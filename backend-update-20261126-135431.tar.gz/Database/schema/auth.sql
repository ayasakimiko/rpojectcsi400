-- Schema owned by the auth service. Applied by Database/migrate.js.

CREATE TABLE IF NOT EXISTS Customer (
    id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY,
    role VARCHAR(20) NOT NULL DEFAULT 'Customer',
    idcard VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
    age INT UNSIGNED NOT NULL,
    room_number INT UNSIGNED,
    deposit_amount DECIMAL(10,2),
    dorm_info_acknowledged_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (room_number) REFERENCES Room(room_number) ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Staff (
    id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    role VARCHAR(20) NOT NULL DEFAULT 'Staff',
    idcard VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
    age INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS Admin (
    id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    role VARCHAR(20) NOT NULL DEFAULT 'Admin',
    idcard VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
    age INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS Owner (
    id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    role VARCHAR(20) NOT NULL DEFAULT 'Owner',
    idcard VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    is_suspended BOOLEAN NOT NULL DEFAULT FALSE,
    age INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS Booking (
    id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    customer_id INT UNSIGNED NOT NULL,
    room_id INT NOT NULL,
    rental_start_date DATETIME NULL,
    rental_end_date DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id) REFERENCES Customer(id),
    FOREIGN KEY (room_id) REFERENCES Room(id)
);

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'rental_start_date'),
    'SELECT 1',
    'ALTER TABLE `Booking` ADD COLUMN `rental_start_date` DATETIME NULL AFTER room_id'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'rental_end_date'),
    'SELECT 1',
    'ALTER TABLE `Booking` ADD COLUMN `rental_end_date` DATETIME NULL AFTER rental_start_date'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'contract_duration_months'),
    'SELECT 1',
    'ALTER TABLE `Booking` ADD COLUMN `contract_duration_months` INT UNSIGNED NULL AFTER rental_end_date'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'contract_completed_at'),
    'SELECT 1',
    'ALTER TABLE `Booking` ADD COLUMN `contract_completed_at` DATETIME NULL AFTER contract_duration_months'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'ended_at'),
    'SELECT 1',
    'ALTER TABLE `Booking` ADD COLUMN `ended_at` DATETIME NULL AFTER contract_completed_at'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'deposit_amount'),
    'SELECT 1',
    'ALTER TABLE `Booking` ADD COLUMN `deposit_amount` DECIMAL(10,2) NULL AFTER ended_at'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'deposit_settlement'),
    'SELECT 1',
    'ALTER TABLE `Booking`
       ADD COLUMN `deposit_settlement` VARCHAR(20) NULL AFTER deposit_amount,
       ADD COLUMN `deposit_deduction` DECIMAL(10,2) NULL AFTER deposit_settlement,
       ADD COLUMN `deposit_refunded_amount` DECIMAL(10,2) NULL AFTER deposit_deduction,
       ADD COLUMN `deposit_settlement_note` VARCHAR(500) NULL AFTER deposit_refunded_amount,
       ADD COLUMN `deposit_settled_at` DATETIME NULL AFTER deposit_settlement_note,
       ADD COLUMN `deposit_settled_by_name` VARCHAR(255) NULL AFTER deposit_settled_at'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'first_payment_due_date'),
    'SELECT 1',
    'ALTER TABLE `Booking`
       ADD COLUMN `first_payment_due_date` DATE NULL AFTER deposit_settled_by_name,
       ADD COLUMN `first_payment_voided_at` DATETIME NULL AFTER first_payment_due_date,
       ADD INDEX idx_booking_first_payment_due (first_payment_due_date)'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND COLUMN_NAME = 'deposit_extra_charge'),
    'SELECT 1',
    'ALTER TABLE `Booking` ADD COLUMN `deposit_extra_charge` DECIMAL(10,2) NULL AFTER deposit_refunded_amount'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

CREATE TABLE IF NOT EXISTS ContractImage (
    id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY,
    booking_id INT NOT NULL,
    customer_id INT UNSIGNED NOT NULL,
    name VARCHAR(255) NULL,
    url VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_contract_image_booking FOREIGN KEY (booking_id) REFERENCES Booking(id),
    CONSTRAINT fk_contract_image_customer FOREIGN KEY (customer_id) REFERENCES Customer(id),
    INDEX idx_contract_image_booking (booking_id, id),
    INDEX idx_contract_image_customer (customer_id)
);

CREATE TABLE IF NOT EXISTS RoomTransfer (
    id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY,
    tenant_request_id INT NOT NULL,
    customer_id INT UNSIGNED NOT NULL,
    from_booking_id INT NOT NULL,
    to_booking_id INT NOT NULL,
    from_room_number INT UNSIGNED NOT NULL,
    to_room_number INT UNSIGNED NOT NULL,
    from_price DECIMAL(10,2) NOT NULL,
    to_price DECIMAL(10,2) NOT NULL,
    chargeable_periods INT UNSIGNED NOT NULL DEFAULT 0,
    price_difference_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    deposit_before DECIMAL(10,2) NOT NULL DEFAULT 0,
    deposit_deducted DECIMAL(10,2) NOT NULL DEFAULT 0,
    amount_charged DECIMAL(10,2) NOT NULL DEFAULT 0,
    charge_payment_id INT UNSIGNED NULL,
    new_price_from DATETIME NULL,
    approved_by_name VARCHAR(255) NULL,
    transferred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    contract_booking_id INT NULL,
    inspection_id INT NULL,
    move_date DATE NULL,
    paid_through DATETIME NULL,
    remaining_days INT UNSIGNED NULL,
    period_days INT UNSIGNED NULL,
    old_unused_rent DECIMAL(10,2) NULL,
    new_prorated_rent DECIMAL(10,2) NULL,
    rent_charge DECIMAL(10,2) NULL,
    rent_credit_to_deposit DECIMAL(10,2) NULL,
    damage_deduction DECIMAL(10,2) NULL,
    transferable_deposit DECIMAL(10,2) NULL,
    required_deposit DECIMAL(10,2) NULL,
    deposit_applied DECIMAL(10,2) NULL,
    deposit_topup DECIMAL(10,2) NULL,
    deposit_surplus_credit DECIMAL(10,2) NULL,
    deposit_limit DECIMAL(10,2) NULL,
    deposit_excess_refund DECIMAL(10,2) NULL,
    deposit_after DECIMAL(10,2) NULL,

    UNIQUE KEY uq_room_transfer_request (tenant_request_id),
    CONSTRAINT fk_room_transfer_customer FOREIGN KEY (customer_id) REFERENCES Customer(id),
    CONSTRAINT fk_room_transfer_from_booking FOREIGN KEY (from_booking_id) REFERENCES Booking(id),
    CONSTRAINT fk_room_transfer_to_booking FOREIGN KEY (to_booking_id) REFERENCES Booking(id),
    INDEX idx_room_transfer_customer (customer_id, id)
);

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'RoomTransfer' AND COLUMN_NAME = 'contract_booking_id'),
    'SELECT 1',
    'ALTER TABLE `RoomTransfer` ADD COLUMN `contract_booking_id` INT NULL AFTER transferred_at'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'RoomTransfer' AND COLUMN_NAME = 'deposit_after'),
    'SELECT 1',
    'ALTER TABLE `RoomTransfer`
       ADD COLUMN `inspection_id` INT NULL AFTER contract_booking_id,
       ADD COLUMN `move_date` DATE NULL AFTER inspection_id,
       ADD COLUMN `paid_through` DATETIME NULL AFTER move_date,
       ADD COLUMN `remaining_days` INT UNSIGNED NULL AFTER paid_through,
       ADD COLUMN `period_days` INT UNSIGNED NULL AFTER remaining_days,
       ADD COLUMN `old_unused_rent` DECIMAL(10,2) NULL AFTER period_days,
       ADD COLUMN `new_prorated_rent` DECIMAL(10,2) NULL AFTER old_unused_rent,
       ADD COLUMN `rent_charge` DECIMAL(10,2) NULL AFTER new_prorated_rent,
       ADD COLUMN `rent_credit_to_deposit` DECIMAL(10,2) NULL AFTER rent_charge,
       ADD COLUMN `damage_deduction` DECIMAL(10,2) NULL AFTER rent_credit_to_deposit,
       ADD COLUMN `transferable_deposit` DECIMAL(10,2) NULL AFTER damage_deduction,
       ADD COLUMN `required_deposit` DECIMAL(10,2) NULL AFTER transferable_deposit,
       ADD COLUMN `deposit_applied` DECIMAL(10,2) NULL AFTER required_deposit,
       ADD COLUMN `deposit_topup` DECIMAL(10,2) NULL AFTER deposit_applied,
       ADD COLUMN `deposit_surplus_credit` DECIMAL(10,2) NULL AFTER deposit_topup,
       ADD COLUMN `deposit_limit` DECIMAL(10,2) NULL AFTER deposit_surplus_credit,
       ADD COLUMN `deposit_excess_refund` DECIMAL(10,2) NULL AFTER deposit_limit,
       ADD COLUMN `deposit_after` DECIMAL(10,2) NULL AFTER deposit_excess_refund'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'RoomTransfer' AND COLUMN_NAME = 'rent_charge_payment_id'),
    'SELECT 1',
    'ALTER TABLE `RoomTransfer`
       ADD COLUMN `rent_carry_credit` DECIMAL(10,2) NULL AFTER deposit_after,
       ADD COLUMN `rent_charge_payment_id` INT UNSIGNED NULL AFTER rent_carry_credit'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ContractImage' AND COLUMN_NAME = 'replaced_at'),
    'SELECT 1',
    'ALTER TABLE `ContractImage`
       ADD COLUMN `room_transfer_id` INT UNSIGNED NULL AFTER url,
       ADD COLUMN `replaced_at` DATETIME NULL AFTER room_transfer_id,
       ADD COLUMN `replaced_by_transfer_id` INT UNSIGNED NULL AFTER replaced_at,
       ADD INDEX `idx_contract_image_replaced_by` (replaced_by_transfer_id)'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

CREATE TABLE IF NOT EXISTS ContractAmendment (
    id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY,
    booking_id INT NOT NULL,
    customer_id INT UNSIGNED NOT NULL,
    version_no INT UNSIGNED NOT NULL,
    reason VARCHAR(30) NOT NULL,
    changes TEXT NOT NULL,
    note VARCHAR(500) NOT NULL,
    amended_by_name VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_contract_amendment_version (booking_id, version_no),
    INDEX idx_contract_amendment_customer (customer_id, id)
);

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ContractImage' AND COLUMN_NAME = 'amendment_id'),
    'SELECT 1',
    'ALTER TABLE `ContractImage`
       ADD COLUMN `amendment_id` INT UNSIGNED NULL AFTER replaced_by_transfer_id,
       ADD COLUMN `replaced_by_amendment_id` INT UNSIGNED NULL AFTER amendment_id,
       ADD INDEX `idx_contract_image_amendment` (amendment_id),
       ADD INDEX `idx_contract_image_replaced_by_amendment` (replaced_by_amendment_id)'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ContractAmendment' AND COLUMN_NAME = 'acknowledged_at'),
    'SELECT 1',
    'ALTER TABLE `ContractAmendment` ADD COLUMN `acknowledged_at` DATETIME NULL AFTER amended_by_name'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND INDEX_NAME = 'idx_booking_contract_completed'),
    'SELECT 1',
    'CREATE INDEX `idx_booking_contract_completed` ON `Booking` (contract_completed_at)'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Booking' AND INDEX_NAME = 'idx_booking_customer_created'),
    'SELECT 1',
    'CREATE INDEX `idx_booking_customer_created` ON `Booking` (customer_id, created_at)'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Customer' AND COLUMN_NAME = 'dorm_info_acknowledged_at'),
    'SELECT 1',
    'ALTER TABLE `Customer` ADD COLUMN `dorm_info_acknowledged_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP AFTER deposit_amount'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

ALTER TABLE `Customer` ALTER COLUMN `dorm_info_acknowledged_at` SET DEFAULT NULL;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Customer' AND COLUMN_NAME = 'history_reset_at'),
    'SELECT 1',
    'ALTER TABLE `Customer` ADD COLUMN `history_reset_at` DATETIME NULL AFTER dorm_info_acknowledged_at'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

UPDATE `Customer` SET `history_reset_at` = NOW() WHERE `is_suspended` = TRUE AND `history_reset_at` IS NULL;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Customer' AND COLUMN_NAME = 'suspended_at'),
    'SELECT 1',
    'ALTER TABLE `Customer` ADD COLUMN `suspended_at` DATETIME NULL AFTER is_suspended'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Customer' AND COLUMN_NAME = 'birth_date'),
    'SELECT 1',
    'ALTER TABLE `Customer` ADD COLUMN `birth_date` DATE NULL AFTER age'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Staff' AND COLUMN_NAME = 'birth_date'),
    'SELECT 1',
    'ALTER TABLE `Staff` ADD COLUMN `birth_date` DATE NULL AFTER age'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Admin' AND COLUMN_NAME = 'birth_date'),
    'SELECT 1',
    'ALTER TABLE `Admin` ADD COLUMN `birth_date` DATE NULL AFTER age'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;

SET @schema_upgrade_sql = IF(
    EXISTS (SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Owner' AND COLUMN_NAME = 'birth_date'),
    'SELECT 1',
    'ALTER TABLE `Owner` ADD COLUMN `birth_date` DATE NULL AFTER age'
);
PREPARE schema_upgrade FROM @schema_upgrade_sql;
EXECUTE schema_upgrade;
DEALLOCATE PREPARE schema_upgrade;
