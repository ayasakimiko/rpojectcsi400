import { useRef } from 'react'
import DatePicker, { registerLocale } from 'react-datepicker'
import { th } from 'date-fns/locale/th'
import 'react-datepicker/dist/react-datepicker.css'
import './ThaiDatePicker.css'

registerLocale('th', th)

const WEEKDAY_SHORT = {
  อาทิตย์: 'อา',
  จันทร์: 'จ',
  อังคาร: 'อ',
  พุธ: 'พ',
  พฤหัสบดี: 'พฤ',
  ศุกร์: 'ศ',
  เสาร์: 'ส',
}

const pad2 = (number) => String(number).padStart(2, '0')

function parseDateString(value) {
  return value ? new Date(`${value}T00:00:00`) : null
}

function toDateString(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate())
}

const formatShort = (date) => date.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: '2-digit' })
const formatFull = (date) => date.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })
const formatTime = (date) => `${pad2(date.getHours())}:${pad2(date.getMinutes())}`
const formatMonth = (date) => date.toLocaleDateString('th-TH', { month: 'long' })
const MONTH_NAMES = Array.from({ length: 12 }, (_, index) => formatMonth(new Date(2000, index, 1)))

function yearOptions(minDate, maxDate) {
  const now = new Date().getFullYear()
  const from = maxDate ? maxDate.getFullYear() : now + 10
  const to = minDate ? minDate.getFullYear() : now - 120
  return Array.from({ length: Math.max(0, from - to) + 1 }, (_, index) => from - index)
}

function getRangeHint(minDate, maxDate, selected) {
  if (minDate && maxDate) return `เลือกได้ ${formatShort(minDate)} – ${formatShort(maxDate)}`
  if (minDate) return `เลือกได้ตั้งแต่ ${formatShort(minDate)}`
  if (maxDate) return `เลือกได้ถึง ${formatShort(maxDate)}`
  return selected ? `เลือก ${formatShort(selected)}` : 'ยังไม่ได้เลือกวันที่'
}

const ChevronIcon =({ direction }) => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d={direction === 'left' ? 'M15 18l-6-6 6-6' : 'M9 18l6-6-6-6'} />
  </svg>
)

function ThaiDatePicker({
  value,
  onChange,
  valueType = 'string',
  placeholder = 'เลือกวันที่',
  className = 'form-control',
  invalid = false,
  compact = false,
  showTimeSelect = false,
  timeOnly = false,
  minDate,
  maxDate,
  pickMonthYear = false,
  ...rest
}) {
  const pickerRef = useRef(null)
  const selected = valueType === 'date' ? value || null : parseDateString(value)

  const emit = (date) => {
    if (valueType === 'date') onChange(date)
    else onChange(date ? toDateString(date) : '')
  }

  const today = startOfDay(new Date())
  const todayDisabled = (minDate && today < startOfDay(minDate)) || (maxDate && today > startOfDay(maxDate))

  const selectToday = () => {
    if (showTimeSelect || timeOnly) {
      const now = new Date()
      now.setSeconds(0, 0)
      emit(minDate && now < minDate ? minDate : now)
    } else {
      emit(today)
    }
    pickerRef.current?.setOpen(false)
  }

  const displayValue = !selected ? '' : timeOnly ? `${formatTime(selected)} น.` : showTimeSelect ? `${formatFull(selected)} เวลา ${formatTime(selected)}` : formatFull(selected)

  return (
    <DatePicker
      ref={pickerRef}
      selected={selected}
      onChange={emit}
      value={displayValue}
      onChangeRaw={(event) => event?.preventDefault()}
      locale="th"
      placeholderText={placeholder}
      className={`${className} thai-dp-input${invalid ? ' is-invalid' : ''}`.trim()}
      wrapperClassName={`thai-dp-wrapper${compact ? ' is-compact' : ''}`}
      calendarClassName={`thai-dp${timeOnly ? ' is-time-only' : ''}`}
      popperClassName="thai-dp-popper"
      popperPlacement="bottom-start"
      showPopperArrow={false}
      fixedHeight
      autoComplete="off"
      showTimeSelect={showTimeSelect || timeOnly}
      showTimeSelectOnly={timeOnly}
      timeFormat="HH:mm"
      timeCaption="เวลา"
      minDate={minDate}
      maxDate={maxDate}
      formatWeekDay={(dayName) => WEEKDAY_SHORT[dayName] || dayName}
      renderCustomHeader={({ monthDate, decreaseMonth, increaseMonth, changeMonth, changeYear, prevMonthButtonDisabled, nextMonthButtonDisabled }) => (
        <div className="thai-dp-header">
          <button type="button" className="thai-dp-nav" onClick={decreaseMonth} disabled={prevMonthButtonDisabled} aria-label="เดือนก่อนหน้า">
            <ChevronIcon direction="left" />
          </button>
          {pickMonthYear ? (
            <div className="thai-dp-title is-pickers">
              <select className="thai-dp-select" value={monthDate.getMonth()} aria-label="เลือกเดือน" onChange={(event) => changeMonth(Number(event.target.value))}>
                {MONTH_NAMES.map((name, index) => (
                  <option key={name} value={index}>{name}</option>
                ))}
              </select>
              <select className="thai-dp-select is-year" value={monthDate.getFullYear()} aria-label="เลือกปี พ.ศ." onChange={(event) => changeYear(Number(event.target.value))}>
                {yearOptions(minDate, maxDate).map((year) => (
                  <option key={year} value={year}>{year + 543}</option>
                ))}
              </select>
            </div>
          ) : (
            <div className="thai-dp-title">
              {formatMonth(monthDate)} <span className="thai-dp-year">{monthDate.getFullYear() + 543}</span>
            </div>
          )}
          <button type="button" className="thai-dp-nav" onClick={increaseMonth} disabled={nextMonthButtonDisabled} aria-label="เดือนถัดไป">
            <ChevronIcon direction="right" />
          </button>
        </div>
      )}
      {...rest}
    >
      <div className="thai-dp-footer">
        <span className="thai-dp-hint">{timeOnly ? 'เลือกเวลา' : getRangeHint(minDate, maxDate, selected)}</span>
        <button type="button" className="thai-dp-today" onClick={selectToday} disabled={todayDisabled}>
          {showTimeSelect || timeOnly ? 'ตอนนี้' : 'วันนี้'}
        </button>
      </div>
    </DatePicker>
  )
}

export default ThaiDatePicker
