import { useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import axios from 'axios'
import { UploadImage } from './UploadMedia.jsx'
import PhotoLightbox from './PhotoLightbox.jsx'
import RoomTransferFinance from './RoomTransferFinance.jsx'
import ThaiDatePicker from './ThaiDatePicker.jsx'
import { matchesSearch } from '../utils/search.js'
import './RentalContract.css'
import {
  addContractMonths,
  CONTRACT_MAX_IMAGES,
  CONTRACT_MIN_IMAGES,
  formatContractDate,
  formatContractLength,
  formatContractMoney,
  formatDepositMonths,
  DEPOSIT_STATUS_LABEL,
  completedContractsViewedKey,
  readViewedContractIds,
  ROOM_TRANSFER_MIN_CONTRACT_IMAGES,
} from '../utils/rentalContract.js'

const CONTRACT_STATUS = {
  active: { label: 'สัญญามีผล', tone: 'active' },
  awaiting_payment: { label: 'รอชำระงวดแรก', tone: 'unpaid' },
  payment_review: { label: 'รอตรวจสลิปงวดแรก', tone: 'warning' },
  upcoming: { label: 'ยังไม่เริ่มสัญญา', tone: 'info' },
  expired: { label: 'หมดอายุสัญญา', tone: 'warning' },
  ended: { label: 'สิ้นสุดการเช่า', tone: 'muted' },
  ended_early: { label: 'ออกก่อนสัญญา', tone: 'unpaid' },
  voided: { label: 'ยกเลิก (ไม่ชำระงวดแรก)', tone: 'muted' },
}

function ContractIcon({ type, size = 16 }) {
  const paths = {
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v12h14V9M9 21v-8h6v8" /></>,
    file: <><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-6-6Z" /><path d="M14 3v6h6M8 13h8M8 17h5" /></>,
    image: <><rect x="3" y="4" width="18" height="16" rx="3" /><circle cx="9" cy="10" r="2" /><path d="m21 16-5-5-9 9" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M16 3v4M8 3v4M3 11h18" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    wallet: <><rect x="3" y="6" width="18" height="14" rx="3" /><path d="M3 10h18M16 15h2" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
    chevron: <path d="m9 6 6 6-6 6" />,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    phone: <path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3.1 5.2 2 2 0 0 1 5.1 3h3a2 2 0 0 1 2 1.7l.5 2.8a2 2 0 0 1-.6 1.7L8.7 10.5a16 16 0 0 0 4.8 4.8l1.3-1.3a2 2 0 0 1 1.7-.6l2.8.5a2 2 0 0 1 1.7 2Z" />,
    check: <><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-6-6Z" /><path d="m9 14 2 2 4-4" /></>,
    alert: <><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" /><path d="M12 9v4M12 17h.01" /></>,
    edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" /></>,
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[type]}
    </svg>
  )
}

function ContractLightbox({ images, index, title, subtitle, onClose }) {
  return createPortal(
    <div onClick={(event) => event.stopPropagation()} onKeyDown={(event) => event.stopPropagation()}>
      <PhotoLightbox photos={images} initialIndex={index} title={title} subtitle={subtitle} label="รูปสัญญาเช่า" onClose={onClose} />
    </div>,
    document.body,
  )
}

function remainingRentMonthsLabel(contract) {
  const price = Number(contract?.monthly_price) || 0
  const remaining = Number(contract?.contract_remaining) || 0
  if (price <= 0) return ''
  const months = Math.ceil(Math.round((remaining / price) * 100) / 100)
  return ` (${months} เดือน)`
}

export function ContractMonthTrack({ start, end, originalEnd, now }) {
  const startDate = start ? new Date(start) : null
  const endDate = end ? new Date(end) : null
  if (!startDate || !endDate || Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime()) || endDate <= startDate) return null
  const renewFrom = originalEnd ? new Date(originalEnd) : null
  const periods = []
  for (let index = 0; index < 120; index += 1) {
    const periodStart = addContractMonths(startDate, index)
    if (periodStart >= endDate) break
    periods.push({ index, periodStart, renewed: Boolean(renewFrom && periodStart >= renewFrom && renewFrom < endDate) })
  }
  if (periods.length === 0) return null
  const daysLeft = Math.ceil((endDate.getTime() - now) / 86400000)
  const tone = daysLeft < 0 ? 'danger' : daysLeft <= 30 ? 'warning' : 'success'
  const leftLabel = daysLeft < 0 ? `หมดสัญญาแล้ว ${Math.abs(daysLeft)} วัน` : daysLeft === 0 ? 'ครบสัญญาวันนี้' : `เหลืออีก ${daysLeft} วัน`
  const elapsed = periods.filter((period) => period.periodStart.getTime() <= now).length
  const current = Math.min(periods.length, Math.max(1, elapsed))
  const finished = now >= endDate.getTime()
  return (
    <div className={`contract-months is-${tone}`}>
      <div className="contract-months-head">
        <div>
          <small>รอบบิล</small>
          <strong>
            {finished ? `ครบ ${periods.length}` : `เดือนที่ ${current}`}
            <span> / {periods.length} เดือน</span>
          </strong>
        </div>
        <span className="contract-months-left">{leftLabel}</span>
      </div>
      <ol className="contract-months-track" aria-label={`รอบบิลเดือนที่ ${current} จาก ${periods.length}`}>
        {periods.map((period) => {
          const state = finished || period.index < current - 1 ? 'is-done' : period.index === current - 1 ? 'is-current' : 'is-next'
          return (
            <li
              key={period.index}
              className={`${state}${period.renewed ? ' is-renewed' : ''}`}
              title={`เดือนที่ ${period.index + 1} · ${period.periodStart.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: '2-digit' })}${period.renewed ? ' · ช่วงต่อสัญญา' : ''}`}
            >
              <span>{period.periodStart.toLocaleDateString('th-TH', { month: 'short' })}</span>
            </li>
          )
        })}
      </ol>
      <div className="contract-months-legend">
        <span className="is-done">ผ่านแล้ว</span>
        <span className="is-current">เดือนนี้</span>
        <span className="is-next">ที่เหลือ</span>
        {periods.some((period) => period.renewed) && <span className="is-renewed">ช่วงต่อสัญญา</span>}
      </div>
    </div>
  )
}

export function ContractStatusBadge({ status }) {
  const info = CONTRACT_STATUS[status] || CONTRACT_STATUS.active
  return <span className={`contract-status is-${info.tone}`}>{info.label}</span>
}

export function ContractFirstPaymentNote({ contract, viewer = 'staff' }) {
  if (!contract || !['awaiting_payment', 'payment_review'].includes(contract.status)) return null
  const review = contract.status === 'payment_review'
  const amount = formatContractMoney(contract.first_month_total)
  const detail = Number(contract.deposit_amount) > 0
    ? `ค่าห้อง ${formatContractMoney(contract.first_month_amount)} + มัดจำ ${formatContractMoney(contract.deposit_amount)}`
    : `ค่าห้อง ${formatContractMoney(contract.first_month_amount)}`
  const deadline = !review && contract.first_payment_due_date
    ? ` · ต้องชำระภายใน ${formatContractDate(`${contract.first_payment_due_date}T00:00:00`)} ไม่เช่นนั้นสัญญาจะถูกยกเลิก`
    : ''
  return (
    <div className={`contract-first-payment-note${review ? ' is-review' : ''}`} role="status">
      <ContractIcon type="wallet" size={18} />
      <span>
        <strong>{review ? 'ส่งสลิปงวดแรกแล้ว รอเจ้าหน้าที่ตรวจสอบ' : 'สัญญายังไม่มีผล'}</strong>
        {review
          ? `สัญญาจะมีผลเมื่ออนุมัติสลิปงวดแรก ${amount} (${detail})`
          : viewer === 'customer'
            ? `กรุณาชำระงวดแรก ${amount} (${detail}) ผ่านระบบหรือที่เจ้าหน้าที่ สัญญาจะมีผลหลังชำระครบ${deadline}`
            : `สัญญาจะมีผลเมื่อผู้เช่าชำระงวดแรก ${amount} (${detail}) หรือเจ้าหน้าที่เก็บเงินแล้ว${deadline}`}
      </span>
    </div>
  )
}

export function ContractGallery({ images = [], title = 'รูปสัญญาเช่า', subtitle }) {
  const [openIndex, setOpenIndex] = useState(null)
  if (images.length === 0) {
    return (
      <div className="contract-gallery-empty">
        <span className="contract-gallery-empty-icon" aria-hidden="true"><ContractIcon type="image" size={22} /></span>
        <strong>ยังไม่มีรูปสัญญาเช่า</strong>
        <span>สัญญาที่ลงทะเบียนก่อนเปิดใช้ระบบแนบรูป จะไม่มีรูปสัญญาเก็บไว้ในระบบ</span>
      </div>
    )
  }
  return (
    <>
      <ul className="contract-gallery" aria-label={title}>
        {images.map((image, index) => (
          <li key={image.url}>
            <button
              type="button"
              className="contract-gallery-item"
              onClick={(event) => {
                event.stopPropagation()
                setOpenIndex(index)
              }}
              aria-label={`ดูรูปสัญญาเช่า ${index + 1} จาก ${images.length}`}
            >
              <UploadImage src={image.url} alt="" loading="lazy" />
              <span className="contract-gallery-index">{index + 1}</span>
            </button>
          </li>
        ))}
      </ul>
      {openIndex !== null && (
        <ContractLightbox images={images} index={openIndex} title={title} subtitle={subtitle} onClose={() => setOpenIndex(null)} />
      )}
    </>
  )
}

function DepositSummary({ contract }) {
  if (!(Number(contract?.deposit_amount) > 0)) return <span className="deposit-summary is-none">ไม่มีมัดจำ</span>
  const months = Number(contract.deposit_months)
  const status = DEPOSIT_STATUS_LABEL[contract.deposit_status]
  return (
    <span className="deposit-summary">
      <b>{formatContractMoney(contract.deposit_amount)}</b>
      {Number.isInteger(months) && months > 0 && <span className="deposit-summary-months">{months} เดือน</span>}
      {status && <span className={`deposit-summary-status is-${contract.deposit_status}`}>{status}</span>}
    </span>
  )
}

export function ContractFacts({ contract }) {
  const facts = [
    { label: 'ระยะเวลาสัญญา', value: formatContractLength(contract) },
    { label: 'วันเริ่มสัญญา', value: formatContractDate(contract.rental_start_date, true) },
    { label: 'วันสิ้นสุดสัญญา', value: formatContractDate(contract.rental_end_date, true) },
    ...(contract.current_end_date && new Date(contract.current_end_date).getTime() !== new Date(contract.rental_end_date).getTime()
      ? [{ label: 'สัญญาปัจจุบันถึง', value: formatContractDate(contract.current_end_date, true), hint: 'รวมการต่อสัญญา/ย้ายห้อง' }]
      : []),
    { label: 'ค่าเช่าห้องต่อเดือน', value: formatContractMoney(contract.monthly_price) },
    { label: 'เงินมัดจำ', value: <DepositSummary contract={contract} /> },
    {
      label: 'ทำสัญญาสำเร็จเมื่อ',
      value: contract.contract_completed_at ? formatContractDate(contract.contract_completed_at, true) : formatContractDate(contract.created_at, true),
    },
  ]
  return (
    <dl className="contract-facts">
      {facts.map((fact) => (
        <div key={fact.label}>
          <dt>{fact.label}</dt>
          <dd>
            {fact.value}
            {fact.hint && <small>{fact.hint}</small>}
          </dd>
        </div>
      ))}
    </dl>
  )
}

export function ContractFirstMonth({ contract }) {
  return (
    <div className="contract-first-month" aria-label="การคำนวณค่าเช่าเดือนแรก">
      <div>
        <span>ค่าเช่าเดือนแรก</span>
        <strong>{formatContractMoney(contract.first_month_amount)}</strong>
      </div>
      <div>
        <span>เงินมัดจำ ({formatDepositMonths(contract)})</span>
        <strong>+ {formatContractMoney(contract.deposit_amount || 0)}</strong>
      </div>
      <div className="is-total">
        <span>รวมชำระเดือนแรก</span>
        <strong>{formatContractMoney(contract.first_month_total)}</strong>
      </div>
      <p>
        เดือนแรกชำระค่าห้องพร้อมเงินมัดจำ เดือนถัดไปชำระเฉพาะค่าห้อง
        {DEPOSIT_STATUS_LABEL[contract.deposit_status] ? ` · มัดจำ${DEPOSIT_STATUS_LABEL[contract.deposit_status]}` : ''}
      </p>
    </div>
  )
}

export function ContractDetail({ contract, showPerson = false, onDepositSettled }) {
  const [now] = useState(() => Date.now())
  if (!contract) {
    return (
      <div className="contract-gallery-empty">
        <ContractIcon type="file" size={22} />
        <strong>ยังไม่มีข้อมูลสัญญาเช่า</strong>
      </div>
    )
  }
  const name = `${contract.first_name || ''} ${contract.last_name || ''}`.trim()
  return (
    <div className="contract-detail">
      <div className="contract-detail-head">
        <span className="contract-detail-icon"><ContractIcon type="file" size={18} /></span>
        <div>
          <strong>{showPerson && name ? name : 'สัญญาเช่า'}</strong>
          <small>ห้อง {contract.room_number || '-'} · {formatContractLength(contract)}</small>
        </div>
        <ContractStatusBadge status={contract.status} />
      </div>
      {!contract.is_archived && <ContractFirstPaymentNote contract={contract} />}
      {onDepositSettled && contract.can_settle_deposit ? (
        <DepositSettlementForm contract={contract} onSaved={onDepositSettled} />
      ) : (
        <DepositRefundNote contract={contract} />
      )}
      {!contract.is_archived && (
        <ContractMonthTrack
          start={contract.rental_start_date}
          end={contract.effective_end_date || contract.current_end_date || contract.rental_end_date}
          originalEnd={
            contract.current_end_date && new Date(contract.current_end_date).getTime() !== new Date(contract.rental_end_date).getTime()
              ? contract.rental_end_date
              : null
          }
          now={now}
        />
      )}
      <ContractFacts contract={contract} />
      <ContractTransferHistory contract={contract} />
      <ContractFirstMonth contract={contract} />
      <section className="contract-detail-images">
        <header>
          <ContractIcon type="image" size={15} />
          <strong>รูปสัญญาเช่า</strong>
          <span>{contract.image_count || 0} รูป</span>
        </header>
        <ContractGallery images={contract.images || []} subtitle={`ห้อง ${contract.room_number || '-'}${name ? ` · ${name}` : ''}`} />
      </section>
    </div>
  )
}

export function ContractCell({ contract }) {
  if (!contract) return <span className="contract-cell-empty">-</span>
  const start = contract.rental_start_date ? new Date(contract.rental_start_date) : null
  const endValue = contract.effective_end_date || contract.current_end_date || contract.rental_end_date
  const end = endValue ? new Date(endValue) : null
  const extended = Boolean(end && contract.rental_end_date && end.getTime() > new Date(contract.rental_end_date).getTime())
  const totalMonths = extended && start
    ? Math.max(1, Math.round((end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth()))
    : null
  const hasDeposit = Number(contract.deposit_amount) > 0
  const depositState = contract.deposit_settlement
    ? contract.deposit_settlement === 'refunded'
      ? { label: 'คืนแล้ว', tone: 'paid' }
      : { label: 'ริบแล้ว', tone: 'muted' }
    : contract.deposit_refund === 'refund'
      ? { label: 'ต้องคืน', tone: 'pending' }
      : DEPOSIT_STATUS_LABEL[contract.deposit_status]
        ? { label: DEPOSIT_STATUS_LABEL[contract.deposit_status], tone: contract.deposit_status }
        : null
  return (
    <div className="contract-cell">
      <div className="contract-cell-text">
        <strong>
          {formatContractMoney(contract.monthly_price)} · {totalMonths ? `${totalMonths} เดือน` : formatContractLength(contract)}
          {extended && <em className="contract-cell-tag">ต่อแล้ว</em>}
        </strong>
        <small>
          {hasDeposit ? <>มัดจำ <b>{formatContractMoney(contract.deposit_amount)}</b></> : 'ไม่มีมัดจำ'}
          {hasDeposit && depositState && <i className={`contract-cell-deposit is-${depositState.tone}`}> · {depositState.label}</i>}
        </small>
      </div>
      <ContractThumb contract={contract} />
    </div>
  )
}

const IMAGE_ACCEPT = 'image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp'

export function ContractImagePicker({ files, onChange, error, min = CONTRACT_MIN_IMAGES }) {
  const previews = useMemo(() => files.map((file) => ({ file, url: URL.createObjectURL(file) })), [files])
  useEffect(() => () => previews.forEach((preview) => URL.revokeObjectURL(preview.url)), [previews])
  const [dragging, setDragging] = useState(false)
  const dragDepth = useRef(0)
  const inputRef = useRef(null)
  const full = files.length >= CONTRACT_MAX_IMAGES
  const remaining = Math.max(0, min - files.length)
  const progress = Math.min(100, (files.length / min) * 100)

  const addFiles = (selected) => {
    if (selected.length) onChange([...files, ...selected])
  }
  const replaceFile = (index, event) => {
    const [file] = event.target.files || []
    event.target.value = ''
    if (file) onChange(files.map((item, itemIndex) => (itemIndex === index ? file : item)))
  }
  const hasFiles = (event) => [...(event.dataTransfer?.types || [])].includes('Files')
  const dragHandlers = {
    onDragEnter: (event) => {
      if (!hasFiles(event)) return
      event.preventDefault()
      dragDepth.current += 1
      setDragging(true)
    },
    onDragOver: (event) => {
      if (!hasFiles(event)) return
      event.preventDefault()
      event.dataTransfer.dropEffect = full ? 'none' : 'copy'
    },
    onDragLeave: (event) => {
      if (!hasFiles(event)) return
      dragDepth.current = Math.max(0, dragDepth.current - 1)
      if (dragDepth.current === 0) setDragging(false)
    },
    onDrop: (event) => {
      if (!hasFiles(event)) return
      event.preventDefault()
      dragDepth.current = 0
      setDragging(false)
      if (!full) addFiles([...(event.dataTransfer.files || [])])
    },
  }

  return (
    <div className={`contract-picker${error ? ' is-invalid' : ''}${dragging ? ' is-dragging' : ''}`} {...dragHandlers}>
      <div className="contract-picker-head">
        <div className="contract-picker-progress">
          <span>
            <strong>{files.length}</strong>/{CONTRACT_MAX_IMAGES} รูป
            <em className={remaining > 0 ? 'is-pending' : 'is-done'}>{remaining > 0 ? `ขาดอีก ${remaining}` : 'ครบขั้นต่ำ'}</em>
          </span>
          <i aria-hidden="true"><b style={{ width: `${progress}%` }} /></i>
        </div>
        <button type="button" className="contract-picker-add" disabled={full} onClick={() => inputRef.current?.click()}>
          + เพิ่มรูป
        </button>
        <input
          ref={inputRef}
          type="file"
          accept={IMAGE_ACCEPT}
          multiple
          hidden
          onChange={(event) => {
            const selected = [...(event.target.files || [])]
            event.target.value = ''
            addFiles(selected)
          }}
        />
      </div>
      <div className="contract-picker-body">
        {previews.length > 0 ? (
          <ul className="contract-gallery contract-picker-grid">
            {previews.map((preview, index) => (
              <li key={preview.url}>
                <div className="contract-gallery-item is-static">
                  <img src={preview.url} alt={`รูปสัญญาเช่า ${index + 1}`} />
                  <span className="contract-gallery-index">{index + 1}</span>
                </div>
                <div className="contract-picker-actions">
                  <label>
                    เปลี่ยน
                    <input type="file" accept={IMAGE_ACCEPT} hidden onChange={(event) => replaceFile(index, event)} />
                  </label>
                  <button type="button" onClick={() => onChange(files.filter((_, itemIndex) => itemIndex !== index))}>
                    ลบ
                  </button>
                </div>
              </li>
            ))}
            {!full && (
              <li>
                <button type="button" className="contract-picker-tile" onClick={() => inputRef.current?.click()}>
                  <span>+</span>
                  เพิ่มรูป
                </button>
              </li>
            )}
          </ul>
        ) : (
          <button type="button" className="contract-picker-drop" onClick={() => inputRef.current?.click()}>
            <ContractIcon type="image" size={26} />
            <strong>ลากรูปมาวาง หรือคลิกเพื่อเลือก</strong>
            <span>อย่างน้อย {min} รูป · JPG, PNG, WebP · ไม่เกิน 5 MB/รูป</span>
          </button>
        )}
      </div>
      {dragging && (
        <div className="contract-picker-overlay" aria-hidden="true">
          <ContractIcon type="image" size={28} />
          <strong>{full ? `แนบครบ ${CONTRACT_MAX_IMAGES} รูปแล้ว` : 'ปล่อยเพื่อเพิ่มรูปสัญญา'}</strong>
        </div>
      )}
      {error && <div className="contract-picker-error">{error}</div>}
    </div>
  )
}

const STAFF_CARD_STATUS = {
  active: { label: 'สัญญามีผล', tone: 'is-active' },
  transferred: { label: 'ย้ายห้องแล้ว', tone: 'is-transferred' },
  awaiting_payment: { label: 'รอชำระงวดแรก', tone: 'is-unpaid' },
  payment_review: { label: 'รอตรวจสลิปงวดแรก', tone: 'is-warning' },
  upcoming: { label: 'ยังไม่เริ่ม', tone: 'is-info' },
  expired: { label: 'หมดอายุ', tone: 'is-warning' },
  ended: { label: 'สิ้นสุดการเช่า', tone: 'is-muted' },
  ended_early: { label: 'ออกก่อนสัญญา', tone: 'is-unpaid' },
  voided: { label: 'ยกเลิกสัญญา', tone: 'is-muted' },
}
const STAFF_CARD_PHOTOS = 4

export function DepositEarlyLeaveWarning({ contract }) {
  if (!contract || !(Number(contract.deposit_amount) > 0)) return null
  if (['ended', 'ended_early', 'expired', 'voided'].includes(contract.status)) return null
  return (
    <div className="contract-refund-note is-refund" role="note">
      <ContractIcon type="wallet" size={18} />
      <span>
        <strong>เงินมัดจำคืนหลังย้ายออกและตรวจห้อง</strong>
        <small>
          เงินมัดจำ {formatContractMoney(contract.deposit_amount)} ({formatDepositMonths(contract)}) หักได้เฉพาะค่าเสียหายหรือยอดค้างชำระที่มีหลักฐาน
          {' '}หากต้องการย้ายออกก่อนครบสัญญา กรุณาแจ้งเจ้าหน้าที่ล่วงหน้า
        </small>
      </span>
    </div>
  )
}

function SettledDepositNote({ contract, viewer, compact }) {
  const refunded = contract.deposit_settlement === 'refunded'
  const deduction = Number(contract.deposit_deduction) || 0
  const extraCharge = Number(contract.deposit_extra_charge) || 0
  const title = refunded
    ? viewer === 'customer'
      ? `ได้รับเงินมัดจำคืนแล้ว ${formatContractMoney(contract.deposit_refunded_amount)}`
      : `คืนเงินมัดจำแล้ว ${formatContractMoney(contract.deposit_refunded_amount)}`
    : `ริบเงินมัดจำแล้ว ${formatContractMoney(contract.deposit_remaining ?? contract.deposit_paid)}`
  if (!compact) {
    return (
      <div className={`contract-refund-note ${refunded ? 'is-refund' : 'is-forfeit'} is-settled is-detailed`} role="note">
        <ContractIcon type="check" size={16} />
        <div className="settled-deposit-body">
          <div className="settled-deposit-head">
            <strong>{title}</strong>
            {viewer !== 'customer' && contract.booking_id && <DepositLogLink contract={contract} />}
          </div>
          <div className="settled-deposit-meta">
            {refunded && deduction > 0 && <span>หักค่าเสียหาย {formatContractMoney(deduction)}</span>}
            {extraCharge > 0 && <span className="is-owe">ผู้เช่าต้องจ่ายเพิ่ม {formatContractMoney(extraCharge)}</span>}
            {contract.deposit_settlement_note && (
              <span className="is-reason">
                {refunded ? 'หมายเหตุ' : 'เหตุผล'}: {contract.deposit_settlement_note}
              </span>
            )}
            <span className="is-staff">
              <ContractIcon type="user" size={12} />
              {contract.deposit_settled_by_name || '-'}
            </span>
            <span className="is-date">
              <ContractIcon type="calendar" size={12} />
              {formatContractDate(contract.deposit_settled_at)}
            </span>
          </div>
        </div>
      </div>
    )
  }
  const parts = [
    refunded && deduction > 0 ? `หักค่าเสียหาย ${formatContractMoney(deduction)}` : null,
    extraCharge > 0 ? `ผู้เช่าต้องจ่ายเพิ่ม ${formatContractMoney(extraCharge)}` : null,
    `${contract.deposit_settled_by_name || '-'} · ${formatContractDate(contract.deposit_settled_at)}`,
  ].filter(Boolean)
  return (
    <span className={`contract-refund-note ${refunded ? 'is-refund' : 'is-forfeit'} is-settled${compact ? ' is-compact' : ''}`} role="note">
      <ContractIcon type="check" size={compact ? 14 : 18} />
      <span>
        <strong>{title}</strong>
        <small>{parts.join(' · ')}</small>
      </span>
    </span>
  )
}

export function DepositRefundNote({ contract, viewer = 'staff', compact = false }) {
  if (contract?.deposit_settlement) return <SettledDepositNote contract={contract} viewer={viewer} compact={compact} />
  if (!contract?.deposit_refund) return null
  const amount = formatContractMoney(contract.deposit_remaining ?? contract.deposit_paid)
  const pendingTask = viewer !== 'customer' && contract.can_settle_deposit
  const title = viewer === 'customer' ? `รอรับเงินมัดจำคืน ${amount}` : `ต้องคืนเงินมัดจำ ${amount}`
  const reason = {
    expired: compact ? 'ครบสัญญา พักอยู่ตามกำหนด' : 'สัญญาครบกำหนดแล้วและผู้เช่าพักอยู่ตามกำหนด',
    ended_early: compact ? 'ออกก่อนสัญญา' : 'ผู้เช่าออกก่อนสัญญาสิ้นสุด',
    voided: compact ? 'สัญญาถูกยกเลิก' : 'สัญญาถูกยกเลิกเพราะไม่ชำระงวดแรก',
  }[contract.status] || (compact ? 'พักอยู่ครบตามสัญญา' : 'ผู้เช่าพักอยู่ครบตามสัญญา')
  const detail = compact ? reason : `${reason} · หักได้เฉพาะค่าเสียหายหรือยอดค้างที่มีหลักฐาน`
  return (
    <span className={`contract-refund-note is-refund${pendingTask ? ' is-pending-task' : ''}${compact ? ' is-compact' : ''}`} role="note">
      <ContractIcon type="wallet" size={compact ? 14 : 18} />
      <span>
        <strong>{title}</strong>
        <small>{detail}</small>
      </span>
    </span>
  )
}

function contractPeriodPosition(contract, now) {
  const periods = Math.max(1, Number(contract.billing_periods) || 1)
  const start = contract.rental_start_date ? new Date(contract.rental_start_date) : null
  const today = new Date(now)
  const elapsed = start
    ? (today.getFullYear() - start.getFullYear()) * 12 + today.getMonth() - start.getMonth() - (today.getDate() < start.getDate() ? 1 : 0)
    : 0
  return { periods, currentPeriod: Math.min(periods, Math.max(0, elapsed)) }
}

function ContractPeriodTimeline({ contract, now, endLabel = 'สิ้นสุด', endValue }) {
  const { daysLeft } = contractTimeline(contract, now)
  const { periods, currentPeriod } = contractPeriodPosition(contract, now)
  const left = ['ended', 'ended_early'].includes(contract.status)
  const leftAt = contract.moved_out_at ? new Date(contract.moved_out_at) : null
  const endAt = contract.rental_end_date ? new Date(contract.rental_end_date) : null
  const earlyDays = contract.status === 'ended_early' && endAt
    ? Math.max(0, Math.ceil((endAt - (leftAt ?? new Date(now))) / 86400000))
    : 0
  return (
    <>
      <span className="csc-period-row">
        <span className="csc-date">
          <small>เริ่มสัญญา</small>
          <b>{formatContractDate(contract.rental_start_date)}</b>
        </span>
        <span className="csc-period-line" aria-hidden="true">
          <em>{formatContractLength(contract)}</em>
        </span>
        <span className="csc-date is-end">
          <small>{endLabel}</small>
          <b>{formatContractDate(endValue ?? contract.rental_end_date)}</b>
        </span>
      </span>
      {left ? (
        <span className="csc-period-meta">
          <small>{leftAt ? `ออกเมื่อ ${formatContractDate(leftAt)}` : 'ไม่ได้พักอยู่แล้ว'}</small>
          <small className={earlyDays > 0 ? 'is-danger' : ''}>
            {earlyDays > 0 ? `ออกก่อนครบ ${earlyDays} วัน` : 'สิ้นสุดการเช่า'}
          </small>
        </span>
      ) : (
        <span className="csc-period-meta">
          <small>{currentPeriod >= periods ? `ครบ ${periods} รอบบิล` : `เดือนที่ ${currentPeriod + 1}/${periods}`}</small>
          <small className={daysLeft !== null && daysLeft <= 30 ? 'is-warning' : ''}>
            {daysLeft > 0 ? `เหลือ ${daysLeft} วัน` : formatDaysLeft(daysLeft)}
          </small>
        </span>
      )}
    </>
  )
}

export function ArchivedContractBadge({ contract }) {
  return (
    <>
      <span className="contract-archived-badge" title="สัญญานี้สิ้นสุดแล้ว เก็บไว้เป็นประวัติ">
        สัญญาเก่า
      </span>
      {contract.has_newer_contract && (
        <span className="contract-newer-badge" title="ผู้เช่าคนนี้ทำสัญญาใหม่แล้ว สัญญานี้เก็บไว้เป็นประวัติ">
          มีสัญญาใหม่แล้ว
        </span>
      )}
    </>
  )
}

const contractTransfers = (contract) => contract?.room_transfers ?? []

const contractCardStatus = (contract) =>
  !contract.is_archived && contractTransfers(contract).length > 0 ? 'transferred' : contract.status

export function ContractRoomBadge({ contract, size = 'card' }) {
  const moved = contractTransfers(contract).length > 0
  const roomNumber = (size === 'hero' ? contract.current_room_number : null) || contract.room_number || '-'
  return size === 'hero' ? (
    <div className={`ccc-room${moved ? ' is-moved' : ''}`}>
      <span>ห้อง</span>
      <strong>{roomNumber}</strong>
    </div>
  ) : (
    <span className={`csc-room${moved ? ' is-moved' : ''}`}>
      <small>ห้อง</small>
      <strong>{roomNumber}</strong>
    </span>
  )
}

function ContractTransferSummary({ contract }) {
  const transfers = contractTransfers(contract)
  if (transfers.length === 0) return null
  const last = transfers.at(-1)
  const fromPrice = Number(last.from_price)
  const toPrice = Number(last.to_price)
  return (
    <span className="csc-transfer-route" title={`ย้ายล่าสุด ${formatContractDate(last.transferred_at)}`}>
      <span>
        ย้ายจาก <b>{last.from_room_number}</b>
      </span>
      <span className={fromPrice === toPrice ? 'is-same' : toPrice > fromPrice ? 'is-up' : 'is-down'}>
        {fromPrice === toPrice
          ? 'ค่าเช่าเท่าเดิม'
          : `${toPrice > fromPrice ? '▲' : '▼'} ${formatContractMoney(toPrice)}`}
      </span>
      {transfers.length > 1 && <span className="is-count">ย้ายแล้ว {transfers.length} ครั้ง</span>}
    </span>
  )
}

function StaffContractCard({ contract, onOpen, unviewed }) {
  const [openIndex, setOpenIndex] = useState(null)
  const [now] = useState(() => Date.now())
  const images = contract.images || []
  const cardStatus = contractCardStatus(contract)
  const status = STAFF_CARD_STATUS[cardStatus] || STAFF_CARD_STATUS.active
  const underlying = cardStatus === 'transferred' && contract.status !== 'active' ? STAFF_CARD_STATUS[contract.status] : null
  const tenantName = `${contract.first_name || ''} ${contract.last_name || ''}`.trim() || '-'
  const extra = images.length - STAFF_CARD_PHOTOS
  return (
    <li
      className={`csc-card is-${cardStatus}${contract.is_archived ? ' is-archived' : ''}${contract.status === 'ended_early' ? ' is-left-early' : ''}`}
    >
      <button type="button" className="csc-main" onClick={onOpen} aria-label={`ดูสัญญาห้อง ${contract.room_number}`}>
        <span className="csc-head">
          <ContractRoomBadge contract={contract} />
          <span className="csc-person">
            <strong title={tenantName}>{tenantName}</strong>
            <small>{contract.phone || '-'}</small>
          </span>
          <span className="csc-badges">
            {unviewed && <span className="csc-status is-info">ยังไม่เปิดดู</span>}
            <span className={`csc-status ${status.tone}`}>{status.label}</span>
            {underlying && <span className={`csc-status ${underlying.tone}`}>{underlying.label}</span>}
            <ContractAmendedBadge contract={contract} />
            {contract.can_settle_deposit && (
              <span className="csc-status is-deposit-alert">
                รอคืนมัดจำ
              </span>
            )}
          </span>
        </span>
        {contract.is_archived && (
          <span className="csc-archive-note">
            <span>สัญญาเก่า</span>
            {contract.has_newer_contract && <span className="is-newer">มีสัญญาใหม่แล้ว</span>}
          </span>
        )}
        <ContractTransferSummary contract={contract} />

        <span className="csc-period">
          <ContractPeriodTimeline contract={contract} now={now} />
        </span>

        <span className="csc-money">
          <span>
            <small>ค่าเช่า/เดือน</small>
            <b>{formatContractMoney(contract.monthly_price)}</b>
          </span>
          <span>
            <small>มัดจำ</small>
            <b>{formatDepositMonths(contract)}</b>
          </span>
          <span className="is-total">
            <small>เดือนแรก</small>
            <b>{formatContractMoney(contract.first_month_total)}</b>
          </span>
        </span>
        <DepositRefundNote contract={contract} compact />
      </button>

      <div className="csc-photos">
        <span className="csc-label">รูปสัญญา <b>{images.length}</b></span>
        <span className="csc-photo-row">
          {images.length === 0 ? (
            <span className="contract-cell-nophoto">ไม่มีรูปสัญญา</span>
          ) : (
            images.slice(0, STAFF_CARD_PHOTOS).map((image, index) => (
              <button
                type="button"
                key={image.url}
                className="csc-photo"
                onClick={() => setOpenIndex(index)}
                aria-label={`ดูรูปสัญญาห้อง ${contract.room_number} รูปที่ ${index + 1}`}
              >
                <UploadImage src={image.url} alt="" loading="lazy" />
                {index === STAFF_CARD_PHOTOS - 1 && extra > 0 && <span>+{extra}</span>}
              </button>
            ))
          )}
        </span>
      </div>

      <div className="csc-foot">
        <span>ทำสัญญา {formatContractDate(contract.contract_completed_at, true)}</span>
        <button type="button" className="csc-btn" onClick={onOpen}>
          ดูสัญญา
          <ContractIcon type="chevron" size={14} />
        </button>
      </div>
      {openIndex !== null && (
        <ContractLightbox
          images={images}
          index={openIndex}
          title="รูปสัญญาเช่า"
          subtitle={`ห้อง ${contract.room_number || '-'} · ${tenantName}`}
          onClose={() => setOpenIndex(null)}
        />
      )}
    </li>
  )
}

const COMPLETED_CONTRACT_SORTS = [
  { value: 'newest', label: 'ทำสัญญาล่าสุดก่อน' },
  { value: 'oldest', label: 'ทำสัญญาเก่าสุดก่อน' },
  { value: 'ending', label: 'ใกล้หมดสัญญาก่อน' },
  { value: 'room', label: 'เรียงตามเลขห้อง' },
]

const contractDayKey = (value) => {
  const date = new Date(value)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

const contractTime = (value) => (value ? new Date(value).getTime() : 0)

const COMPLETED_CONTRACT_SORTERS = {
  newest: (a, b) => contractTime(b.contract_completed_at) - contractTime(a.contract_completed_at),
  oldest: (a, b) => contractTime(a.contract_completed_at) - contractTime(b.contract_completed_at),
  ending: (a, b) =>
    (contractTime(a.current_end_date || a.rental_end_date) || Infinity) - (contractTime(b.current_end_date || b.rental_end_date) || Infinity),
  room: (a, b) => String(a.room_number || '').localeCompare(String(b.room_number || ''), 'th', { numeric: true }),
}

const DEPOSIT_VIEWS = {
  pending: { label: 'รอคืนมัดจำ', match: (contract) => contract.can_settle_deposit },
  owe: { label: 'ผู้เช่าต้องจ่ายเพิ่ม', match: (contract) => Number(contract.deposit_extra_charge) > 0 },
  settled: { label: 'คืนแล้ว', match: (contract) => Boolean(contract.deposit_settlement) },
  all: { label: 'ทั้งหมด', match: () => true },
}

const isDepositContract = (contract) => contract.can_settle_deposit || Boolean(contract.deposit_settlement)

export function StaffCompletedContracts({ Modal, Pagination, FilterPanel, pageSize = 12, onSummaryChange, mode = 'all' }) {
  const depositMode = mode === 'deposit'
  const [allContracts, setContracts] = useState([])
  const contracts = useMemo(() => (depositMode ? allContracts.filter(isDepositContract) : allContracts), [allContracts, depositMode])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState(depositMode ? 'pending' : 'all')
  const [sort, setSort] = useState('newest')
  const [scope, setScope] = useState('all')
  const [dates, setDates] = useState({ from: '', to: '' })
  const [page, setPage] = useState(1)
  const [detail, setDetail] = useState(null)
  const [detailSection, setDetailSection] = useState('all')
  const [logOpen, setLogOpen] = useState(false)
  const [reloadKey, setReloadKey] = useState(0)
  const [viewedContractIds, setViewedContractIds] = useState(readViewedContractIds)

  useEffect(() => {
    try {
      localStorage.setItem(completedContractsViewedKey(), JSON.stringify([...viewedContractIds]))
    } catch {
      return
    }
  }, [viewedContractIds])

  useEffect(() => {
    let cancelled = false
    axios
      .get('/api/staff/contracts/completed')
      .then(({ data }) => {
        if (cancelled) return
        setContracts(data.contracts || [])
        setError('')
      })
      .catch((requestError) => {
        if (!cancelled) setError(requestError.response?.data?.message || 'ไม่สามารถโหลดรายการสัญญาได้')
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [reloadKey])

  const statusCounts = useMemo(
    () =>
      contracts.reduce((counts, contract) => {
        const key = contractCardStatus(contract)
        return { ...counts, [key]: (counts[key] || 0) + 1 }
      }, {}),
    [contracts],
  )
  const unviewedCount = useMemo(
    () => contracts.filter((contract) => !viewedContractIds.has(String(contract.booking_id))).length,
    [contracts, viewedContractIds],
  )
  const openContract = (contract) => {
    setDetailSection('all')
    setDetail(contract)
    const id = String(contract.booking_id)
    setViewedContractIds((current) => current.has(id) ? current : new Set([...current, id]))
  }
  const keyword = search.trim().toLowerCase()
  const filtered = useMemo(
    () =>
      contracts
        .filter((contract) =>
          depositMode
            ? (DEPOSIT_VIEWS[status] || DEPOSIT_VIEWS.all).match(contract)
            : status === 'all' || contractCardStatus(contract) === status,
        )
        .filter((contract) =>
          scope === 'all'
            ? true
            : scope === 'deposit'
              ? contract.can_settle_deposit
              : scope === 'amended'
                ? Number(contract.amendment_count) > 0
                : (scope === 'archived') === Boolean(contract.is_archived),
        )
        .filter((contract) => {
          if (!dates.from && !dates.to) return true
          if (!contract.contract_completed_at) return false
          const key = contractDayKey(contract.contract_completed_at)
          return (!dates.from || key >= dates.from) && (!dates.to || key <= dates.to)
        })
        .filter(
          (contract) =>
            matchesSearch([
              contract.first_name,
              contract.last_name,
              `${contract.first_name} ${contract.last_name}`,
              contract.phone,
              contract.room_number,
              ...contractTransfers(contract).map((transfer) => transfer.from_room_number),
            ], keyword, contract, [
              contract.rental_start_date,
              contract.rental_end_date,
              contract.moved_out_at,
              contract.contract_completed_at,
            ]),
        )
        .sort(COMPLETED_CONTRACT_SORTERS[sort]),
    [contracts, status, scope, dates, keyword, sort, depositMode],
  )
  const archivedCount = contracts.filter((contract) => contract.is_archived).length
  const amendedCount = contracts.filter((contract) => Number(contract.amendment_count) > 0).length
  const pendingDeposits = useMemo(() => contracts.filter((contract) => contract.can_settle_deposit), [contracts])
  const pendingDepositCount = pendingDeposits.length
  const depositViewCounts = useMemo(
    () => Object.fromEntries(Object.entries(DEPOSIT_VIEWS).map(([key, view]) => [key, contracts.filter(view.match).length])),
    [contracts],
  )
  const depositSummary = useMemo(() => {
    const sum = (list, read) => list.reduce((total, contract) => total + (Number(read(contract)) || 0), 0)
    const settled = contracts.filter(DEPOSIT_VIEWS.settled.match)
    const owing = contracts.filter(DEPOSIT_VIEWS.owe.match)
    return {
      pending: pendingDepositCount,
      pendingAmount: sum(pendingDeposits, (contract) => contract.deposit_remaining ?? contract.deposit_paid),
      settled: settled.length,
      refundedAmount: sum(settled, (contract) => contract.deposit_refunded_amount),
      deducted: settled.filter((contract) => Number(contract.deposit_deduction) > 0).length,
      deductedAmount: sum(settled, (contract) => contract.deposit_deduction),
      owe: owing.length,
      oweAmount: sum(owing, (contract) => contract.deposit_extra_charge),
    }
  }, [contracts, pendingDeposits, pendingDepositCount])
  useEffect(() => {
    if (!onSummaryChange || loading) return
    if (depositMode) {
      onSummaryChange(depositSummary)
      return
    }
    onSummaryChange({
      total: contracts.length,
      active: (statusCounts.active || 0) + (statusCounts.transferred || 0),
      awaitingPayment: (statusCounts.awaiting_payment || 0) + (statusCounts.payment_review || 0),
      pendingDeposit: pendingDepositCount,
      archived: archivedCount,
      transferred: statusCounts.transferred || 0,
      endedEarly: statusCounts.ended_early || 0,
      unviewed: unviewedCount,
    })
  }, [onSummaryChange, loading, contracts.length, statusCounts, pendingDepositCount, archivedCount, unviewedCount, depositMode, depositSummary])
  const defaultStatus = depositMode ? 'pending' : 'all'
  const filtersActive = Boolean(keyword || dates.from || dates.to || status !== defaultStatus || scope !== 'all' || sort !== 'newest')
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const currentPage = Math.min(page, totalPages)
  const pageItems = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)
  const resetPage = (setter) => (value) => {
    setter(value)
    setPage(1)
  }

  return (
    <div className="staff-card staff-tab-card contract-panel">
      <div className="staff-card-header">
        <div>
          <h2>
            {depositMode ? 'จัดการเงินมัดจำ' : 'สัญญาทั้งหมด'}{' '}
            <span className="staff-count-pill">{depositMode ? pendingDepositCount : contracts.length}</span>
          </h2>
          <p className="waiting-list-storage-note">
            {depositMode
              ? 'สัญญาที่สิ้นสุดแล้วและต้องคืนเงินมัดจำ · คืนได้ทุกกรณี หักได้เฉพาะค่าเสียหายหรือยอดค้างที่มีหลักฐาน'
              : 'สัญญาเช่าที่ลงทะเบียนผู้เช่าและแนบรูปสัญญาครบแล้ว'}
          </p>
        </div>
        <button type="button" className="deposit-log-open" onClick={() => setLogOpen(true)}>
          <ContractIcon type="wallet" size={15} />
          บันทึกการจัดการเงินมัดจำ
          {pendingDepositCount > 0 && <em>{pendingDepositCount} รอจัดการ</em>}
        </button>
      </div>
      {logOpen && (
        <DepositLogModal
          pending={contracts.filter((contract) => contract.can_settle_deposit)}
          onSettled={(updated) =>
            setContracts((current) => current.map((item) => (item.booking_id === updated.booking_id ? updated : item)))
          }
          onClose={() => setLogOpen(false)}
        />
      )}
      <FilterPanel
        segments={
          depositMode
            ? Object.entries(DEPOSIT_VIEWS).map(([key, view]) => ({ key, label: `${view.label} (${depositViewCounts[key] || 0})` }))
            : [
                { key: 'all', label: 'ทั้งหมด' },
                ...Object.entries(STAFF_CARD_STATUS)
                  .filter(([key]) => statusCounts[key])
                  .map(([key, info]) => ({ key, label: info.label })),
              ]
        }
        active={status}
        onSegment={resetPage(setStatus)}
        segmentsBelow
        search={search}
        onSearch={resetPage(setSearch)}
        searchPlaceholder="ค้นหาชื่อผู้เช่า เบอร์โทร เลขห้อง หรือวันที่"
        resultText={`พบ ${filtered.length} จาก ${contracts.length} สัญญา`}
        dateRange={{ label: 'วันที่ทำสัญญา', from: dates.from, to: dates.to, onChange: resetPage(setDates) }}
        canClear={filtersActive}
        onClear={() => {
          setSearch('')
          setStatus(defaultStatus)
          setScope('all')
          setSort('newest')
          setDates({ from: '', to: '' })
          setPage(1)
        }}
      >
        {!depositMode && (
          <select className="staff-filter-select" value={scope} onChange={(event) => resetPage(setScope)(event.target.value)} aria-label="ประเภทสัญญา">
            <option value="all">ทุกสัญญา</option>
            <option value="current">สัญญาปัจจุบัน ({contracts.length - archivedCount})</option>
            <option value="archived">สัญญาเก่า ({archivedCount})</option>
            <option value="deposit">รอคืนมัดจำ ({pendingDepositCount})</option>
            <option value="amended">สัญญาที่แก้ไขแล้ว ({amendedCount})</option>
          </select>
        )}
        <select className="staff-filter-select" value={sort} onChange={(event) => resetPage(setSort)(event.target.value)} aria-label="เรียงลำดับ">
          {COMPLETED_CONTRACT_SORTS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </FilterPanel>
      {loading ? (
        <p className="staff-empty">กำลังโหลดรายการสัญญา...</p>
      ) : error ? (
        <p className="staff-empty">
          {error}{' '}
          <button type="button" className="staff-action-btn is-ghost" onClick={() => { setLoading(true); setReloadKey((key) => key + 1) }}>
            ลองใหม่
          </button>
        </p>
      ) : filtered.length === 0 ? (
        <p className="staff-empty">
          {depositMode
            ? status === 'pending' ? 'ไม่มีเงินมัดจำที่รอคืน' : 'ไม่พบรายการเงินมัดจำตามเงื่อนไขที่เลือก'
            : contracts.length ? 'ไม่พบสัญญาตามเงื่อนไขที่เลือก' : 'ยังไม่มีสัญญาในระบบ'}
        </p>
      ) : (
        <ul className="csc-grid">
          {pageItems.map((contract) => (
            <StaffContractCard
              key={contract.booking_id}
              contract={contract}
              unviewed={!depositMode && !viewedContractIds.has(String(contract.booking_id))}
              onOpen={() => openContract(contract)}
            />
          ))}
        </ul>
      )}
      {Pagination && <Pagination page={currentPage} total={filtered.length} onChange={setPage} pageSize={pageSize} />}
      {detail && Modal && (
        <Modal title={`สัญญาเช่า ห้อง ${detail.room_number || '-'}`} onClose={() => setDetail(null)} variant="wide">
          <div className="ccc-modal">
            <div className="ccc-header ccc-person-header">
              <span className="ccc-avatar" aria-hidden="true"><ContractIcon type="user" size={22} /></span>
              <div className="ccc-person">
                <h2>{detail.first_name} {detail.last_name}</h2>
                <div className="ccc-person-meta">
                  <span className="ccc-phone"><ContractIcon type="phone" size={13} />{detail.phone || '-'}</span>
                  <span className="ccc-signed">
                    <ContractIcon type="check" size={13} />
                    ทำสัญญา {formatContractDate(detail.contract_completed_at, true)}
                  </span>
                </div>
              </div>
              <span className="csc-badges">
                {detail.is_archived && <ArchivedContractBadge contract={detail} />}
                {contractCardStatus(detail) === 'transferred' && (
                  <span className="csc-status is-transferred">ย้ายห้องแล้ว</span>
                )}
                <ContractAmendedBadge contract={detail} />
                <ContractStatusBadge status={detail.status} />
              </span>
            </div>
            <ContractSectionFilter value={detailSection} onChange={setDetailSection} contract={detail} />
            {detail.is_archived && (
              <div className={`contract-refund-note is-archived${detail.has_newer_contract ? ' is-superseded' : ''}`} role="note">
                <ContractIcon type="file" size={18} />
                <span>
                  <strong>{detail.has_newer_contract ? 'สัญญาเก่า · ผู้เช่าทำสัญญาใหม่แล้ว' : 'สัญญาเก่า · สิ้นสุดแล้ว'}</strong>
                  <small className="contract-archived-meta">
                    {(detail.moved_out_at || detail.next_contract_at) && (
                      <span>
                        <ContractIcon type="calendar" size={13} />
                        สิ้นสุดเมื่อ <b>{formatContractDate(detail.moved_out_at || detail.next_contract_at)}</b>
                      </span>
                    )}
                    <span>
                      <ContractIcon type="wallet" size={13} />
                      ยอดเงินในหน้านี้เป็นของสัญญานี้เท่านั้น
                    </span>
                  </small>
                </span>
              </div>
            )}
            {detail.can_settle_deposit && (
              <DepositSettlementForm
                contract={detail}
                onSaved={(contract) => {
                  setContracts((current) => current.map((item) => (item.booking_id === contract.booking_id ? contract : item)))
                  setDetail(contract)
                }}
              />
            )}
            {!detail.is_archived && (
              <ContractAmendCard
                contract={detail}
                onSaved={(contract) => {
                  setContracts((current) => current.map((item) => (item.booking_id === contract.booking_id ? contract : item)))
                  setDetail(contract)
                }}
              />
            )}
            <CustomerContractBody contract={detail} viewer="staff" section={detailSection} />
          </div>
        </Modal>
      )}
    </div>
  )
}

function DepositContractTerms({ contract, title = 'เงื่อนไขสัญญา' }) {
  const endDate = contract.effective_end_date || contract.rental_end_date
  const leftAt = contract.moved_out_at || contract.next_contract_at || null
  const leftLabel = contract.moved_out_at ? 'ย้ายออกเมื่อ' : contract.next_contract_at ? 'ทำสัญญาใหม่เมื่อ' : 'ย้ายออกเมื่อ'
  const earlyDays = leftAt && endDate ? Math.ceil((new Date(endDate) - new Date(leftAt)) / 86400000) : 0
  return (
    <section className="deposit-settle-terms">
      <h4>
        <ContractIcon type="file" size={14} />
        {title}
      </h4>
      <dl>
        <div className="is-wide">
          <dt>ระยะสัญญา</dt>
          <dd>
            {formatContractDate(contract.rental_start_date)} ถึง {formatContractDate(endDate)}
            {contract.contract_duration_months ? <span className="is-muted">{contract.contract_duration_months} เดือน</span> : null}
          </dd>
        </div>
        <div>
          <dt>เงินมัดจำ</dt>
          <dd>
            {formatContractMoney(contract.deposit_amount)}
            <span className="is-muted">{formatDepositMonths(contract)}</span>
          </dd>
        </div>
        <div className="is-wide">
          <dt>{leftLabel}</dt>
          <dd>
            {leftAt ? (
              <>
                {formatContractDate(leftAt, true)}
                {earlyDays > 0 ? (
                  <em className="is-early">ก่อนครบสัญญา {earlyDays} วัน</em>
                ) : (
                  <em className="is-complete">อยู่ครบสัญญา</em>
                )}
              </>
            ) : (
              <>
                ไม่มีบันทึกวันย้ายออก
                <em className="is-early">{contract.is_suspended ? 'บัญชีผู้เช่าถูกระงับ' : 'ไม่ได้ผ่านคำขอย้ายออก'}</em>
              </>
            )}
          </dd>
        </div>
        {contract.moveout_damage_note && (
          <div className="is-wide">
            <dt>ผลตรวจห้อง</dt>
            <dd>
              {contract.moveout_damage_note}
              {Number(contract.moveout_damage_cost) > 0 && (
                <span className="is-muted">ค่าเสียหาย {formatContractMoney(contract.moveout_damage_cost)}</span>
              )}
            </dd>
          </div>
        )}
      </dl>
      <div className="deposit-settle-rule" role="note">
        <span className="deposit-settle-rule-icon" aria-hidden="true">
          <ContractIcon type="check" size={16} />
        </span>
        <span>
          <strong>คืนเงินมัดจำทุกกรณี</strong>
          <small>ทั้งพักครบและย้ายออกก่อนครบสัญญา · หักได้เฉพาะค่าเสียหายหรือยอดค้างชำระที่มีหลักฐาน</small>
        </span>
      </div>
    </section>
  )
}

function DepositSettlementModal({ contract, onClose, onSaved }) {
  const paid = Number(contract.deposit_remaining ?? contract.deposit_paid) || 0
  const inspectionDamage = Number(contract.moveout_damage_cost) || 0
  const collected = Number(contract.damage_charge?.paid) || 0
  const [deduction, setDeduction] = useState(inspectionDamage > 0 ? String(inspectionDamage) : '')
  const [note, setNote] = useState(inspectionDamage > 0 ? (contract.moveout_damage_note || '').slice(0, 500) : '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [invalidField, setInvalidField] = useState(null)
  const deductionRef = useRef(null)
  const noteRef = useRef(null)
  const deductionValue = Number(deduction) || 0
  const refundAmount = Math.max(0, paid - deductionValue)
  const fromDeposit = Math.min(deductionValue, paid)
  const overDeposit = Math.max(0, deductionValue - paid)
  const fromCollected = Math.min(overDeposit, collected)
  const extraAmount = overDeposit - fromCollected
  const noteRequired = deductionValue > 0

  const failField = (field, ref, message) => {
    setError(message)
    setInvalidField(field)
    ref.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    ref.current?.focus({ preventScroll: true })
  }

  const submit = async (event) => {
    event.preventDefault()
    if (!Number.isFinite(Number(deduction || 0)) || deductionValue < 0) {
      failField('deduction', deductionRef, 'จำนวนเงินที่หักต้องเป็นตัวเลขตั้งแต่ 0 ขึ้นไป')
      return
    }
    if (noteRequired && !note.trim()) {
      failField('note', noteRef, 'กรุณาระบุรายการค่าเสียหายหรือยอดค้างที่หัก')
      return
    }
    setInvalidField(null)
    setSaving(true)
    setError('')
    try {
      const { data } = await axios.post(
        `/api/staff/contracts/${contract.booking_id}/deposit-settlement`,
        { action: 'refund', deduction: deductionValue, note: note.trim() || undefined }
      )
      onSaved(data.contract)
    } catch (requestError) {
      setError(requestError.response?.data?.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่อีกครั้ง')
    } finally {
      setSaving(false)
    }
  }

  const name = `${contract.first_name || ''} ${contract.last_name || ''}`.trim()
  const statusTone = ['ended_early', 'voided'].includes(contract.status) ? 'is-warn' : 'is-ok'
  const changeDeduction = (value) => {
    setDeduction(value)
    setError('')
    setInvalidField(null)
  }
  const damageCost = Number(contract.moveout_damage_cost) || 0
  const excess = Number(contract.damage_excess) || 0
  const presets = [
    { key: 'none', label: 'ไม่หัก', value: '' },
    inspectionDamage > 0 && {
      key: 'inspection',
      label: `ตามผลตรวจห้อง ${formatContractMoney(inspectionDamage)}`,
      value: String(inspectionDamage),
    },
    inspectionDamage !== paid && paid > 0 && { key: 'deposit', label: `เท่ามัดจำ ${formatContractMoney(paid)}`, value: String(paid) },
  ].filter(Boolean)
  const charge = contract.damage_charge
  const excessState = charge?.status === 'paid' ? 'is-paid' : charge ? 'is-pending' : 'is-missing'
  const excessText = charge?.status === 'paid'
    ? `ผู้เช่าชำระส่วนเกิน ${formatContractMoney(charge.amount)} แล้ว`
    : charge
      ? `บิลส่วนเกิน ${formatContractMoney(charge.amount)} ยังไม่ได้ชำระ`
      : 'ยังไม่มีบิลส่วนเกิน · ใส่ยอดหักตามผลตรวจห้อง ระบบจะบันทึกส่วนเกินเป็นยอดที่ผู้เช่าต้องจ่ายเพิ่ม'

  return (
    <ContractDialog
      className="deposit-settle-modal"
      label="จัดการเงินมัดจำ"
      onClose={onClose}
      locked={saving}
      header={(close) => (
        <header className="rent-bill-head">
          <span className="rent-bill-icon deposit-settle-icon"><ContractIcon type="wallet" size={20} /></span>
          <div>
            <strong>จัดการเงินมัดจำ</strong>
            <small className="dsm-meta">
              <span><ContractIcon type="home" size={13} />ห้อง {contract.room_number || '-'}</span>
              {name && <span><ContractIcon type="user" size={13} />{name}</span>}
            </small>
          </div>
          <DialogCloseButton onClick={close} />
        </header>
      )}
    >
      <form className="deposit-settle" onSubmit={submit}>
        <div className="deposit-settle-body">
          <section className="dsm-hero" aria-live="polite">
            <div className="dsm-hero-main">
              <span className="dsm-eyebrow">ยอดที่คืนให้ผู้เช่า</span>
              <strong className="dsm-amount">{formatContractMoney(refundAmount)}</strong>
              <span className="dsm-calc">
                <span className="dsm-calc-chip">มัดจำคงเหลือ <b>{formatContractMoney(paid)}</b></span>
                {fromDeposit > 0 && (
                  <span className="dsm-calc-chip is-minus">− หักจากมัดจำ <b>{formatContractMoney(fromDeposit)}</b></span>
                )}
                {fromCollected > 0 && (
                  <span className="dsm-calc-chip is-paid">ใช้ส่วนเกินที่เก็บแล้ว <b>{formatContractMoney(fromCollected)}</b></span>
                )}
                {extraAmount > 0 && (
                  <span className="dsm-calc-chip is-owe">ผู้เช่าต้องจ่ายเพิ่ม <b>{formatContractMoney(extraAmount)}</b></span>
                )}
              </span>
            </div>
            <span className={`dsm-pill ${statusTone}`}>{CONTRACT_STATUS[contract.status]?.label || '-'}</span>
          </section>
          {excess > 0 && (
            <div className={`dsm-excess ${excessState}`} role="note">
              <span className="dsm-excess-icon" aria-hidden="true"><ContractIcon type="alert" size={16} /></span>
              <span className="dsm-excess-body">
                <strong>ค่าเสียหายเกินเงินมัดจำ</strong>
                <dl className="dsm-excess-rows">
                  <div>
                    <dt>ผลตรวจห้อง</dt>
                    <dd>{formatContractMoney(damageCost)}</dd>
                  </div>
                  <div>
                    <dt>มัดจำคงเหลือ</dt>
                    <dd>− {formatContractMoney(paid)}</dd>
                  </div>
                  <div className="is-total">
                    <dt>ส่วนที่เกินมัดจำ</dt>
                    <dd>{formatContractMoney(excess)}</dd>
                  </div>
                </dl>
                <em>{excessText}</em>
              </span>
            </div>
          )}
          <DepositContractTerms contract={contract} title="ข้อมูลสัญญา" />
          <section className="dsm-form">
            <h4 className="dsm-section-title">
              บันทึกการคืนเงิน
              <span>ตรวจยอดหักให้ตรงกับผลตรวจห้องก่อนยืนยัน</span>
            </h4>
            <div className={`dsm-field${invalidField === 'deduction' ? ' is-invalid' : ''}`}>
              <label htmlFor="dsm-deduction">หักค่าเสียหาย / ยอดค้าง</label>
              <div className="dsm-money">
                <span aria-hidden="true">฿</span>
                <input
                  id="dsm-deduction"
                  ref={deductionRef}
                  type="number"
                  min="0"
                  step="0.01"
                  inputMode="decimal"
                  placeholder="0"
                  value={deduction}
                  onChange={(event) => changeDeduction(event.target.value)}
                />
                <small>มัดจำ {formatContractMoney(paid)}</small>
              </div>
              {overDeposit > 0 && (
                <p className="dsm-over-note" role="status">
                  <ContractIcon type="alert" size={14} />
                  <span>
                    <b>ยอดหักเกินมัดจำ {formatContractMoney(overDeposit)}</b>
                    {fromCollected > 0 && ` · ใช้ส่วนเกินที่เก็บแล้ว ${formatContractMoney(fromCollected)}`}
                    {extraAmount > 0
                      ? ` · บันทึกเป็นยอดที่ผู้เช่าต้องจ่ายเพิ่ม ${formatContractMoney(extraAmount)}`
                      : ' · ไม่ต้องเก็บเพิ่ม'}
                  </span>
                </p>
              )}
              <div className="dsm-presets">
                {presets.map((preset) => (
                  <button
                    key={preset.key}
                    type="button"
                    className={(deduction || '') === preset.value ? 'is-active' : ''}
                    onClick={() => changeDeduction(preset.value)}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
            <div className={`dsm-field${invalidField === 'note' ? ' is-invalid' : ''}`}>
              <label htmlFor="dsm-note">
                รายการที่หัก / หมายเหตุ
                {noteRequired ? <em>จำเป็น</em> : <span>ไม่บังคับ</span>}
              </label>
              <textarea
                id="dsm-note"
                ref={noteRef}
                rows={3}
                maxLength={500}
                value={note}
                placeholder="เช่น ผนังเป็นรู 1 จุด ค่าซ่อม 500 บาท"
                onChange={(event) => {
                  setNote(event.target.value)
                  setError('')
                  setInvalidField(null)
                }}
              />
              <small className="dsm-help">
                {noteRequired ? 'ระบุรายการและจำนวนเงินที่หักให้ตรวจสอบได้' : 'ถ้าไม่หักเงิน เว้นว่างได้'}
                <b>{note.length}/500</b>
              </small>
            </div>
          </section>
        </div>
        {error && <p className="deposit-settle-error" role="alert">{error}</p>}
        <footer className="deposit-settle-foot">
          <small>บันทึกแล้วแก้ไขไม่ได้ ระบบจะเก็บไว้ในบันทึกการจัดการเงินมัดจำ</small>
          <button type="button" className="deposit-settle-cancel" onClick={onClose} disabled={saving}>ยกเลิก</button>
          <button type="submit" className="deposit-settle-submit is-refund" disabled={saving}>
            {saving
              ? 'กำลังบันทึก...'
              : refundAmount > 0
                ? `ยืนยันคืน ${formatContractMoney(refundAmount)}`
                : extraAmount > 0
                  ? `ยืนยัน · เก็บเพิ่ม ${formatContractMoney(extraAmount)}`
                  : 'ยืนยันหักเต็มมัดจำ'}
          </button>
        </footer>
      </form>
    </ContractDialog>
  )
}

export function DepositSettlementForm({ contract, onSaved }) {
  const [open, setOpen] = useState(false)
  const paid = Number(contract.deposit_remaining ?? contract.deposit_paid) || 0
  return (
    <div className="deposit-settle-card is-refund">
      <span className="deposit-settle-card-icon"><ContractIcon type="wallet" size={20} /></span>
      <div>
        <strong>ยังไม่ได้จัดการเงินมัดจำ {formatContractMoney(paid)}</strong>
        <small>
          ตามเงื่อนไข: คืนเงินมัดจำ หักได้เฉพาะค่าเสียหายหรือยอดค้างที่มีหลักฐาน
        </small>
      </div>
      <button type="button" onClick={() => setOpen(true)}>จัดการเงินมัดจำ</button>
      {open && (
        <DepositSettlementModal
          contract={contract}
          onClose={() => setOpen(false)}
          onSaved={(updated) => {
            setOpen(false)
            onSaved(updated)
          }}
        />
      )}
    </div>
  )
}

function DialogCloseButton({ onClick }) {
  return (
    <button type="button" className="rent-bill-close" onClick={onClick} aria-label="ปิด">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
        <path d="M18 6 6 18M6 6l12 12" />
      </svg>
    </button>
  )
}

function ContractDialog({ className, label, header, onClose, locked = false, children }) {
  const [closing, setClosing] = useState(false)
  const overlayRef = useRef(null)
  const requestClose = () => {
    if (!locked) setClosing(true)
  }

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key !== 'Escape' || locked) return
      const overlays = document.querySelectorAll('.rent-bill-overlay')
      if (overlays[overlays.length - 1] !== overlayRef.current) return
      event.stopImmediatePropagation()
      setClosing(true)
    }
    window.addEventListener('keydown', handleKeyDown, true)
    return () => window.removeEventListener('keydown', handleKeyDown, true)
  }, [locked])

  useEffect(() => {
    if (!closing) return undefined
    const timer = setTimeout(onClose, 110)
    return () => clearTimeout(timer)
  }, [closing, onClose])

  return createPortal(
    <div ref={overlayRef} className={`rent-bill-overlay${closing ? ' is-closing' : ''}`} onClick={requestClose} role="presentation">
      <div
        className={`rent-bill ${className}`}
        role="dialog"
        aria-modal="true"
        aria-label={label}
        onClick={(event) => event.stopPropagation()}
      >
        {header(requestClose)}
        {children}
      </div>
    </div>,
    document.body,
  )
}

const DEPOSIT_LOG_ACTION = {
  refunded: { label: 'คืนเงินมัดจำ', tone: 'is-refund' },
  forfeited: { label: 'ริบเงินมัดจำ', tone: 'is-forfeit' },
}

const PENDING_PREVIEW = 3

const DEPOSIT_LEFT_REASON = {
  moveout: 'ผู้เช่าแจ้งย้ายออก',
  suspended: 'บัญชีผู้เช่าถูกระงับ',
  new_contract: 'ผู้เช่าทำสัญญาใหม่แทนสัญญานี้',
  voided: 'สัญญาถูกยกเลิกเพราะไม่ชำระงวดแรก',
}

function DepositLogViolation({ log }) {
  const [open, setOpen] = useState(false)
  const leftAt = log.left_at ? new Date(log.left_at) : null
  const endAt = log.contract_end_date ? new Date(log.contract_end_date) : null
  const earlyDays = leftAt && endAt ? Math.ceil((endAt - leftAt) / 86400000) : null
  return (
    <div className={`deposit-log-violation${open ? ' is-open' : ''}`} role="note">
      <button type="button" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
        <strong>
          ผิดสัญญา: ย้ายออกก่อนครบสัญญา
          {earlyDays > 0 && <em>ก่อนครบ {earlyDays} วัน</em>}
        </strong>
        <span className="deposit-log-violation-toggle">
          {open ? 'ซ่อนรายละเอียด' : 'ดูรายละเอียด'}
          <ContractIcon type="chevron" size={14} />
        </span>
      </button>
      <div className="deposit-collapse" aria-hidden={!open}>
      <ul>
        <li>
          <span>ย้ายออกเมื่อ</span>
          <b>{leftAt ? formatContractDate(log.left_at) : 'ไม่มีบันทึก'}</b>
          {log.left_reason && (
            <small className={`is-${log.left_reason}`}>{DEPOSIT_LEFT_REASON[log.left_reason] || log.left_reason}</small>
          )}
        </li>
        <li>
          <span>สัญญาสิ้นสุด</span>
          <b>{endAt ? formatContractDate(log.contract_end_date) : 'ไม่มีบันทึก'}</b>
        </li>
        <li>
          <span>เงื่อนไขที่ผิด</span>
          <b>ย้ายออกก่อนครบสัญญา หอพักริบเงินมัดจำทั้งหมด</b>
        </li>
      </ul>
      </div>
    </div>
  )
}

function DepositLogModal({ contract, pending = [], onSettled, onClose }) {
  const [logs, setLogs] = useState(null)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [settling, setSettling] = useState(null)
  const [reloadKey, setReloadKey] = useState(0)
  const [tab, setTab] = useState('history')
  const [expanded, setExpanded] = useState(null)
  const pendingVisible = contract
    ? []
    : pending.filter((item) =>
        !search.trim() ||
        matchesSearch([item.room_number, item.first_name, item.last_name, item.phone], search, item),
      )
  const keyword = search.trim().toLowerCase()
  const visible = (logs ?? []).filter((log) =>
    !keyword ||
    matchesSearch([
      DEPOSIT_LOG_ACTION[log.action]?.label,
      log.note,
      log.settled_by_name,
      log.room_number,
      log.tenant_name,
      CONTRACT_STATUS[log.contract_status]?.label,
      formatContractDate(log.created_at, true),
      formatContractMoney(log.deposit_amount),
      formatContractMoney(log.refunded_amount),
      formatContractMoney(log.forfeited_amount),
    ], keyword, log),
  )

  const bookingId = contract?.booking_id ?? null
  const totals = (logs ?? []).reduce(
    (sum, log) => ({
      refunded: sum.refunded + (Number(log.refunded_amount) || 0),
      forfeited: sum.forfeited + (Number(log.forfeited_amount) || 0),
    }),
    { refunded: 0, forfeited: 0 },
  )

  useEffect(() => {
    let active = true
    const url = bookingId
      ? `/api/staff/contracts/${bookingId}/deposit-settlement-logs`
      : '/api/staff/contracts/deposit-settlement-logs'
    axios
      .get(url)
      .then(({ data }) => {
        if (active) setLogs(data.logs ?? [])
      })
      .catch((requestError) => {
        if (active) setError(requestError.response?.data?.message || 'โหลดบันทึกไม่สำเร็จ')
      })
    return () => {
      active = false
    }
  }, [bookingId, reloadKey])

  return (
    <ContractDialog
      className="deposit-log-modal"
      label="บันทึกการจัดการเงินมัดจำ"
      onClose={onClose}
      header={(close) => (
        <header className="rent-bill-head">
          <span className="rent-bill-icon"><ContractIcon type="file" size={18} /></span>
          <div>
            <strong>บันทึกการจัดการเงินมัดจำ</strong>
            <small>
              {contract
                ? `ห้อง ${contract.room_number || '-'} · ${`${contract.first_name || ''} ${contract.last_name || ''}`.trim() || '-'}`
                : `ทุกสัญญา · คืนแล้ว ${formatContractMoney(totals.refunded)} · ริบแล้ว ${formatContractMoney(totals.forfeited)}`}
            </small>
          </div>
          <DialogCloseButton onClick={close} />
        </header>
      )}
    >
      {!contract && (
        <nav className="deposit-log-tabs" role="tablist" aria-label="ส่วนของบันทึกเงินมัดจำ">
          {[
            { key: 'history', label: 'ประวัติที่บันทึกแล้ว', count: logs?.length ?? 0 },
            { key: 'pending', label: 'รอจัดการเงินมัดจำ', count: pending.length, alert: pending.length > 0 },
          ].map((item) => (
            <button
              type="button"
              role="tab"
              key={item.key}
              aria-selected={tab === item.key}
              className={`${tab === item.key ? 'is-active' : ''}${item.alert ? ' is-alert' : ''}`}
              onClick={() => setTab(item.key)}
            >
              {item.label}
              <span>{item.count}</span>
            </button>
          ))}
        </nav>
      )}
      <div className="contract-transfers-modal-search deposit-log-search">
        <input
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder={
            contract
              ? 'ค้นหาเหตุผล ผู้บันทึก วันที่ ยอดเงิน หรือ คืน/ริบ'
              : tab === 'pending'
                ? 'ค้นหาห้อง ชื่อผู้เช่า หรือเบอร์โทร'
                : 'ค้นหาห้อง ชื่อผู้เช่า เหตุผล ผู้บันทึก วันที่ หรือ คืน/ริบ'
          }
          aria-label="ค้นหาบันทึกการจัดการเงินมัดจำ"
        />
        <span>
          {tab === 'pending'
            ? `พบ ${pendingVisible.length} จาก ${pending.length} สัญญา`
            : `พบ ${visible.length} จาก ${logs?.length ?? 0} รายการ`}
        </span>
      </div>
      <div className="deposit-log-body">
        {tab === 'pending' && pendingVisible.length === 0 && (
          <p className="deposit-log-empty">{pending.length ? 'ไม่พบสัญญาที่ตรงกับคำค้นหา' : 'ไม่มีสัญญาที่รอจัดการเงินมัดจำ'}</p>
        )}
        {pendingVisible.length > 0 && (
          <section className={`deposit-pending${tab === 'pending' ? ' is-full' : ''}`}>
            <h4>
              <ContractIcon type="wallet" size={15} />
              รอจัดการเงินมัดจำ
              <span>{pendingVisible.length} สัญญา</span>
              {tab === 'history' && pendingVisible.length > PENDING_PREVIEW && (
                <button type="button" className="deposit-pending-more" onClick={() => setTab('pending')}>
                  ดูทั้งหมด {pendingVisible.length} รายการ
                </button>
              )}
            </h4>
            <ul>
              {(tab === 'pending' ? pendingVisible : pendingVisible.slice(0, PENDING_PREVIEW)).map((item) => {
                const amount = Number(item.deposit_remaining ?? item.deposit_paid) || 0
                return (
                  <li
                    key={item.booking_id}
                    className={`is-refund${expanded === item.booking_id ? ' is-open' : ''}`}
                  >
                    <div className="deposit-pending-row">
                      <button
                        type="button"
                        className="deposit-pending-toggle"
                        aria-expanded={expanded === item.booking_id}
                        onClick={() => setExpanded((current) => (current === item.booking_id ? null : item.booking_id))}
                      >
                        <span className="deposit-pending-room">ห้อง {item.room_number || '-'}</span>
                        <span className="deposit-pending-info">
                          <b>{`${item.first_name || ''} ${item.last_name || ''}`.trim() || '-'}</b>
                          <small>
                            {CONTRACT_STATUS[item.status]?.label || '-'} · ต้องคืนเงินมัดจำ
                          </small>
                        </span>
                        <strong>{formatContractMoney(amount)}</strong>
                        <span className="deposit-pending-chevron" aria-hidden="true">
                          <ContractIcon type="chevron" size={16} />
                        </span>
                      </button>
                      <button type="button" className="deposit-pending-action" onClick={() => setSettling(item)}>
                        บันทึกคืน
                      </button>
                    </div>
                    <div className="deposit-collapse" aria-hidden={expanded !== item.booking_id}>
                      <div className="deposit-pending-detail">
                        <DepositContractTerms contract={item} title="รายละเอียดและเงื่อนไขสัญญา" />
                      </div>
                    </div>
                  </li>
                )
              })}
            </ul>
          </section>
        )}
        {!contract && tab === 'history' && <h4 className="deposit-log-heading">ประวัติที่บันทึกแล้ว</h4>}
        {tab === 'pending' ? null : error ? (
          <p className="deposit-settle-error">{error}</p>
        ) : logs === null ? (
          <p className="deposit-log-empty">กำลังโหลด...</p>
        ) : logs.length === 0 ? (
          <p className="deposit-log-empty">ยังไม่มีบันทึก</p>
        ) : visible.length === 0 ? (
          <p className="deposit-log-empty">ไม่พบบันทึกที่ตรงกับคำค้นหา</p>
        ) : (
          visible.map((log) => {
            const info = DEPOSIT_LOG_ACTION[log.action] || { label: log.action, tone: '' }
            const refunded = log.action === 'refunded'
            const facts = [
              { label: 'เงินมัดจำคงเหลือ', value: formatContractMoney(log.deposit_amount), icon: 'wallet', tone: 'is-money' },
              refunded
                ? { label: 'หักค่าเสียหาย', value: formatContractMoney(log.deduction), icon: 'wallet', tone: 'is-deduct' }
                : null,
              Number(log.extra_charge) > 0
                ? { label: 'ผู้เช่าต้องจ่ายเพิ่ม', value: formatContractMoney(log.extra_charge), icon: 'alert', tone: 'is-deduct' }
                : null,
              log.contract_status
                ? {
                    label: 'สถานะสัญญา',
                    value: CONTRACT_STATUS[log.contract_status]?.label || log.contract_status,
                    icon: 'file',
                    tone: `is-status-${CONTRACT_STATUS[log.contract_status]?.tone || 'muted'}`,
                  }
                : null,
              { label: 'บันทึกโดย', value: log.settled_by_name || '-', icon: 'user', tone: 'is-staff' },
            ].filter(Boolean)
            return (
              <article key={log.id} className={`deposit-log-entry ${info.tone}`}>
                <header>
                  <div>
                    <span className="deposit-log-tags">
                      <em>{info.label}</em>
                      {!contract && (
                        <b>
                          ห้อง {log.room_number || '-'}
                          {log.tenant_name ? ` · ${log.tenant_name}` : ''}
                        </b>
                      )}
                    </span>
                    <time className="deposit-log-time" dateTime={log.created_at}>
                      <ContractIcon type="calendar" size={13} />
                      <b>{formatContractDate(log.created_at)}</b>
                      <span>
                        <ContractIcon type="clock" size={12} />
                        {new Date(log.created_at).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })} น.
                      </span>
                    </time>
                  </div>
                  <span className="deposit-log-amount">
                    <small>{refunded ? 'คืนให้ผู้เช่า' : 'ยอดที่ริบ'}</small>
                    <strong>{formatContractMoney(refunded ? log.refunded_amount : log.forfeited_amount)}</strong>
                  </span>
                </header>
                {!refunded && <DepositLogViolation log={log} />}
                <dl>
                  {facts.map((fact) => (
                    <div key={fact.label} className={fact.tone}>
                      <dt>
                        <ContractIcon type={fact.icon} size={13} />
                        {fact.label}
                      </dt>
                      <dd>{fact.value}</dd>
                    </div>
                  ))}
                </dl>
                <p className="deposit-log-note">
                  <b>{refunded ? 'หมายเหตุ' : 'เหตุผล'}</b>
                  <span>{log.note || '-'}</span>
                </p>
              </article>
            )
          })
        )}
      </div>
      {settling && (
        <DepositSettlementModal
          contract={settling}
          onClose={() => setSettling(null)}
          onSaved={(updated) => {
            setSettling(null)
            setReloadKey((key) => key + 1)
            onSettled?.(updated)
          }}
        />
      )}
    </ContractDialog>
  )
}

function DepositLogLink({ contract }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <button type="button" className="deposit-log-link" onClick={() => setOpen(true)}>
        ดูบันทึกการจัดการเงินมัดจำ
      </button>
      {open && <DepositLogModal contract={contract} onClose={() => setOpen(false)} />}
    </>
  )
}

function ContractThumb({ contract }) {
  const [openIndex, setOpenIndex] = useState(null)
  const images = contract.images || []
  if (images.length === 0) return <span className="contract-cell-nophoto">ไม่มีรูป</span>
  return (
    <>
      <button
        type="button"
        className="contract-cell-thumb"
        onClick={(event) => {
          event.stopPropagation()
          setOpenIndex(0)
        }}
        onKeyDown={(event) => event.stopPropagation()}
        aria-label={`ดูรูปสัญญาเช่า ${images.length} รูป`}
      >
        <UploadImage src={images[0].url} alt="" loading="lazy" />
        <span>{images.length} รูป</span>
      </button>
      {openIndex !== null && (
        <ContractLightbox
          images={images}
          index={openIndex}
          title="รูปสัญญาเช่า"
          subtitle={`ห้อง ${contract.room_number || '-'} · ${contract.first_name || ''} ${contract.last_name || ''}`}
          onClose={() => setOpenIndex(null)}
        />
      )}
    </>
  )
}

export function ContractFullModal({ contract, onClose, viewer = 'staff' }) {
  const [closing, setClosing] = useState(false)
  const requestClose = () => setClosing(true)

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key !== 'Escape') return
      if (document.querySelector('.photo-viewer') || document.querySelectorAll('.rent-bill-overlay').length > 1) return
      event.stopImmediatePropagation()
      setClosing(true)
    }
    window.addEventListener('keydown', handleKeyDown, true)
    return () => window.removeEventListener('keydown', handleKeyDown, true)
  }, [])

  useEffect(() => {
    if (!closing) return undefined
    const timer = setTimeout(onClose, 110)
    return () => clearTimeout(timer)
  }, [closing, onClose])

  const name = `${contract.first_name || ''} ${contract.last_name || ''}`.trim()
  return createPortal(
    <div className={`rent-bill-overlay${closing ? ' is-closing' : ''}`} onClick={requestClose} role="presentation">
      <div
        className="rent-bill contract-full-modal"
        role="dialog"
        aria-modal="true"
        aria-label="รายละเอียดสัญญาเช่า"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="rent-bill-head">
          <span className="rent-bill-icon"><ContractIcon type="file" size={18} /></span>
          <div>
            <strong>สัญญาเช่า ห้อง {contract.room_number || '-'}</strong>
            <span className="contract-transfers-modal-meta">
              {name && (
                <span>
                  <i>ผู้เช่า</i>
                  <b>{name}</b>
                </span>
              )}
              <span>
                <i>เบอร์โทร</i>
                <b>{contract.phone || '-'}</b>
              </span>
              <span>
                <i>ทำสัญญา</i>
                <b>{formatContractDate(contract.contract_completed_at || contract.created_at)}</b>
              </span>
            </span>
          </div>
          <ContractStatusBadge status={contract.status} />
          <button type="button" className="rent-bill-close" onClick={requestClose} aria-label="ปิด">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </header>
        <div className="contract-full-modal-body ccc-modal">
          <CustomerContractBody contract={contract} viewer={viewer} />
        </div>
      </div>
    </div>,
    document.body,
  )
}

const TIMELINE_THUMBS = 4

const dayKeyDate = (key) => (key ? new Date(`${key}T00:00:00`) : undefined)

function ContractTransferTimeline({ contract, viewer }) {
  const [openId, setOpenId] = useState(null)
  const [search, setSearch] = useState('')
  const [dates, setDates] = useState({ from: '', to: '' })
  const transfers = contractTransfers(contract)
  const keyword = search.trim().toLowerCase()
  const filtersActive = Boolean(keyword || dates.from || dates.to)
  if (transfers.length === 0) {
    return (
      <div className="ccc-state">
        <ContractIcon type="file" size={26} />
        <strong>ยังไม่มีประวัติการย้ายห้อง</strong>
        <span>เมื่อย้ายห้องในสัญญานี้ ประวัติจะแสดงที่นี่</span>
      </div>
    )
  }
  const allItems = transfers.map((transfer, index) => ({ transfer, order: index + 1 })).reverse()
  const items = allItems.filter(({ transfer, order }) => {
    if (dates.from || dates.to) {
      if (!transfer.transferred_at) return false
      const key = contractDayKey(transfer.transferred_at)
      if ((dates.from && key < dates.from) || (dates.to && key > dates.to)) return false
    }
    if (!keyword) return true
    return matchesSearch([
      `ครั้งที่ ${order}`,
      transfer.from_room_number,
      transfer.to_room_number,
      formatContractDate(transfer.transferred_at, true),
      formatContractMoney(transfer.from_price),
      formatContractMoney(transfer.to_price),
    ], keyword, transfer)
  })
  const lastDeposit = transfers.at(-1).deposit_after ?? Math.max(0, Number(transfers.at(-1).deposit_before) - Number(transfers.at(-1).deposit_deducted))
  return (
    <div className="ctl">
      <div className="ctl-summary">
        <div>
          <span>ห้องปัจจุบัน</span>
          <strong>{contract.current_room_number || contract.room_number || '-'}</strong>
        </div>
        <div>
          <span>ย้ายแล้ว</span>
          <strong>{transfers.length} ครั้ง</strong>
        </div>
        <div>
          <span>ค่าเช่าปัจจุบัน</span>
          <strong>{formatContractMoney(contract.monthly_price)}</strong>
        </div>
        <div>
          <span>เงินมัดจำคงเหลือ</span>
          <strong>{formatContractMoney(contract.deposit_remaining ?? lastDeposit)}</strong>
        </div>
      </div>
      <div className="ctl-toolbar">
        <input
          type="search"
          className="ctl-search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="ค้นหาเลขห้อง ราคา หรือ ครั้งที่"
          aria-label="ค้นหาประวัติการย้ายห้อง"
        />
        <div className="ctl-date-field">
          <ContractIcon type="calendar" size={14} />
          <ThaiDatePicker
            className="ctl-date-input"
            placeholder="ตั้งแต่วันที่"
            value={dates.from}
            maxDate={dayKeyDate(dates.to)}
            isClearable
            portalId="ctl-date-portal"
            onChange={(value) => setDates((current) => ({ ...current, from: value }))}
          />
          <span>ถึง</span>
          <ThaiDatePicker
            className="ctl-date-input"
            placeholder="ถึงวันที่"
            value={dates.to}
            minDate={dayKeyDate(dates.from)}
            isClearable
            portalId="ctl-date-portal"
            onChange={(value) => setDates((current) => ({ ...current, to: value }))}
          />
        </div>
        {filtersActive && (
          <button
            type="button"
            className="ctl-clear"
            onClick={() => {
              setSearch('')
              setDates({ from: '', to: '' })
            }}
          >
            ล้างตัวกรอง
          </button>
        )}
        <span className="ctl-result">พบ {items.length} จาก {allItems.length} ครั้ง</span>
      </div>
      <ol className="ctl-list">
        {items.length === 0 && <li className="ctl-empty">ไม่พบการย้ายห้องที่ตรงกับตัวกรอง</li>}
        {items.map(({ transfer, order }) => {
          const fromPrice = Number(transfer.from_price) || 0
          const toPrice = Number(transfer.to_price) || 0
          const deducted = transfer.finance ? Number(transfer.finance.damage_deduction) || 0 : Number(transfer.deposit_deducted) || 0
          const charged = Number(transfer.amount_charged) || 0
          const date = transfer.transferred_at ? new Date(transfer.transferred_at) : null
          return (
            <li key={transfer.id}>
              <span className="ctl-order">ครั้งที่ {order}</span>
              <button type="button" className="ctl-item" onClick={() => setOpenId(transfer.id)}>
                <span className="ctl-date" aria-hidden="true">
                  <b>{date ? date.toLocaleDateString('th-TH', { day: 'numeric' }) : '-'}</b>
                  <small>{date ? date.toLocaleDateString('th-TH', { month: 'short', year: '2-digit' }) : ''}</small>
                </span>
                <span className="ctl-body">
                  <span className="ctl-title">
                    ห้อง {transfer.from_room_number} <i>→</i> ห้อง {transfer.to_room_number}
                  </span>
                  <span className="ctl-facts">
                    <span className={toPrice > fromPrice ? 'is-up' : toPrice < fromPrice ? 'is-down' : ''}>
                      ค่าเช่า {formatContractMoney(fromPrice)} → {formatContractMoney(toPrice)}
                    </span>
                    <span className={deducted > 0 ? 'is-up' : 'is-down'}>
                      {transfer.finance
                        ? `มัดจำหลังย้าย ${formatContractMoney(transfer.deposit_after)}${deducted > 0 ? ` (หักค่าเสียหาย ${formatContractMoney(deducted)})` : ''}`
                        : deducted > 0 ? `หักมัดจำ ${formatContractMoney(deducted)}` : 'ไม่หักมัดจำ'}
                    </span>
                    {charged > 0 && (
                      <span className={transfer.charge_status === 'paid' ? 'is-down' : 'is-danger'}>
                        จ่ายเพิ่ม {formatContractMoney(charged)} · {TRANSFER_CHARGE_STATUS[transfer.charge_status] || 'รอชำระ'}
                      </span>
                    )}
                  </span>
                  <span className="ctl-time">ย้ายเมื่อ {formatContractDate(transfer.transferred_at, true)}</span>
                </span>
                <span className="ctl-thumbs">
                  {(transfer.new_images ?? []).length > 0 ? (
                    <>
                      <small>รูปสัญญาใหม่ {transfer.new_images.length} รูป</small>
                      <span className="ctl-thumb-row">
                        {transfer.new_images.slice(0, TIMELINE_THUMBS).map((image, index) => (
                          <span key={image.url} className="ctl-thumb">
                            <UploadImage src={image.url} alt="" loading="lazy" />
                            {index === TIMELINE_THUMBS - 1 && transfer.new_images.length > TIMELINE_THUMBS && (
                              <em>+{transfer.new_images.length - TIMELINE_THUMBS}</em>
                            )}
                          </span>
                        ))}
                      </span>
                    </>
                  ) : (
                    <small className="is-empty">ไม่มีรูปสัญญาใหม่</small>
                  )}
                </span>
                <span className="ctl-more">
                  ดูรายละเอียด
                  <ContractIcon type="chevron" size={14} />
                </span>
              </button>
            </li>
          )
        })}
      </ol>
      {openId !== null && (
        <ContractTransfersModal contract={contract} viewer={viewer} focusId={openId} onClose={() => setOpenId(null)} />
      )}
    </div>
  )
}

const CONTRACT_SECTIONS = [
  { key: 'all', label: 'ทั้งหมด', icon: 'file' },
  { key: 'overview', label: 'ภาพรวม', icon: 'home' },
  { key: 'detail', label: 'รายละเอียดสัญญา', icon: 'file' },
  { key: 'payments', label: 'ยอดชำระ', icon: 'wallet' },
  { key: 'images', label: 'รูปสัญญา', icon: 'image' },
  { key: 'history', label: 'ประวัติการย้ายห้อง', icon: 'calendar' },
  { key: 'amendments', label: 'ประวัติการแก้ไขสัญญา', icon: 'edit' },
]

function ContractSectionFilter({ value, onChange, contract }) {
  return (
    <div className="ccc-section-filter" role="group" aria-label="กรองส่วนของสัญญาเช่า">
      <span className="ccc-section-filter-label">เลือกส่วนที่ต้องการดู</span>
      <div className="ccc-section-options">
        {CONTRACT_SECTIONS.map(({ key, label, icon }) => (
          <button
            key={key}
            type="button"
            aria-pressed={value === key}
            className={value === key ? 'is-active' : ''}
            onClick={() => onChange(key)}
          >
            <ContractIcon type={icon} size={15} />
            {label}
            {key === 'images' && <em>{contract.images?.length || 0}</em>}
            {key === 'history' && <em>{contractTransfers(contract).length}</em>}
            {key === 'amendments' && <em>{Number(contract.amendment_count) || 0}</em>}
          </button>
        ))}
      </div>
    </div>
  )
}

function useDormContact() {
  const [contact, setContact] = useState(null)
  useEffect(() => {
    let cancelled = false
    axios
      .get('/api/customer/dorm-info')
      .then(({ data }) => {
        if (!cancelled) setContact({ phone: data.config?.caretaker_phone || '', dormName: data.config?.dorm_name || '' })
      })
      .catch(() => {
        if (!cancelled) setContact({ phone: '', dormName: '' })
      })
    return () => {
      cancelled = true
    }
  }, [])
  return contact
}

function ContractContactCard({ contact }) {
  if (!contact) return null
  const phone = contact.phone.trim()
  return (
    <div className="contract-contact-card" role="note">
      <span className="contract-contact-icon" aria-hidden="true"><ContractIcon type="phone" size={18} /></span>
      <span className="contract-contact-text">
        <strong>ต้องการแก้ไขสัญญา? ติดต่อเจ้าหน้าที่</strong>
        <small>
          แก้ไขได้ เช่น ชื่อ-นามสกุล หรือเอกสารสัญญาที่ชำรุด · ต้องลงนามเอกสารทั้งสองฝ่ายที่สำนักงาน
          {contact.dormName ? `${contact.dormName}` : 'หอพัก'}
        </small>
      </span>
      {phone ? (
        <a className="contract-contact-call" href={`tel:${phone.replace(/[^\d+]/g, '')}`}>
          <ContractIcon type="phone" size={15} />
          โทร {phone}
        </a>
      ) : (
        <span className="contract-contact-call is-muted">ติดต่อที่สำนักงานหอพัก</span>
      )}
    </div>
  )
}

export function CustomerContractPanel() {
  const contact = useDormContact()
  const [contract, setContract] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [section, setSection] = useState('all')

  useEffect(() => {
    let cancelled = false
    axios
      .get('/api/customer/contract')
      .then(({ data }) => {
        if (!cancelled) setContract(data.contract || null)
      })
      .catch((requestError) => {
        if (!cancelled) setError(requestError.response?.data?.message || 'ไม่สามารถโหลดข้อมูลสัญญาเช่าได้')
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <section className={`dashboard-card contract-panel contract-customer-card${section === 'all' ? ' is-all-sections' : ''}`} aria-labelledby="customer-contract-title">
      <div className="ccc-header">
        <div>
          <h2 id="customer-contract-title">สัญญาเช่าของฉัน</h2>
          <p>ข้อมูลจากวันลงทะเบียนเข้าพัก</p>
        </div>
        {contract && <ContractStatusBadge status={contract.status} />}
      </div>
      {loading || error || !contract ? (
        <div className="ccc-state">
          {loading ? (
            <span>กำลังโหลดข้อมูลสัญญาเช่า...</span>
          ) : error ? (
            <span className="is-error">{error}</span>
          ) : (
            <>
              <ContractIcon type="file" size={26} />
              <strong>ยังไม่มีข้อมูลสัญญาเช่า</strong>
              <span>
                กรุณาติดต่อเจ้าหน้าที่หากคุณลงทะเบียนเข้าพักแล้ว
                {contact?.phone ? ` · โทร ${contact.phone}` : ''}
              </span>
            </>
          )}
        </div>
      ) : (
        <>
          <ContractSectionFilter value={section} onChange={setSection} contract={contract} />
          <ContractContactCard contact={contact} />
          <div key={section} className="ccc-customer-content" role="region" aria-label="เนื้อหาสัญญาเช่า" tabIndex={0}>
            <CustomerContractBody contract={contract} viewer="customer" section={section} />
          </div>
        </>
      )}
    </section>
  )
}

function contractTimeline(contract, now) {
  const start = contract.rental_start_date ? new Date(contract.rental_start_date).getTime() : null
  const endValue = contract.current_end_date || contract.rental_end_date
  const end = endValue ? new Date(endValue).getTime() : null
  if (!start || !end || end <= start) return { percent: 0, daysLeft: null, totalDays: null, usedDays: null }
  const percent = Math.min(100, Math.max(0, ((now - start) / (end - start)) * 100))
  const totalDays = Math.max(1, Math.round((end - start) / 86400000))
  const daysLeft = Math.ceil((end - now) / 86400000)
  return { percent, daysLeft, totalDays, usedDays: Math.min(totalDays, Math.max(0, totalDays - Math.max(0, daysLeft))) }
}

function formatDaysLeft(daysLeft) {
  if (daysLeft === null) return '-'
  if (daysLeft > 0) return `${daysLeft} วัน`
  if (daysLeft === 0) return 'ครบวันนี้'
  return `ครบแล้ว (${Math.abs(daysLeft)} วันก่อน)`
}

const THIS_MONTH_STATUS = {
  paid: { label: 'ชำระแล้ว', tone: 'is-paid' },
  due: { label: 'รอชำระ', tone: 'is-due' },
  pending: { label: 'รอตรวจสลิป', tone: 'is-pending' },
  overdue: { label: 'เกินกำหนด', tone: 'is-overdue' },
}

const billDate = (value) => (value ? new Date(value).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' }) : '-')

function RentBillModal({ contract, thisMonth, onClose, viewer = 'customer' }) {
  const [closing, setClosing] = useState(false)
  const [slipOpen, setSlipOpen] = useState(false)
  const slipOpenRef = useRef(false)
  const requestClose = () => setClosing(true)

  useEffect(() => {
    slipOpenRef.current = slipOpen
  }, [slipOpen])

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key !== 'Escape' || slipOpenRef.current) return
      event.stopImmediatePropagation()
      setClosing(true)
    }
    window.addEventListener('keydown', handleKeyDown, true)
    return () => window.removeEventListener('keydown', handleKeyDown, true)
  }, [])

  useEffect(() => {
    if (!closing) return undefined
    const timer = setTimeout(onClose, 110)
    return () => clearTimeout(timer)
  }, [closing, onClose])

  const depositOpen = ['due', 'pending'].includes(thisMonth.deposit_status)
  const deposit = depositOpen ? Number(thisMonth.deposit_due) || 0 : 0
  const rentPaid = thisMonth.status === 'paid'
  const paid = rentPaid && deposit === 0
  const billStatus = rentPaid && deposit > 0 ? thisMonth.deposit_status : thisMonth.status
  const info = THIS_MONTH_STATUS[billStatus] || THIS_MONTH_STATUS.due
  const months = (thisMonth.overdue_months || 0) + 1
  const price = Number(contract.monthly_price) || 0
  const gross = rentPaid ? 0 : price * months
  const rentAmount = rentPaid ? 0 : Number(thisMonth.amount) || 0
  const amount = rentAmount + deposit
  const adjustment = Math.round((rentAmount - gross) * 100) / 100
  const depositMonths = price > 0 ? Number(contract.deposit_amount) / price : 0
  const depositLabel = Number.isInteger(depositMonths) && depositMonths > 0
    ? `เงินมัดจำ ${depositMonths} เดือน (${formatContractMoney(price)} × ${depositMonths})`
    : 'เงินมัดจำ'
  const firstBill = ['awaiting_payment', 'payment_review'].includes(contract.status)
  const contractTotal = Number(contract.contract_total) || 0
  const rentProgress = contractTotal > 0 ? Math.min(100, Math.max(0, (Number(contract.rent_paid) / contractTotal) * 100)) : 0
  const paidAmount = Number(thisMonth.last_payment?.amount) || 0
  const prepaidCredit = paid && paidAmount > 0 && paidAmount < price ? price - paidAmount : 0
  const lines = paid
    ? [
        { label: 'ค่าเช่ารอบนี้', value: formatContractMoney(price) },
        ...(prepaidCredit > 0 ? [{ label: 'หักค่าเช่าที่จ่ายล่วงหน้าไว้', value: `− ${formatContractMoney(prepaidCredit)}`, tone: 'is-paid' }] : []),
        { label: 'ชำระแล้ว', value: `− ${formatContractMoney(prepaidCredit > 0 ? paidAmount : price)}`, tone: 'is-paid' },
      ]
    : [
        ...(rentPaid
          ? [{ label: 'ค่าเช่ารอบนี้', value: 'ชำระแล้ว', tone: 'is-paid' }]
          : [{ label: months > 1 ? `ค่าเช่า ${months} เดือน (${formatContractMoney(price)} × ${months})` : firstBill ? 'ค่าเช่าเดือนแรก' : 'ค่าเช่ารอบนี้', value: formatContractMoney(gross) }]),
        ...(deposit > 0
          ? [{
              label: thisMonth.deposit_status === 'pending' ? `${depositLabel} · รอตรวจสลิป` : depositLabel,
              value: formatContractMoney(deposit),
              tone: 'is-deposit',
            }]
          : []),
        ...(adjustment < 0 ? [{ label: 'หักค่าเช่าที่จ่ายไว้แล้ว', value: `− ${formatContractMoney(-adjustment)}`, tone: 'is-paid' }] : []),
        ...(adjustment > 0 ? [{ label: 'ค่าเช่าล่วงหน้า (ทบยอด)', value: formatContractMoney(adjustment) }] : []),
      ]

  const payment = thisMonth.last_payment
  const showSlip = ['paid', 'pending'].includes(thisMonth.status)
  const slipPhotos = payment?.slip_path ? [{ name: 'สลิปค่าเช่า', url: payment.slip_path }] : []

  return createPortal(
    <div className={`rent-bill-overlay${closing ? ' is-closing' : ''}`} onClick={requestClose} role="presentation">
      <div className="rent-bill" role="dialog" aria-modal="true" aria-label="ใบแจ้งค่าเช่า" onClick={(event) => event.stopPropagation()}>
        <header className="rent-bill-head">
          <span className="rent-bill-icon"><ContractIcon type="file" size={18} /></span>
          <div>
            <strong>ใบแจ้งค่าเช่า</strong>
            <small>ห้อง {contract.current_room_number || contract.room_number || '-'} · {contract.first_name} {contract.last_name}</small>
          </div>
          <em className={`rent-bill-status ${info.tone}`}>{info.label}</em>
          <button type="button" className="rent-bill-close" onClick={requestClose} aria-label="ปิด">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </header>

        <div className="rent-bill-body">
          <div className="rent-bill-main">
          <ContractFirstPaymentNote contract={contract} viewer={viewer} />
          <DepositRefundNote contract={contract} viewer={viewer} />
          <div className="rent-bill-meta">
            <div>
              <small>รอบบิล</small>
              <b>{billDate(thisMonth.period_start)} ถึง {billDate(thisMonth.period_end)}</b>
            </div>
            <div>
              <small>{paid ? 'ชำระเมื่อ' : 'ครบกำหนด'}</small>
              <b className={paid ? '' : 'is-due'}>
                {paid ? (payment ? billDate(payment.payment_date) : 'ยอดล่วงหน้า') : billDate(thisMonth.due_date)}
              </b>
            </div>
          </div>

          <div className="rent-bill-sheet">
            <dl className="rent-bill-lines">
              {lines.map((line) => (
                <div key={line.label} className={line.tone}>
                  <dt>{line.label}</dt>
                  <dd>{line.value}</dd>
                </div>
              ))}
            </dl>
            <div className={`rent-bill-total ${info.tone}`}>
              <span>{paid ? 'ยอดคงค้าง' : 'ยอดที่ต้องชำระ'}</span>
              <strong>{formatContractMoney(amount)}</strong>
            </div>
          </div>
          <section className="rent-bill-contract" aria-label="ราคาตามสัญญา">
            <header>
              <span>สัญญาของคุณ</span>
              <small>{formatContractLength(contract)} · {contract.billing_periods || 0} รอบบิล</small>
            </header>
            <div className="rent-bill-facts">
              <div>
                <small>ช่วงสัญญา</small>
                <b>{billDate(contract.rental_start_date)} ถึง {billDate(contract.current_end_date || contract.rental_end_date)}</b>
              </div>
              <div>
                <small>ค่าห้องต่อเดือน</small>
                <b className="is-accent">{formatContractMoney(contract.monthly_price)}</b>
              </div>
            </div>
            <div className="rent-bill-progress">
              <div className="rent-bill-progress-head">
                <span>ค่าเช่าทั้งสัญญา</span>
                <b>{formatContractMoney(contract.contract_total)}</b>
              </div>
              {contract.room_transfers?.length > 0 && <small>รวมส่วนต่างจากการย้ายห้องแล้ว</small>}
              <span className="rent-bill-progress-bar" aria-hidden="true">
                <i style={{ width: `${rentProgress}%` }} />
              </span>
              <div className="rent-bill-progress-foot">
                <span className="is-paid">จ่ายแล้ว <b>{formatContractMoney(contract.rent_paid)}</b></span>
                <span className="is-left">เหลือ <b>{formatContractMoney(contract.contract_remaining)}</b>{remainingRentMonthsLabel(contract)}</span>
              </div>
            </div>
            <div className="rent-bill-deposit">
              <div>
                <small>เงินมัดจำ</small>
                <DepositSummary contract={contract} />
              </div>
              <p>แยกจากค่าเช่า ไม่นำมาหักค่าเช่า · คืนเมื่อย้ายออก หักได้เฉพาะค่าเสียหายหรือยอดค้างที่มีหลักฐาน</p>
            </div>
            {firstBill && (
              <div className="rent-bill-first">
                <span>งวดแรก (ค่าห้อง + มัดจำ)</span>
                <b>{formatContractMoney(contract.first_month_total)}</b>
              </div>
            )}
          </section>
          </div>

          <section className="rent-bill-slip">
            <header>
              <span>สลิปการชำระ</span>
              {payment && showSlip && <small>{formatContractMoney(payment.amount)} · {billDate(payment.payment_date)}</small>}
            </header>
            {showSlip && slipPhotos.length > 0 ? (
              <button type="button" className="rent-bill-slip-image" onClick={() => setSlipOpen(true)} aria-label="ดูสลิปขนาดใหญ่">
                <UploadImage src={slipPhotos[0].url} alt="สลิปการชำระค่าเช่า" />
                <span>แตะเพื่อขยาย</span>
              </button>
            ) : (
              <div className="rent-bill-slip-empty">
                <ContractIcon type="image" size={22} />
                <span>
                  {!showSlip ? 'ยังไม่มีการชำระในรอบนี้' : payment ? 'ชำระที่เคาน์เตอร์ ไม่มีสลิปแนบ' : 'ไม่มีสลิปสำหรับรอบนี้'}
                </span>
              </div>
            )}
          </section>
        </div>

        <footer className="rent-bill-foot">
          <small>
            {paid
              ? 'ชำระค่าเช่ารอบนี้ครบแล้ว'
              : firstBill
                ? 'งวดแรก = ค่าห้อง + เงินมัดจำ · เดือนถัดไปชำระเฉพาะค่าห้อง · ไม่รวมค่าน้ำค่าไฟ'
                : 'ไม่รวมค่าน้ำค่าไฟ · ชำระได้ที่หน้าแรก'}
          </small>
          <button type="button" onClick={requestClose}>ปิด</button>
        </footer>
      </div>
      {slipOpen && (
        <ContractLightbox
          images={slipPhotos}
          index={0}
          title="สลิปค่าเช่า"
          subtitle={`ห้อง ${contract.current_room_number || contract.room_number || '-'}`}
          onClose={() => setSlipOpen(false)}
        />
      )}
    </div>,
    document.body,
  )
}

function depositAdjustmentLines(contract) {
  return contractTransfers(contract).flatMap((transfer) => {
    const route = `${transfer.from_room_number} → ${transfer.to_room_number}`
    const date = formatContractDate(transfer.transferred_at)
    const finance = transfer.finance
    if (!finance) {
      return Number(transfer.deposit_deducted) > 0
        ? [{ key: `${transfer.id}-legacy`, label: `หักส่วนต่างย้ายห้อง ${route}`, date, amount: -Number(transfer.deposit_deducted) }]
        : []
    }
    return [
      { key: 'damage', label: `หักค่าเสียหายห้อง ${transfer.from_room_number}`, amount: -Number(finance.damage_deduction) },
      { key: 'topup', label: `ชำระมัดจำเพิ่ม (ย้าย ${route})`, amount: Number(finance.deposit_topup) },
      { key: 'rent', label: `เครดิตค่าเช่าที่เหลือเข้ามัดจำ (${route})`, amount: Number(finance.rent_credit_to_deposit) },
      { key: 'excess', label: 'คืนส่วนเกินเพดานมัดจำ', amount: -Number(finance.deposit_excess_refund) },
    ]
      .filter((line) => line.amount)
      .map((line) => ({ ...line, key: `${transfer.id}-${line.key}`, date }))
  })
}

function DepositDeductions({ contract }) {
  const [open, setOpen] = useState(false)
  const lines = depositAdjustmentLines(contract)
  const deducted = Number(contract.deposit_transfer_deducted) || 0
  return (
    <div className={`ccc-bill-deposit-more${open ? ' is-open' : ''}`}>
      <button type="button" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
        <span className="ccc-bill-deposit-summary">
          {deducted > 0 && (
            <span className="is-deduct">
              หักไป <b>−{formatContractMoney(deducted)}</b>
            </span>
          )}
          <span className="is-left">
            คงเหลือ <b>{formatContractMoney(contract.deposit_remaining)}</b>
          </span>
        </span>
        <span className="ccc-bill-deposit-toggle">
          {open ? 'ซ่อน' : 'ดูรายการปรับมัดจำ'}
          <ContractIcon type="chevron" size={13} />
        </span>
      </button>
      <div className="deposit-collapse" aria-hidden={!open}>
        <ul className="ccc-bill-deposit-deductions">
          <li>
            <span>เงินมัดจำที่ชำระ</span>
            <b>{formatContractMoney(contract.deposit_paid ?? contract.deposit_amount)}</b>
          </li>
          {lines.map((line) => (
            <li key={line.key} className={line.amount < 0 ? 'is-deduct' : undefined}>
              <span>
                {line.label}
                <small>{line.date}</small>
              </span>
              <b>{line.amount < 0 ? '−' : '+'}{formatContractMoney(Math.abs(line.amount))}</b>
            </li>
          ))}
          <li className="is-left">
            <span>คงเหลือ</span>
            <b>{formatContractMoney(contract.deposit_remaining)}</b>
          </li>
        </ul>
      </div>
    </div>
  )
}

function formatShortRange(from, to) {
  const format = (value) => {
    const date = value ? new Date(value) : null
    return date && !Number.isNaN(date.getTime())
      ? date.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: '2-digit' })
      : '-'
  }
  return (
    <>
      <b>{format(from)}</b> ถึง <b>{format(to)}</b>
    </>
  )
}

function ThisMonthRent({ thisMonth, contract, viewer }) {
  const [billOpen, setBillOpen] = useState(false)
  if (!thisMonth) {
    return (
      <div className="ccc-month is-none">
        <div>
          <span>ค่าเช่าเดือนนี้</span>
          <small>ไม่มีรอบบิลที่ต้องชำระ</small>
        </div>
      </div>
    )
  }
  const deposit = ['due', 'pending'].includes(thisMonth.deposit_status) ? Number(thisMonth.deposit_due) || 0 : 0
  const rentPaid = thisMonth.status === 'paid'
  const paid = rentPaid && deposit === 0
  const info = THIS_MONTH_STATUS[rentPaid && deposit > 0 ? thisMonth.deposit_status : thisMonth.status] || THIS_MONTH_STATUS.due
  const total = (rentPaid ? 0 : Number(thisMonth.amount) || 0) + deposit
  const shortDate = (value) =>
    value ? new Date(value).toLocaleDateString('th-TH', { day: 'numeric', month: 'short' }) : '-'
  return (
    <div className={`ccc-month ${info.tone}`}>
      <div className="ccc-month-top">
        <span>
          {deposit > 0 ? 'ค่าเช่า + เงินมัดจำ' : 'ค่าเช่าเดือนนี้'}
          <em>{info.label}</em>
        </span>
        <strong>{paid ? '✓' : formatContractMoney(total)}</strong>
      </div>
      <div className="ccc-month-facts">
        <div>
          <small>รอบบิล</small>
          <b>{shortDate(thisMonth.period_start)} ถึง {shortDate(thisMonth.period_end)}</b>
        </div>
        {!paid && thisMonth.due_date && (
          <div className="is-due">
            <small>ครบกำหนด</small>
            <b>{shortDate(thisMonth.due_date)}</b>
          </div>
        )}
        {!paid && thisMonth.overdue_months > 0 && (
          <div className="is-due">
            <small>ค้างรวม</small>
            <b>{thisMonth.overdue_months + 1} เดือน</b>
          </div>
        )}
        {deposit > 0 && (
          <div className="is-due">
            <small>รวมมัดจำ</small>
            <b>{formatContractMoney(deposit)}</b>
          </div>
        )}
      </div>
      <button type="button" className="ccc-month-bill" onClick={() => setBillOpen(true)}>
        <ContractIcon type="file" size={14} />
        ดูบิล
      </button>
      {billOpen && <RentBillModal contract={contract} thisMonth={thisMonth} viewer={viewer} onClose={() => setBillOpen(false)} />}
    </div>
  )
}

const TRANSFER_CHARGE_STATUS = { paid: 'ชำระแล้ว', pending: 'รอชำระ', rejected: 'รอชำระ' }
const TRANSFER_PREVIEW_COUNT = 1

function ContractTransferEntry({ transfer, order, viewer, detailed = false, depositAmount = null, focused = false }) {
  const imagesOpen = detailed
  const fromPrice = Number(transfer.from_price) || 0
  const toPrice = Number(transfer.to_price) || 0
  const diff = toPrice - fromPrice
  const periods = Number(transfer.chargeable_periods) || 0
  const totalDiff = Number(transfer.price_difference_total) || 0
  const depositBefore = Number(transfer.deposit_before) || 0
  const finance = transfer.finance
  const deducted = finance ? Number(finance.damage_deduction) || 0 : Number(transfer.deposit_deducted) || 0
  const depositAfter = transfer.deposit_after == null ? Math.max(0, depositBefore - deducted) : Number(transfer.deposit_after) || 0
  const credited = finance ? (Number(finance.total_credit) || 0) - (Number(finance.deposit_excess_refund) || 0) : 0
  const charged = Number(transfer.amount_charged) || 0
  const contractDeposit = Number(depositAmount) || 0
  const yours = viewer === 'customer' ? 'ของคุณ' : ''
  const diffText = diff === 0 ? 'เท่าเดิม' : `${diff > 0 ? '+' : '−'}${formatContractMoney(Math.abs(diff))}/เดือน`
  const tiles = [
    {
      label: 'ค่าเช่าห้องใหม่',
      value: formatContractMoney(toPrice),
      note: diff === 0 ? 'เท่าห้องเดิม' : `${diff > 0 ? 'แพงขึ้น' : 'ถูกลง'} ${formatContractMoney(Math.abs(diff))}`,
      tone: diff > 0 ? 'is-warning' : diff < 0 ? 'is-success' : '',
    },
    {
      label: `มัดจำ${yours}หลังย้าย`,
      value: formatContractMoney(depositAfter),
      note: finance
        ? [deducted > 0 && `หักค่าเสียหาย ${formatContractMoney(deducted)}`, credited > 0 && `เครดิต +${formatContractMoney(credited)}`].filter(Boolean).join(' · ') || 'โอนมัดจำครบ'
        : deducted > 0 ? `หักไป ${formatContractMoney(deducted)}` : 'ไม่ถูกหัก',
      tone: deducted > 0 ? 'is-warning' : 'is-success',
    },
    {
      label: 'ต้องจ่ายเพิ่ม',
      value: charged > 0 ? formatContractMoney(charged) : '฿0',
      note: charged > 0 ? TRANSFER_CHARGE_STATUS[transfer.charge_status] || 'รอชำระ' : 'ไม่มียอดเพิ่ม',
      tone: charged > 0 ? (transfer.charge_status === 'paid' ? 'is-success' : 'is-danger') : 'is-success',
    },
  ]
  const groups = [
    {
      title: 'ค่าเช่า',
      rows: [
        { label: 'ห้องเดิม', value: `${formatContractMoney(fromPrice)}/เดือน` },
        { label: 'ห้องใหม่', value: `${formatContractMoney(toPrice)}/เดือน`, tone: 'is-accent' },
        { label: 'ส่วนต่าง', value: diffText, tone: diff > 0 ? 'is-warning' : diff < 0 ? 'is-success' : '' },
        transfer.new_price_from && { label: 'เริ่มคิดราคาใหม่', value: `รอบ ${formatContractDate(transfer.new_price_from)}` },
      ],
    },
    {
      title: 'เงินมัดจำ',
      rows: [
        contractDeposit > 0 && { label: 'ตามสัญญา', value: formatContractMoney(contractDeposit) },
        { label: 'ก่อนย้าย', value: formatContractMoney(depositBefore) },
        { label: 'หักส่วนต่าง', value: deducted > 0 ? `− ${formatContractMoney(deducted)}` : 'ไม่หัก', tone: deducted > 0 ? 'is-warning' : 'is-success' },
        { label: 'หลังย้าย', value: formatContractMoney(depositAfter), tone: 'is-strong' },
        contractDeposit > 0 && depositAfter < contractDeposit && {
          label: 'ขาดจากที่สัญญากำหนด',
          value: formatContractMoney(contractDeposit - depositAfter),
          tone: 'is-muted',
        },
      ],
    },
    {
      title: 'ยอดชำระจากการย้าย',
      rows: [
        {
          label: 'ส่วนต่างที่ต้องชำระ',
          value: diff > 0
            ? `${formatContractMoney(totalDiff)} (${periods} รอบที่จ่ายแล้ว)`
            : diff === 0 ? 'ไม่มี · ราคาเท่าเดิม' : 'ไม่มี · ห้องใหม่ถูกกว่า',
          tone: totalDiff > 0 ? 'is-warning' : '',
        },
        totalDiff > 0 && { label: 'จ่ายด้วยเงินมัดจำ', value: formatContractMoney(deducted) },
        totalDiff > 0 && {
          label: 'เพิ่มในยอดชำระ',
          value: charged > 0 ? `${formatContractMoney(charged)} · ${TRANSFER_CHARGE_STATUS[transfer.charge_status] || 'รอชำระ'}` : 'ไม่มี',
          tone: charged > 0 ? (transfer.charge_status === 'paid' ? 'is-success' : 'is-danger') : 'is-success',
        },
        viewer !== 'customer' && transfer.approved_by_name && { label: 'อนุมัติโดย', value: transfer.approved_by_name },
      ],
    },
  ]
  return (
    <li data-transfer-id={transfer.id} className={focused ? 'is-focused' : undefined}>
      <div className="contract-transfer-route">
        <strong>
          <span className="contract-transfer-order">ครั้งที่ {order}</span>
          ห้อง {transfer.from_room_number} → ห้อง {transfer.to_room_number}
        </strong>
        <span className="contract-transfer-date">
          <ContractIcon type="calendar" size={13} />
          <span>ย้ายเมื่อ</span>
          <b>{formatContractDate(transfer.transferred_at, true)}</b>
        </span>
      </div>
      {detailed ? (
        <>
          <div className="contract-transfer-tiles">
            {tiles.map((tile) => (
              <div key={tile.label}>
                <span>{tile.label}</span>
                <strong>{tile.value}</strong>
                <small className={tile.tone}>{tile.note}</small>
              </div>
            ))}
          </div>
          {finance ? (
            <div className="contract-transfer-finance">
              <RoomTransferFinance finance={finance} fromPrice={fromPrice} toPrice={toPrice} final chargeStatus={transfer.charge_status} />
              {viewer !== 'customer' && transfer.approved_by_name && <small>อนุมัติโดย {transfer.approved_by_name}</small>}
            </div>
          ) : (
          <div className="contract-transfer-groups">
            {groups.map((group) => (
              <section key={group.title}>
                <h5>{group.title}</h5>
                <dl>
                  {group.rows.filter(Boolean).map((row) => (
                    <div key={row.label}>
                      <dt>{row.label}</dt>
                      <dd className={row.tone}>{row.value}</dd>
                    </div>
                  ))}
                </dl>
              </section>
            ))}
          </div>
          )}
        </>
      ) : (
        <dl>
          <div>
            <dt>ค่าเช่า/เดือน</dt>
            <dd>
              {formatContractMoney(fromPrice)} → <b className="is-accent">{formatContractMoney(toPrice)}</b>
            </dd>
          </div>
          {transfer.new_price_from && (
            <div>
              <dt>เริ่มคิดราคาใหม่</dt>
              <dd>รอบ {formatContractDate(transfer.new_price_from)}</dd>
            </div>
          )}
          {finance ? (
            <div>
              <dt>{finance.rent_charge_after_move ? 'ส่วนต่างค่าเช่าเดือนที่ย้ายเข้า' : `ค่าเช่า ${finance.remaining_days} วันที่เหลือ`}</dt>
              <dd className={Number(finance.rent_charge) > 0 ? 'is-warning' : Number(finance.rent_credit_to_deposit) > 0 ? 'is-success' : ''}>
                {Number(finance.rent_charge) > 0
                  ? `จ่ายเพิ่ม ${formatContractMoney(finance.rent_charge)}${finance.rent_charge_after_move ? (finance.rent_charge_status === 'paid' ? ' (ชำระแล้ว)' : ' (รอชำระ)') : ''}`
                  : Number(finance.rent_credit_to_deposit) > 0
                    ? `เครดิตเข้ามัดจำ +${formatContractMoney(finance.rent_credit_to_deposit)}`
                    : 'ไม่มีส่วนต่าง'}
              </dd>
            </div>
          ) : (
            <div>
              <dt>ส่วนต่างที่ต้องชำระ</dt>
              <dd className={totalDiff > 0 ? 'is-warning' : ''}>
                {diff > 0 ? formatContractMoney(totalDiff) : diff === 0 ? 'ราคาเท่าเดิม' : 'ห้องใหม่ถูกกว่า ไม่มีส่วนต่าง'}
              </dd>
            </div>
          )}
          <div>
            <dt>เงินมัดจำ{yours}</dt>
            <dd className="contract-transfer-deposit">
              <span className={deducted > 0 ? 'is-warning' : 'is-success'}>
                {finance
                  ? deducted > 0 ? `หักค่าเสียหาย ${formatContractMoney(deducted)}` : credited > 0 ? `เครดิต +${formatContractMoney(credited)}` : 'โอนไปห้องใหม่'
                  : deducted > 0 ? `หักส่วนต่าง ${formatContractMoney(deducted)}` : 'ไม่หักส่วนต่าง'}
              </span>
              <span className="is-strong">{finance ? 'หลังย้าย' : 'เหลือ'} {formatContractMoney(depositAfter)}</span>
            </dd>
          </div>
          {charged > 0 && (
            <div>
              <dt>เพิ่มในยอดชำระ</dt>
              <dd className={transfer.charge_status === 'paid' ? 'is-success' : 'is-danger'}>
                {formatContractMoney(charged)} · {TRANSFER_CHARGE_STATUS[transfer.charge_status] || 'รอชำระ'}
              </dd>
            </div>
          )}
        </dl>
      )}
      {transfer.new_images?.length > 0 && (
        <details className="contract-transfer-images" open={imagesOpen}>
          <summary>
            <span>รูปสัญญาใหม่หลังย้าย</span>
            <em>{transfer.new_images.length} รูป</em>
          </summary>
          <ContractGallery images={transfer.new_images} title="รูปสัญญาใหม่หลังย้ายห้อง" subtitle={`ห้อง ${transfer.to_room_number}`} />
        </details>
      )}
      {transfer.previous_images?.length > 0 && (
        <details className="contract-transfer-images is-old" open={imagesOpen}>
          <summary>
            <span>รูปสัญญาเดิมก่อนย้าย · เก็บไว้เป็นประวัติ</span>
            <em>{transfer.previous_images.length} รูป</em>
          </summary>
          <ContractGallery images={transfer.previous_images} title="รูปสัญญาเดิมก่อนย้ายห้อง" subtitle={`ห้อง ${transfer.from_room_number}`} />
        </details>
      )}
    </li>
  )
}

function ContractTransfersModal({ contract, viewer, onClose, focusId = null }) {
  const [closing, setClosing] = useState(false)
  const [search, setSearch] = useState('')
  const requestClose = () => setClosing(true)
  const transfers = contractTransfers(contract)
  const single = focusId !== null
  const keyword = search.trim().toLowerCase()
  const entries = transfers
    .map((transfer, index) => ({ transfer, order: index + 1 }))
    .reverse()
    .filter(({ transfer }) => !single || transfer.id === focusId)
    .filter(({ transfer, order }) =>
      single ||
      !keyword ||
      matchesSearch([
        `ครั้งที่ ${order}`,
        transfer.from_room_number,
        transfer.to_room_number,
        transfer.approved_by_name,
        formatContractDate(transfer.transferred_at, true),
        formatContractMoney(transfer.from_price),
        formatContractMoney(transfer.to_price),
      ], keyword, transfer),
    )

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key !== 'Escape' || document.querySelector('.photo-lightbox, .photo-viewer')) return
      event.stopImmediatePropagation()
      setClosing(true)
    }
    window.addEventListener('keydown', handleKeyDown, true)
    return () => window.removeEventListener('keydown', handleKeyDown, true)
  }, [])

  useEffect(() => {
    if (!closing) return undefined
    const timer = setTimeout(onClose, 110)
    return () => clearTimeout(timer)
  }, [closing, onClose])

  const name = `${contract.first_name || ''} ${contract.last_name || ''}`.trim()
  return createPortal(
    <div className={`rent-bill-overlay${closing ? ' is-closing' : ''}`} onClick={requestClose} role="presentation">
      <div
        className="rent-bill contract-transfers-modal"
        role="dialog"
        aria-modal="true"
        aria-label={single ? 'รายละเอียดการย้ายห้อง' : 'ประวัติการย้ายห้องทั้งหมด'}
        onClick={(event) => event.stopPropagation()}
      >
        <header className="rent-bill-head">
          <span className="rent-bill-icon"><ContractIcon type="file" size={18} /></span>
          <div>
            <strong>
              {single && entries[0]
                ? `รายละเอียดการย้ายห้อง ครั้งที่ ${entries[0].order}`
                : 'ประวัติการย้ายห้องทั้งหมด'}
            </strong>
            <span className="contract-transfers-modal-meta">
              <span>
                <i>ห้องปัจจุบัน</i>
                <b>{contract.room_number || '-'}</b>
              </span>
              {name && (
                <span>
                  <i>ผู้เช่า</i>
                  <b>{name}</b>
                </span>
              )}
              <span className="is-count">
                <i>ย้ายทั้งหมด</i>
                <b>{transfers.length} ครั้ง</b>
              </span>
            </span>
          </div>
          <button type="button" className="rent-bill-close" onClick={requestClose} aria-label="ปิด">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </header>
        {!single && (
          <div className="contract-transfers-modal-search">
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="ค้นหาเลขห้อง ผู้อนุมัติ วันที่ หรือ ครั้งที่"
              aria-label="ค้นหาประวัติการย้ายห้อง"
            />
            <span>พบ {entries.length} จาก {transfers.length} ครั้ง</span>
          </div>
        )}
        <div className="contract-transfers-modal-body contract-transfers">
          {entries.length === 0 ? (
            <p className="contract-transfers-empty">ไม่พบการย้ายห้องที่ตรงกับคำค้นหา</p>
          ) : (
            <ol>
              {entries.map(({ transfer, order }) => (
                <ContractTransferEntry
                  key={transfer.id}
                  transfer={transfer}
                  order={order}
                  viewer={viewer}
                  depositAmount={contract.deposit_amount}
                  detailed
                />
              ))}
            </ol>
          )}
        </div>
      </div>
    </div>,
    document.body,
  )
}

export function ContractTransferHistory({ contract, viewer = 'staff' }) {
  const [showAll, setShowAll] = useState(false)
  const transfers = contractTransfers(contract)
  if (transfers.length === 0) return null
  const recent = transfers
    .map((transfer, index) => ({ transfer, order: index + 1 }))
    .slice(-TRANSFER_PREVIEW_COUNT)
    .reverse()
  const hidden = transfers.length - recent.length
  return (
    <section className="contract-transfers" aria-label="ประวัติการย้ายห้อง">
      <header>
        <ContractIcon type="file" size={15} />
        <strong>การย้ายห้อง (บันทึกแนบท้ายสัญญา)</strong>
        <span className="contract-transfers-count">ย้ายแล้ว {transfers.length} ครั้ง</span>
        <button type="button" className="contract-transfers-all" onClick={() => setShowAll(true)}>
          ดูทั้งหมด
        </button>
      </header>
      <p className="contract-transfers-note">
        {viewer === 'customer'
          ? 'สัญญาฉบับที่เซ็นไว้ยังใช้ต่อ ระบบบันทึกการย้ายห้องและการเปลี่ยนค่าเช่าไว้เป็นเอกสารแนบ'
          : 'รูปสัญญาฉบับเดิมไม่ถูกแก้ไข การเปลี่ยนห้องและค่าเช่าบันทึกเป็นประวัติแนบท้ายสัญญา'}
        {hidden > 0 ? ' · แสดงเฉพาะครั้งล่าสุด' : ''}
      </p>
      <ol>
        {recent.map(({ transfer, order }) => (
          <ContractTransferEntry
            key={transfer.id}
            transfer={transfer}
            order={order}
            viewer={viewer}
            depositAmount={contract.deposit_amount}
          />
        ))}
      </ol>
      {hidden > 0 && (
        <button type="button" className="contract-transfers-more" onClick={() => setShowAll(true)}>
          ดูการย้ายก่อนหน้าอีก {hidden} ครั้ง
        </button>
      )}
      {showAll && <ContractTransfersModal contract={contract} viewer={viewer} onClose={() => setShowAll(false)} />}
    </section>
  )
}

const AMENDMENT_REASON_OPTIONS = [
  { key: 'typo', label: 'แก้ไขข้อมูลที่บันทึกผิดพลาด', hint: 'เช่น พิมพ์ชื่อ-นามสกุลผิดตอนลงทะเบียน', name: true },
  { key: 'legal_name_change', label: 'เปลี่ยนชื่อ-นามสกุลตามกฎหมาย', hint: 'ต้องมีหลักฐานการเปลี่ยนชื่อจากทางราชการ', name: true },
  { key: 'document_update', label: 'ทำเอกสารสัญญาใหม่', hint: 'ฉบับเดิมชำรุด ไม่ชัด หรือสูญหาย', name: false },
]
const AMENDMENT_REASON_LABEL = Object.fromEntries(AMENDMENT_REASON_OPTIONS.map((option) => [option.key, option.label]))
const AMENDMENT_MIN_IMAGES = ROOM_TRANSFER_MIN_CONTRACT_IMAGES
const AMENDMENT_NOTE_MIN = 10

export function ContractAmendedBadge({ contract }) {
  const count = Number(contract?.amendment_count) || 0
  if (count <= 0) return null
  return <span className="csc-status is-amended">แก้ไขแล้ว {count} ครั้ง</span>
}

function ContractAmendmentEntry({ amendment, viewer, detailed = false }) {
  const changes = amendment.changes || []
  const nameChange = changes.find((change) => change.field === 'name')
  return (
    <li className="contract-amendment-item">
      <div className="contract-transfer-route">
        <strong>
          <span className="contract-transfer-order">ครั้งที่ {amendment.version_no}</span>
          {AMENDMENT_REASON_LABEL[amendment.reason] || amendment.reason}
        </strong>
        <span className="contract-transfer-date">
          <ContractIcon type="calendar" size={13} />
          <span>แก้ไขเมื่อ</span>
          <b>{formatContractDate(amendment.created_at, true)}</b>
        </span>
      </div>
      <dl>
        <div>
          <dt>ชื่อ-นามสกุลผู้เช่า</dt>
          <dd>
            {nameChange ? (
              <>
                <span className="contract-amendment-old">{nameChange.before}</span> → <b className="is-accent">{nameChange.after}</b>
              </>
            ) : (
              'ไม่เปลี่ยน'
            )}
          </dd>
        </div>
        <div>
          <dt>รูปสัญญา</dt>
          <dd>
            {amendment.previous_images?.length || 0} รูป → <b className="is-accent">ฉบับใหม่ {amendment.new_images?.length || 0} รูป</b>
          </dd>
        </div>
        <div>
          <dt>เอกสาร</dt>
          <dd className="is-success">ลงนามทั้งสองฝ่ายแล้ว</dd>
        </div>
        <div>
          <dt>ผู้เช่ารับทราบ</dt>
          <dd className={amendment.acknowledged_at ? 'is-success' : 'is-warning'}>
            {amendment.acknowledged_at ? `รับทราบแล้ว ${formatContractDate(amendment.acknowledged_at, true)}` : 'ยังไม่รับทราบ'}
          </dd>
        </div>
        {viewer !== 'customer' && amendment.amended_by_name && (
          <div>
            <dt>แก้ไขโดย</dt>
            <dd>{amendment.amended_by_name}</dd>
          </div>
        )}
      </dl>
      <p className="contract-amendment-comment">
        <span className="contract-amendment-comment-label">
          <ContractIcon type="edit" size={13} />
          เหตุผลที่แก้ไข
        </span>
        <span className="contract-amendment-comment-text">{amendment.note}</span>
      </p>
      {amendment.new_images?.length > 0 && (
        <details className="contract-transfer-images" open>
          <summary>
            <span>รูปสัญญาฉบับแก้ไข</span>
            <em>{amendment.new_images.length} รูป</em>
          </summary>
          <ContractGallery images={amendment.new_images} title={`รูปสัญญาฉบับแก้ไขครั้งที่ ${amendment.version_no}`} />
        </details>
      )}
      {amendment.previous_images?.length > 0 && (
        <details className="contract-transfer-images is-old" open={detailed}>
          <summary>
            <span>รูปสัญญาก่อนแก้ไข · เก็บไว้เป็นประวัติ</span>
            <em>{amendment.previous_images.length} รูป</em>
          </summary>
          <ContractGallery images={amendment.previous_images} title={`รูปสัญญาก่อนแก้ไขครั้งที่ ${amendment.version_no}`} />
        </details>
      )}
    </li>
  )
}

function ContractAmendmentList({ contract, viewer }) {
  const amendments = [...(contract?.amendments || [])].reverse()
  return (
    <section className="contract-transfers contract-amendments" aria-label="ประวัติการแก้ไขสัญญา">
      <header>
        <ContractIcon type="edit" size={15} />
        <strong>ประวัติการแก้ไขสัญญา</strong>
        <span className="contract-transfers-count">แก้ไขแล้ว {amendments.length} ครั้ง</span>
      </header>
      <p className="contract-transfers-note">
        {viewer === 'customer'
          ? 'ทุกการแก้ไขทำโดยความยินยอมของทั้งสองฝ่ายและมีเอกสารลงนาม ฉบับก่อนแก้ไขยังเก็บไว้ให้ตรวจสอบได้'
          : 'แก้ได้เฉพาะชื่อผู้เช่าและรูปสัญญา ทุกครั้งมีเอกสารลงนามทั้งสองฝ่าย ฉบับก่อนแก้ไขเก็บไว้เป็นประวัติ'}
      </p>
      {amendments.length === 0 ? (
        <div className="contract-gallery-empty">
          <span className="contract-gallery-empty-icon" aria-hidden="true"><ContractIcon type="edit" size={22} /></span>
          <strong>ยังไม่มีการแก้ไขสัญญา</strong>
          <span>สัญญานี้ยังเป็นฉบับเดิมตั้งแต่ลงทะเบียน</span>
        </div>
      ) : (
        <ol>
          {amendments.map((amendment) => (
            <ContractAmendmentEntry key={amendment.id} amendment={amendment} viewer={viewer} />
          ))}
        </ol>
      )}
    </section>
  )
}

function ContractAmendmentsModal({ contract, viewer, onClose }) {
  const amendments = [...(contract.amendments || [])].reverse()
  return (
    <ContractDialog
      className="contract-transfers-modal"
      label="ประวัติการแก้ไขสัญญาทั้งหมด"
      onClose={onClose}
      header={(close) => (
        <header className="rent-bill-head">
          <span className="rent-bill-icon"><ContractIcon type="edit" size={18} /></span>
          <div>
            <strong>ประวัติการแก้ไขสัญญาทั้งหมด</strong>
            <small>ห้อง {contract.room_number || '-'} · แก้ไขแล้ว {amendments.length} ครั้ง</small>
          </div>
          <DialogCloseButton onClick={close} />
        </header>
      )}
    >
      <div className="contract-transfers-modal-body contract-transfers">
        <ol>
          {amendments.map((amendment) => (
            <ContractAmendmentEntry key={amendment.id} amendment={amendment} viewer={viewer} detailed />
          ))}
        </ol>
      </div>
    </ContractDialog>
  )
}

export function ContractAmendmentHistory({ contract, viewer = 'staff' }) {
  const [showAll, setShowAll] = useState(false)
  const amendments = contract?.amendments || []
  if (amendments.length === 0) return null
  const latest = amendments[amendments.length - 1]
  const hidden = amendments.length - 1
  return (
    <section className="contract-transfers contract-amendments" aria-label="ประวัติการแก้ไขสัญญา">
      <header>
        <ContractIcon type="edit" size={15} />
        <strong>การแก้ไขสัญญา (บันทึกแนบท้ายสัญญา)</strong>
        <span className="contract-transfers-count">แก้ไขแล้ว {amendments.length} ครั้ง</span>
        <button type="button" className="contract-transfers-all" onClick={() => setShowAll(true)}>
          ดูทั้งหมด
        </button>
      </header>
      <p className="contract-transfers-note">
        {viewer === 'customer'
          ? 'ทุกการแก้ไขทำโดยความยินยอมของทั้งสองฝ่ายและมีเอกสารลงนาม ฉบับก่อนแก้ไขยังเก็บไว้ให้ตรวจสอบได้'
          : 'แก้ได้เฉพาะชื่อผู้เช่าและรูปสัญญา ทุกครั้งมีเอกสารลงนามทั้งสองฝ่าย ฉบับก่อนแก้ไขเก็บไว้เป็นประวัติ'}
        {hidden > 0 ? ' · แสดงเฉพาะครั้งล่าสุด' : ''}
      </p>
      <ol>
        <ContractAmendmentEntry amendment={latest} viewer={viewer} />
      </ol>
      {hidden > 0 && (
        <button type="button" className="contract-transfers-more" onClick={() => setShowAll(true)}>
          ดูการแก้ไขก่อนหน้าอีก {hidden} ครั้ง
        </button>
      )}
      {showAll && <ContractAmendmentsModal contract={contract} viewer={viewer} onClose={() => setShowAll(false)} />}
    </section>
  )
}

function ContractAmendmentModal({ contract, onClose, onSaved }) {
  const [reason, setReason] = useState('')
  const [firstName, setFirstName] = useState(contract.first_name || '')
  const [lastName, setLastName] = useState(contract.last_name || '')
  const [note, setNote] = useState('')
  const [files, setFiles] = useState([])
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [invalidField, setInvalidField] = useState(null)
  const reasonRef = useRef(null)
  const nameRef = useRef(null)
  const noteRef = useRef(null)
  const imagesRef = useRef(null)
  const reasonOption = AMENDMENT_REASON_OPTIONS.find((option) => option.key === reason)
  const oldName = `${contract.first_name || ''} ${contract.last_name || ''}`.trim()
  const newName = `${firstName.trim()} ${lastName.trim()}`.trim()
  const nameChanged = firstName.trim() !== (contract.first_name || '') || lastName.trim() !== (contract.last_name || '')
  const nextVersion = (Number(contract.amendment_count) || 0) + 1
  const currentImages = contract.images?.length || 0

  const fail = (field, ref, message) => {
    setError(message)
    setInvalidField(field)
    ref.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    ref.current?.focus?.({ preventScroll: true })
  }
  const clearError = () => {
    setError('')
    setInvalidField(null)
  }

  const submit = async (event) => {
    event.preventDefault()
    if (!reasonOption) return fail('reason', reasonRef, 'กรุณาเลือกเหตุผลการแก้ไขสัญญา')
    if (!firstName.trim() || !lastName.trim()) return fail('name', nameRef, 'กรุณากรอกชื่อและนามสกุลให้ครบ')
    if (reasonOption.name && !nameChanged) return fail('name', nameRef, 'เหตุผลที่เลือกเป็นการแก้ชื่อ แต่ชื่อ-นามสกุลยังเหมือนเดิม')
    if (note.trim().length < AMENDMENT_NOTE_MIN) {
      return fail('note', noteRef, `กรุณาอธิบายเหตุผลที่แก้ไขสัญญาอย่างน้อย ${AMENDMENT_NOTE_MIN} ตัวอักษร`)
    }
    if (files.length < AMENDMENT_MIN_IMAGES) {
      return fail('images', imagesRef, `กรุณาแนบรูปสัญญาฉบับแก้ไขที่ลงนามทั้งสองฝ่ายอย่างน้อย ${AMENDMENT_MIN_IMAGES} รูป`)
    }
    clearError()
    setSaving(true)
    try {
      const form = new FormData()
      form.append('reason', reason)
      form.append('note', note.trim())
      form.append('first_name', firstName.trim())
      form.append('last_name', lastName.trim())
      files.forEach((file) => form.append('contract_images', file))
      const { data } = await axios.post(`/api/staff/contracts/${contract.booking_id}/amendments`, form)
      onSaved(data.contract)
    } catch (requestError) {
      setError(requestError.response?.data?.message || 'แก้ไขสัญญาไม่สำเร็จ กรุณาลองใหม่อีกครั้ง')
    } finally {
      setSaving(false)
    }
    return undefined
  }

  return (
    <ContractDialog
      className="deposit-settle-modal contract-amend-modal"
      label="แก้ไขสัญญา"
      onClose={onClose}
      locked={saving}
      header={(close) => (
        <header className="rent-bill-head">
          <span className="rent-bill-icon deposit-settle-icon"><ContractIcon type="edit" size={20} /></span>
          <div>
            <strong>แก้ไขสัญญา · ฉบับแก้ไขครั้งที่ {nextVersion}</strong>
            <small className="dsm-meta">
              <span><ContractIcon type="home" size={13} />ห้อง {contract.room_number || '-'}</span>
              {oldName && <span><ContractIcon type="user" size={13} />{oldName}</span>}
            </small>
          </div>
          <DialogCloseButton onClick={close} />
        </header>
      )}
    >
      <form className="deposit-settle" onSubmit={submit}>
        <div className="deposit-settle-body">
          <div className="dsm-amend-law" role="note">
            <span className="dsm-amend-law-icon" aria-hidden="true"><ContractIcon type="alert" size={16} /></span>
            <span>
              <strong>แก้ไขสัญญาตามกฎหมาย</strong>
              <ul>
                <li>ต้องได้รับความยินยอมจาก<b>ทั้งสองฝ่าย</b>และมีเอกสารลงนามเป็นลายลักษณ์อักษร</li>
                <li>แก้ได้เฉพาะ<b>ชื่อผู้เช่า</b>และ<b>รูปสัญญา</b> · ค่าเช่า มัดจำ ระยะเวลา และห้อง แก้ที่นี่ไม่ได้ (ใช้ต่อสัญญาหรือย้ายห้อง)</li>
                <li>ระบบเก็บสัญญาฉบับก่อนแก้ไขไว้เป็นประวัติ และแจ้งผู้เช่าทุกครั้ง</li>
              </ul>
            </span>
          </div>

          <section className="dsm-form">
            <h4 className="dsm-section-title">
              เหตุผลการแก้ไข
              <span>เลือก 1 ข้อ</span>
            </h4>
            <div ref={reasonRef} tabIndex={-1} className={`dsm-reasons${invalidField === 'reason' ? ' is-invalid' : ''}`} role="radiogroup" aria-label="เหตุผลการแก้ไข">
              {AMENDMENT_REASON_OPTIONS.map((option) => (
                <button
                  key={option.key}
                  type="button"
                  role="radio"
                  aria-checked={reason === option.key}
                  className={reason === option.key ? 'is-active' : ''}
                  onClick={() => {
                    setReason(option.key)
                    clearError()
                  }}
                >
                  {option.label}
                </button>
              ))}
            </div>
            {reasonOption && <small className="dsm-reason-hint">{reasonOption.hint}</small>}
            <div className={`dsm-field${invalidField === 'name' ? ' is-invalid' : ''}`}>
              <label htmlFor="amend-first-name">
                ชื่อ-นามสกุลผู้เช่า
                {reasonOption?.name ? <em>แก้ไขชื่อ</em> : <span>ไม่บังคับ</span>}
              </label>
              <div className="dsm-name-row">
                <input
                  id="amend-first-name"
                  ref={nameRef}
                  className="dsm-text"
                  value={firstName}
                  maxLength={100}
                  placeholder="ชื่อ"
                  onChange={(event) => {
                    setFirstName(event.target.value)
                    clearError()
                  }}
                />
                <input
                  className="dsm-text"
                  value={lastName}
                  maxLength={100}
                  placeholder="นามสกุล"
                  aria-label="นามสกุล"
                  onChange={(event) => {
                    setLastName(event.target.value)
                    clearError()
                  }}
                />
              </div>
            </div>
            <div className={`dsm-field${invalidField === 'note' ? ' is-invalid' : ''}`}>
              <label htmlFor="amend-note">
                คอมเมนต์เหตุผลที่แก้ไข
                <em>จำเป็น</em>
              </label>
              <textarea
                id="amend-note"
                ref={noteRef}
                rows={3}
                maxLength={500}
                value={note}
                placeholder="เช่น ผู้เช่าเปลี่ยนนามสกุลหลังแต่งงาน แนบใบเปลี่ยนชื่อสกุล (ช.3) และลงนามบันทึกแก้ไขสัญญาแล้ว"
                onChange={(event) => {
                  setNote(event.target.value)
                  clearError()
                }}
              />
              <small className="dsm-help">
                {note.trim().length < AMENDMENT_NOTE_MIN ? `อย่างน้อย ${AMENDMENT_NOTE_MIN} ตัวอักษร · ผู้เช่าจะเห็นเหตุผลนี้` : 'ผู้เช่าจะเห็นเหตุผลนี้ในประวัติสัญญา'}
                <b>{note.length}/500</b>
              </small>
            </div>
          </section>

          <section className={`dsm-form${invalidField === 'images' ? ' is-invalid' : ''}`} ref={imagesRef} tabIndex={-1}>
            <h4 className="dsm-section-title">
              รูปสัญญาฉบับแก้ไข
              <span>ลงนามทั้งสองฝ่าย อย่างน้อย {AMENDMENT_MIN_IMAGES} รูป</span>
            </h4>
            <ContractImagePicker
              files={files}
              min={AMENDMENT_MIN_IMAGES}
              onChange={(next) => {
                setFiles(next)
                clearError()
              }}
              error={invalidField === 'images' ? error : ''}
            />
          </section>

          <section className="dsm-changes" aria-live="polite">
            <h4 className="dsm-section-title">สรุปสิ่งที่จะเปลี่ยน</h4>
            <dl>
              <div>
                <dt>ชื่อผู้เช่า</dt>
                <dd>
                  {nameChanged ? (
                    <>
                      <span className="is-before">{oldName}</span>
                      <span className="is-arrow" aria-hidden="true">→</span>
                      <span className="is-after">{newName || '-'}</span>
                    </>
                  ) : (
                    <span className="is-same">ไม่เปลี่ยน</span>
                  )}
                </dd>
              </div>
              <div>
                <dt>รูปสัญญา</dt>
                <dd>
                  <span className="is-before">ฉบับเดิม {currentImages} รูป</span>
                  <span className="is-arrow" aria-hidden="true">→</span>
                  <span className="is-after">ฉบับใหม่ {files.length} รูป</span>
                </dd>
              </div>
              <div>
                <dt>ฉบับก่อนแก้ไข</dt>
                <dd><span className="is-same">เก็บไว้เป็นประวัติ ดูได้ทั้งเจ้าหน้าที่และผู้เช่า</span></dd>
              </div>
            </dl>
          </section>
        </div>
        {error && invalidField !== 'images' && <p className="deposit-settle-error" role="alert">{error}</p>}
        <footer className="deposit-settle-foot">
          <small>บันทึกแล้วแก้ย้อนไม่ได้ ต้องแก้เป็นฉบับใหม่อีกครั้ง</small>
          <button type="button" className="deposit-settle-cancel" onClick={onClose} disabled={saving}>ยกเลิก</button>
          <button type="submit" className="deposit-settle-submit is-refund" disabled={saving}>
            {saving ? 'กำลังบันทึก...' : `บันทึกฉบับแก้ไขครั้งที่ ${nextVersion}`}
          </button>
        </footer>
      </form>
    </ContractDialog>
  )
}

export function ContractAmendmentNotice({ disabled = false }) {
  const [amendments, setAmendments] = useState([])
  const [roomNumber, setRoomNumber] = useState(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    let cancelled = false
    axios
      .get('/api/customer/contract')
      .then(({ data }) => {
        if (cancelled) return
        const pending = (data.contract?.amendments || []).filter((amendment) => !amendment.acknowledged_at)
        setAmendments(pending.reverse())
        setRoomNumber(data.contract?.room_number ?? null)
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [])

  if (disabled || dismissed || amendments.length === 0) return null
  const latest = amendments[0]

  const acknowledge = async () => {
    setBusy(true)
    setError('')
    try {
      await axios.post('/api/customer/contract/amendments/acknowledge', null)
      setDismissed(true)
    } catch (requestError) {
      setError(requestError.response?.data?.message || 'บันทึกการรับทราบไม่สำเร็จ กรุณาลองใหม่อีกครั้ง')
    } finally {
      setBusy(false)
    }
  }

  return (
    <ContractDialog
      className="deposit-settle-modal contract-amend-notice"
      label="แจ้งการแก้ไขสัญญาเช่า"
      onClose={() => setDismissed(true)}
      locked={busy}
      header={(close) => (
        <header className="rent-bill-head">
          <span className="rent-bill-icon deposit-settle-icon"><ContractIcon type="edit" size={20} /></span>
          <div>
            <strong>สัญญาเช่าของคุณถูกแก้ไข</strong>
            <small className="dsm-meta">
              {roomNumber && <span><ContractIcon type="home" size={13} />ห้อง {roomNumber}</span>}
              <span><ContractIcon type="file" size={13} />{amendments.length > 1 ? `มีการแก้ไข ${amendments.length} ครั้งที่ยังไม่รับทราบ` : `ฉบับแก้ไขครั้งที่ ${latest.version_no}`}</span>
            </small>
          </div>
          <DialogCloseButton onClick={close} />
        </header>
      )}
    >
      <div className="deposit-settle">
        <div className="deposit-settle-body">
          <div className="deposit-settle-rule" role="note">
            <span className="deposit-settle-rule-icon" aria-hidden="true"><ContractIcon type="check" size={16} /></span>
            <span>
              <strong>แก้ไขโดยความยินยอมของทั้งสองฝ่าย</strong>
              <small>มีเอกสารลงนามแนบไว้ทุกครั้ง ฉบับก่อนแก้ไขยังเก็บไว้ ดูย้อนหลังได้ที่เมนูสัญญาเช่า → ประวัติการแก้ไขสัญญา</small>
            </span>
          </div>
          <section className="contract-transfers contract-amendments">
            <ol>
              {amendments.map((amendment) => (
                <ContractAmendmentEntry key={amendment.id} amendment={amendment} viewer="customer" />
              ))}
            </ol>
          </section>
        </div>
        {error && <p className="deposit-settle-error" role="alert">{error}</p>}
        <footer className="deposit-settle-foot">
          <small>กดรับทราบเพื่อยืนยันว่าคุณได้อ่านการแก้ไขสัญญานี้แล้ว</small>
          <button type="button" className="deposit-settle-cancel" onClick={() => setDismissed(true)} disabled={busy}>ไว้ทีหลัง</button>
          <button type="button" className="deposit-settle-submit is-refund" onClick={acknowledge} disabled={busy}>
            {busy ? 'กำลังบันทึก...' : 'รับทราบการแก้ไข'}
          </button>
        </footer>
      </div>
    </ContractDialog>
  )
}

export function ContractAmendCard({ contract, onSaved }) {
  const [open, setOpen] = useState(false)
  if (!contract || contract.is_archived) return null
  return (
    <div className="contract-amend-card">
      <span className="contract-amend-card-icon"><ContractIcon type="edit" size={18} /></span>
      <div>
        <strong>แก้ไขสัญญา</strong>
        <small>แก้ชื่อผู้เช่าหรือรูปสัญญา · ต้องมีเอกสารลงนามทั้งสองฝ่าย · ฉบับเดิมเก็บไว้เป็นประวัติ</small>
      </div>
      <button type="button" onClick={() => setOpen(true)}>แก้ไขสัญญา</button>
      {open && (
        <ContractAmendmentModal
          contract={contract}
          onClose={() => setOpen(false)}
          onSaved={(updated) => {
            setOpen(false)
            onSaved(updated)
          }}
        />
      )}
    </div>
  )
}

const SUMMARY_CARD_ICONS = {
  wallet: <><rect x="3" y="6" width="18" height="13" rx="2.5" /><path d="M3 10h18M16 14.5h2" /></>,
  home: <><path d="M4 11l8-6 8 6" /><path d="M6 10v9h12v-9" /><path d="M10 19v-5h4v5" /></>,
  receipt: <><path d="M6 3h12v18l-3-2-3 2-3-2-3 2z" /><path d="M9 8h6M9 12h6" /></>,
  calendar: <><rect x="4" y="5" width="16" height="15" rx="2.5" /><path d="M4 10h16M9 3v4M15 3v4" /></>,
}

function ContractSummaryCards({ contract, daysLeft, payments = false }) {
  const depositPaid = Number(contract.deposit_paid) || 0
  const depositLeft = contract.deposit_remaining != null ? Number(contract.deposit_remaining) : depositPaid
  const deducted = Number(contract.deposit_transfer_deducted) || 0
  const hasDeposit = Number(contract.deposit_amount) > 0
  const originalPrice = Number(contract.original_monthly_price) || 0
  const priceChanged = originalPrice > 0 && originalPrice !== Number(contract.monthly_price)
  const endDate = contract.effective_end_date || contract.current_end_date || contract.rental_end_date
  const overviewCards = [
    {
      key: 'deposit',
      icon: 'wallet',
      tone: 'blue',
      label: 'เงินมัดจำคงเหลือ',
      value: hasDeposit ? formatContractMoney(depositLeft) : 'ไม่มีมัดจำ',
      hint: !hasDeposit
        ? null
        : deducted > 0
          ? `จ่ายไว้ ${formatContractMoney(depositPaid)} · หักไป ${formatContractMoney(deducted)}`
          : `${formatDepositMonths(contract)} · ${DEPOSIT_STATUS_LABEL[contract.deposit_status] || 'คืนเมื่อย้ายออก'}`,
    },
    {
      key: 'rent',
      icon: 'home',
      tone: 'green',
      label: 'ค่าห้องตามสัญญา',
      value: formatContractMoney(contract.monthly_price),
      unit: '/เดือน',
      hint: priceChanged ? `ห้อง ${contract.room_number} · เดิม ${formatContractMoney(originalPrice)}/เดือน` : `ห้อง ${contract.room_number || '-'}`,
    },
    {
      key: 'total',
      icon: 'receipt',
      tone: 'violet',
      label: 'ยอดค่าเช่าตลอดสัญญา',
      value: formatContractMoney(contract.contract_total),
      hint: `ชำระแล้ว ${formatContractMoney(contract.rent_paid)}`,
    },
    {
      key: 'days',
      icon: 'calendar',
      tone: daysLeft !== null && daysLeft <= 30 ? 'amber' : 'teal',
      label: 'สัญญาเหลืออีก',
      value: formatDaysLeft(daysLeft),
      hint: endDate ? `สิ้นสุด ${formatContractDate(endDate)}` : null,
    },
  ]
  const remainingRent = Math.max(0, Number(contract.contract_remaining ?? (Number(contract.contract_total || 0) - Number(contract.rent_paid || 0))))
  const cards = payments ? [
    {
      key: 'total', icon: 'receipt', tone: 'violet',
      label: 'ยอดค่าเช่าตลอดสัญญา',
      value: formatContractMoney(contract.contract_total),
      hint: `${contract.billing_periods || 0} รอบบิล · ไม่รวมเงินมัดจำ`,
    },
    {
      key: 'paid', icon: 'wallet', tone: 'green',
      label: 'ค่าเช่าที่ชำระแล้ว',
      value: formatContractMoney(contract.rent_paid),
      hint: 'ยอดค่าเช่าที่รับชำระแล้วตามสัญญา',
    },
    {
      key: 'remaining', icon: 'receipt', tone: remainingRent > 0 ? 'amber' : 'teal',
      label: 'ค่าเช่าคงเหลือตามสัญญา',
      value: formatContractMoney(remainingRent),
      hint: remainingRent > 0 ? 'รวมงวดถัดไป ยังไม่ใช่ยอดค้างชำระ' : 'ชำระค่าเช่าครบตามสัญญาแล้ว',
    },
    overviewCards[0],
  ] : overviewCards

  return (
    <div className="ccc-summary">
      {cards.map((card) => (
        <div key={card.key} className={`ccc-summary-card is-${card.tone}${card.key === 'deposit' ? ' is-primary' : ''}`}>
          <span className="ccc-summary-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
              {SUMMARY_CARD_ICONS[card.icon]}
            </svg>
          </span>
          <span className="ccc-summary-text">
            <small>{card.label}</small>
            <strong>
              {card.value}
              {card.unit && <em>{card.unit}</em>}
            </strong>
            {card.hint && <span>{card.hint}</span>}
          </span>
        </div>
      ))}
    </div>
  )
}

function CustomerContractBody({ contract, viewer = 'customer', section = 'all' }) {
  const [now] = useState(() => Date.now())
  const { daysLeft, totalDays, usedDays } = contractTimeline(contract, now)
  const extended = contract.current_end_date && new Date(contract.current_end_date).getTime() !== new Date(contract.rental_end_date).getTime()
  const images = contract.images || []
  const transferred = (contract.room_transfers?.length ?? 0) > 0
  const rows = [
    { label: 'ผู้เช่า', value: `${contract.first_name} ${contract.last_name}` },
    { label: 'ระยะสัญญา', value: formatContractLength(contract) },
    { label: 'เริ่มสัญญา', value: formatContractDate(contract.rental_start_date, true), tone: 'is-date-start' },
    {
      label: 'สิ้นสุดสัญญา',
      value: formatContractDate(contract.rental_end_date, true),
      tone: extended ? 'is-date-old' : 'is-date-end',
    },
    ...(extended ? [{ label: 'ต่อสัญญาถึง', value: formatContractDate(contract.current_end_date, true), tone: 'is-date-renew' }] : []),
    { label: 'ระยะเวลาทั้งหมด', value: totalDays === null ? '-' : `${totalDays} วัน` },
    { label: 'ผ่านไปแล้ว', value: usedDays === null ? '-' : `${usedDays} วัน` },
    { label: 'เหลืออีก', value: formatDaysLeft(daysLeft), tone: daysLeft !== null && daysLeft <= 30 ? 'is-warning' : 'is-accent' },
    { label: 'ค่าเช่า/เดือน', value: formatContractMoney(contract.monthly_price), tone: transferred ? 'is-accent' : undefined },
    {
      label: 'เงินมัดจำ',
      value: <DepositSummary contract={contract} />,
    },
    ...(contract.deposit_transfer_adjusted || Number(contract.deposit_transfer_deducted) > 0
      ? [
          ...(Number(contract.deposit_transfer_deducted) > 0
            ? [{ label: 'หักจากมัดจำตอนย้ายห้อง', value: `− ${formatContractMoney(contract.deposit_transfer_deducted)}`, tone: 'is-warning' }]
            : []),
          { label: 'มัดจำคงเหลือ', value: formatContractMoney(contract.deposit_remaining), tone: 'is-accent' },
        ]
      : []),
    { label: 'ชำระเดือนแรก', value: formatContractMoney(contract.first_month_total), tone: 'is-accent' },
    {
      label: 'สถานะสัญญา',
      value: (CONTRACT_STATUS[contract.status] || CONTRACT_STATUS.active).label,
      tone: contract.status === 'active' ? 'is-accent' : ['awaiting_payment', 'payment_review'].includes(contract.status) ? 'is-warning' : undefined,
    },
  ]
  const depositStatus = contract.deposit_status
  const depositStatusLabel = DEPOSIT_STATUS_LABEL[depositStatus]
  const showOverview = section === 'all' || section === 'overview'
  const showDetails = section === 'all' || section === 'detail'
  const showPayments = section === 'all' || section === 'payments'
  const showImages = section === 'all' || section === 'images'

  if (section === 'history') return <ContractTransferTimeline contract={contract} viewer={viewer} />
  if (section === 'amendments') return <ContractAmendmentList contract={contract} viewer={viewer} />

  return (
    <>
      {showOverview && <>
      <div className="ccc-hero">
        <ContractRoomBadge contract={contract} size="hero" />
        <div className="ccc-period csc-period">
          <ContractPeriodTimeline
            contract={contract}
            now={now}
            endLabel={extended ? 'ต่อสัญญาถึง' : 'สิ้นสุด'}
            endValue={contract.current_end_date || contract.rental_end_date}
          />
        </div>
      </div>

      </>}

      {(showOverview || section === 'payments') && <ContractSummaryCards contract={contract} daysLeft={daysLeft} payments={section === 'payments'} />}

      {(showDetails || showPayments || showImages) && <div className={`ccc-grid${section !== 'all' ? ' ccc-grid-filtered' : ''}`}>
        {(showDetails || showPayments) && <div className="ccc-pane">
          {showDetails && <>
          <h3>รายละเอียดสัญญา</h3>
          <ContractFirstPaymentNote contract={contract} viewer={viewer} />
          <DepositRefundNote contract={contract} viewer={viewer} />
          {viewer === 'customer' && <DepositEarlyLeaveWarning contract={contract} />}
          <ContractMonthTrack
            start={contract.rental_start_date}
            end={contract.effective_end_date || contract.current_end_date || contract.rental_end_date}
            originalEnd={extended ? contract.rental_end_date : null}
            now={now}
          />
          <dl className="ccc-rows">
            {rows.map((row) => (
              <div key={row.label} className={row.tone}>
                <dt>{row.label}</dt>
                <dd>{row.value}</dd>
              </div>
            ))}
          </dl>
          </>}
          {section === 'all' && <ContractAmendmentHistory contract={contract} viewer={viewer} />}
          {section === 'all' && <ContractTransferHistory contract={contract} viewer={viewer} />}
          {showPayments && <div className={`ccc-bill${section === 'payments' ? ' ccc-bill-focused' : ''}`}>
            <h3>
              ยอดตามสัญญารวมทุกเดือน
              <span>{contract.billing_periods || 0} รอบบิล</span>
            </h3>
            <div className="ccc-bill-period">
              <span className="ccc-bill-period-icon"><ContractIcon type="calendar" size={18} /></span>
              <span className="ccc-bill-period-text">
                <small>ช่วงเวลาค่าเช่าตามสัญญา</small>
                <span>{formatShortRange(contract.rental_start_date, contract.effective_end_date)}</span>
              </span>
              <em>{contract.billing_periods || 0} เดือน</em>
            </div>
            {transferred && contract.rent_breakdown?.length ? (
              <>
                {contract.rent_breakdown.map((line, index) => (
                  <div key={index} className="ccc-bill-rent-row">
                    <span className="ccc-bill-line">
                      {line.kind === 'difference' ? (
                        `ส่วนต่างย้ายห้อง ${line.from_room_number} → ${line.room_number}`
                      ) : (
                        <>
                          <span className="ccc-bill-rent-dates">{formatShortRange(line.from_date, line.to_date)}</span>
                          <span className="ccc-bill-rent-meta">
                            <i>ห้อง {line.room_number}</i>
                            <small>{formatContractMoney(line.price)} × {line.periods || 1} เดือน</small>
                          </span>
                        </>
                      )}
                    </span>
                    <strong>{formatContractMoney(line.amount)}</strong>
                  </div>
                ))}
                <div className="ccc-bill-sum">
                  <span>รวมค่าเช่าตามสัญญา</span>
                  <strong>{formatContractMoney(contract.contract_total)}</strong>
                </div>
              </>
            ) : (
              <div className="ccc-bill-rent-row">
                <span className="ccc-bill-line">
                  <span className="ccc-bill-rent-dates">ค่าเช่าตามสัญญา</span>
                  <span className="ccc-bill-rent-meta">
                    <i>ห้อง {contract.room_number || '-'}</i>
                    <small>{formatContractMoney(contract.monthly_price)} × {contract.billing_periods || 0} เดือน</small>
                  </span>
                </span>
                <strong>{formatContractMoney(contract.contract_total)}</strong>
              </div>
            )}
            <div className="is-paid">
              <span>ชำระแล้ว</span>
              <strong>− {formatContractMoney(contract.rent_paid)}</strong>
            </div>
            {Number(contract.deposit_amount) > 0 && (
              <div className={`ccc-bill-deposit is-${depositStatus || 'none'}`}>
                <div className="ccc-bill-deposit-main">
                  <span>
                    เงินมัดจำ {formatDepositMonths(contract)}
                    {depositStatusLabel && <em>{depositStatusLabel}</em>}
                  </span>
                  <strong>
                    {formatContractMoney(
                      Number(contract.deposit_paid) > 0 ? contract.deposit_paid : contract.deposit_amount,
                    )}
                  </strong>
                </div>
                {(contract.deposit_transfer_adjusted || Number(contract.deposit_transfer_deducted) > 0) && <DepositDeductions contract={contract} />}
              </div>
            )}
            <ThisMonthRent thisMonth={contract.this_month ?? null} contract={contract} viewer={viewer} />
            <p>เงินมัดจำ {formatDepositMonths(contract)} {formatContractMoney(contract.deposit_amount || 0)} ชำระพร้อมค่าห้องเดือนแรก · เดือนแรก {formatContractMoney(contract.first_month_total)}</p>
          </div>}
        </div>}
        {showImages && <div className="ccc-pane ccc-gallery-pane">
          <h3>
            รูปสัญญา
            <span>{images.length} รูป</span>
          </h3>
          <div className="ccc-gallery-scroll">
            <ContractGallery images={images} subtitle={`ห้อง ${contract.room_number || '-'}`} />
          </div>
        </div>}
      </div>}
    </>
  )
}
