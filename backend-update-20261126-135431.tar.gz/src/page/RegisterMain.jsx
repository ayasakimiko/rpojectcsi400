import { useEffect, useEffectEvent, useState } from 'react'
import axios from 'axios'
import { useLocation, useNavigate } from 'react-router-dom'
import { homePathForRole, sessionRole } from '../utils/session.js'
import 'bootstrap/dist/css/bootstrap.min.css'
import './css/Login.css'
import './css/RegisterPage.css'
import ThaiDatePicker from '../components/ThaiDatePicker.jsx'
import BirthDateInput from '../components/BirthDateInput.jsx'
import compressImageFile, { validateImageFile } from '../utils/compressImageFile.js'
import { digitsOnly, firstError, validatePersonForm } from '../utils/validators.js'
import { ContractImagePicker, DepositSettlementForm } from '../components/RentalContract.jsx'
import { roomFloorLabel } from '../utils/roomFloors.js'
import {
  addContractMonths,
  CONTRACT_DURATION_OPTIONS,
  CONTRACT_MAX_IMAGES,
  CONTRACT_MIN_IMAGES,
  DEPOSIT_MONTHS,
  firstMonthBreakdown,
  formatContractDate,
  formatContractMoney,
} from '../utils/rentalContract.js'

const formatDateTimeLocal = (date) => {
  const pad = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

const getNow = () => new Date()

const SECTION_ICONS = {
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  home: <><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9" /><path d="M10 21v-6h4v6" /></>,
  image: <><rect x="3" y="4" width="18" height="16" rx="3" /><circle cx="9" cy="10" r="2" /><path d="m21 16-5-5-9 9" /></>,
  lock: <><rect x="4" y="11" width="16" height="10" rx="2.5" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></>,
  back: <path d="M15 18l-6-6 6-6" />,
  alert: <><circle cx="12" cy="12" r="9" /><path d="M12 7.5v5.5M12 16.5h.01" /></>,
  check: <><circle cx="12" cy="12" r="9" /><path d="m8 12 3 3 5-6" /></>,
}

function RegisterIcon({ type, size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {SECTION_ICONS[type]}
    </svg>
  )
}

function RegisterSection({ step, icon, title, hint, children }) {
  return (
    <section className="register-section">
      <header className="register-section-head">
        <span className="register-section-icon"><RegisterIcon type={icon} /></span>
        <div>
          <small>ขั้นตอนที่ {step}</small>
          <strong>{title}</strong>
          {hint && <span>{hint}</span>}
        </div>
      </header>
      <div className="row g-3">{children}</div>
    </section>
  )
}

const Required = () => <span className="register-required" aria-hidden="true">*</span>

const dataUrlToFile = async (dataUrl, name) => {
  const blob = await (await fetch(dataUrl)).blob()
  const baseName = String(name || 'contract').replace(/\.[^.]+$/, '') || 'contract'
  return new File([blob], `${baseName}.jpg`, { type: 'image/jpeg' })
}

const MOBILE_QUERY = '(max-width: 576px)'

const useIsMobile = () => {
  const [isMobile, setIsMobile] = useState(
    () => typeof window !== 'undefined' && window.matchMedia(MOBILE_QUERY).matches,
  )

  useEffect(() => {
    const mql = window.matchMedia(MOBILE_QUERY)
    const handleChange = (e) => setIsMobile(e.matches)
    mql.addEventListener('change', handleChange)
    return () => mql.removeEventListener('change', handleChange)
  }, [])

  return isMobile
}

const initialRegisterForm = {
  idcard: '',
  first_name: '',
  last_name: '',
  phone: '',
  birth_date: '',
  room_number: '',
  rental_start_date: getNow(),
  contract_duration_months: '',
  deposit_months: DEPOSIT_MONTHS,
  password: '',
  confirmPassword: '',
}

function RegisterMain() {
  const navigate = useNavigate()
  const location = useLocation()
  const preselectedRoomNumber = location.state?.roomNumber
  const isMobile = useIsMobile()
  const [registerForm, setRegisterForm] = useState(initialRegisterForm)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [fieldErrors, setFieldErrors] = useState({})
  const [success, setSuccess] = useState('')
  const [availableRooms, setAvailableRooms] = useState([])
  const [roomsLoading, setRoomsLoading] = useState(true)
  const [contractImages, setContractImages] = useState([])
  const [contractImageError, setContractImageError] = useState('')
  const [idcardLookup, setIdcardLookup] = useState(null)
  const [idcardCandidates, setIdcardCandidates] = useState([])
  const [idcardSuggestOpen, setIdcardSuggestOpen] = useState(false)
  const idcardSuggestions =
    registerForm.idcard.length >= 1 && registerForm.idcard.length < 13
      ? idcardCandidates.filter((customer) => customer.idcard.startsWith(registerForm.idcard)).slice(0, 8)
      : []
  const showIdcardSuggestions = idcardSuggestOpen && idcardSuggestions.length > 0
  const selectedRoom = availableRooms.find((room) => String(room.room_number) === String(registerForm.room_number))
  const selectedRoomPrice = selectedRoom ? Number(selectedRoom.price) : null
  const contractEndDate =
    registerForm.rental_start_date && registerForm.contract_duration_months
      ? addContractMonths(registerForm.rental_start_date, registerForm.contract_duration_months)
      : null
  const firstMonth = selectedRoomPrice !== null ? firstMonthBreakdown(selectedRoomPrice, registerForm.deposit_months) : null

  const handleContractImagesChange = (files) => {
    const invalid = files.map(validateImageFile).find(Boolean)
    if (invalid) {
      setContractImageError(invalid)
      return
    }
    if (files.length > CONTRACT_MAX_IMAGES) {
      setContractImageError(`แนบรูปสัญญาได้ไม่เกิน ${CONTRACT_MAX_IMAGES} รูป`)
      return
    }
    setContractImageError('')
    setContractImages(files)
  }

  const applyAvailableRooms = useEffectEvent((rooms) => {
    setAvailableRooms(rooms)
    if (preselectedRoomNumber && rooms.some((room) => room.room_number === preselectedRoomNumber)) {
      setRegisterForm((prev) => ({ ...prev, room_number: preselectedRoomNumber }))
    }
  })

  useEffect(() => {
    let isMounted = true

    axios
      .get('/api/rooms/available')
      .then(({ data }) => {
        if (isMounted) applyAvailableRooms(data.rooms || [])
      })
      .catch(() => {
        if (isMounted) setError('ไม่สามารถโหลดรายการห้องว่างได้ กรุณาลองใหม่อีกครั้ง')
      })
      .finally(() => {
        if (isMounted) setRoomsLoading(false)
      })

    return () => {
      isMounted = false
    }
  }, [])

  const clearFieldError = (name) => setFieldErrors((prev) => (prev[name] ? { ...prev, [name]: null } : prev))

  const fieldClass = (name) => `form-control${fieldErrors[name] ? ' is-invalid' : ''}`

  const fieldFeedback = (name) =>
    fieldErrors[name] ? <div id={`register-${name}-error`} className="invalid-feedback d-block">{fieldErrors[name]}</div> : null

  const handleRegisterChange = (e) => {
    const { name, value } = e.target
    clearFieldError(name)
    setRegisterForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleIdcardChange = (e) => {
    clearFieldError('idcard')
    setRegisterForm((prev) => ({ ...prev, idcard: digitsOnly(e.target.value, 13) }))
    setIdcardLookup(null)
    setIdcardSuggestOpen(true)
  }

  const pickIdcardSuggestion = (customer) => {
    setRegisterForm((prev) => ({ ...prev, idcard: customer.idcard }))
    setIdcardLookup(null)
    setIdcardSuggestOpen(false)
  }

  useEffect(() => {
    let isActive = true
    axios
      .get('/api/auth/register/suggest', {
      })
      .then(({ data }) => {
        if (isActive) setIdcardCandidates(data.customers || [])
      })
      .catch(() => {})
    return () => {
      isActive = false
    }
  }, [])

  useEffect(() => {
    const idcard = registerForm.idcard
    if (idcard.length !== 13) return
    let isActive = true
    axios
      .get(`/api/auth/register/lookup/${idcard}`, {
      })
      .then(({ data }) => {
        if (!isActive) return
        if (!data.found) {
          setIdcardLookup({ found: false })
          return
        }
        const { first_name, last_name, phone, birth_date, room_number } = data.customer
        setRegisterForm((prev) => ({
          ...prev,
          first_name: first_name || prev.first_name,
          last_name: last_name || prev.last_name,
          phone: phone || prev.phone,
          birth_date: birth_date || prev.birth_date,
        }))
        setIdcardLookup({
          found: true,
          room_number,
          depositMessage: data.unsettled_deposit_message || null,
          depositContract: data.unsettled_deposit_contract || null,
        })
      })
      .catch(() => {})
    return () => {
      isActive = false
    }
  }, [registerForm.idcard])

  const handlePhoneChange = (e) => {
    clearFieldError('phone')
    setRegisterForm((prev) => ({ ...prev, phone: digitsOnly(e.target.value, 10) }))
  }

  const handleBirthDateChange = (value) => {
    clearFieldError('birth_date')
    setRegisterForm((prev) => ({ ...prev, birth_date: value }))
  }

  const handleRoomChange = (e) => {
    setRegisterForm((prev) => ({ ...prev, room_number: e.target.value }))
  }

  const handleRentalStartChange = (date) => {
    setRegisterForm((prev) => ({ ...prev, rental_start_date: date }))
  }

  const handleRegisterSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    const {
      idcard,
      first_name,
      last_name,
      phone,
      birth_date,
      room_number,
      rental_start_date,
      contract_duration_months,
      deposit_months,
      password,
      confirmPassword,
    } = registerForm

    const personErrors = validatePersonForm({ idcard, first_name, last_name, phone, birth_date, password, confirmPassword })
    setFieldErrors(personErrors)
    if (firstError(personErrors)) {
      setError(firstError(personErrors))
      return
    }

    if (
      !idcard ||
      !first_name ||
      !last_name ||
      !phone ||
      !birth_date ||
      !room_number ||
      !rental_start_date ||
      !contract_duration_months ||
      !password ||
      !confirmPassword
    ) {
      setError(contract_duration_months ? 'กรุณากรอกข้อมูลให้ครบทุกช่อง' : 'กรุณาเลือกระยะเวลาสัญญาเช่า')
      return
    }

    if (idcardLookup?.depositMessage) {
      setError(idcardLookup.depositMessage)
      return
    }

    if (contractImages.length < CONTRACT_MIN_IMAGES) {
      const message = `กรุณาแนบรูปสัญญาเช่าอย่างน้อย ${CONTRACT_MIN_IMAGES} รูป (แนบแล้ว ${contractImages.length} รูป)`
      setContractImageError(message)
      setError(message)
      return
    }

    if (Number(deposit_months) !== DEPOSIT_MONTHS) {
      setError(`เงินมัดจำต้องเป็น ${DEPOSIT_MONTHS} เดือน`)
      return
    }

    try {
      setLoading(true)
      const payload = new FormData()
      Object.entries({
        idcard,
        first_name,
        last_name,
        phone,
        birth_date,
        room_number,
        rental_start_date: formatDateTimeLocal(rental_start_date),
        contract_duration_months,
        deposit_months,
        password,
      }).forEach(([key, value]) => {
        if (value !== '' && value !== undefined && value !== null) payload.append(key, value)
      })
      const compressed = await Promise.all(contractImages.map((file) => compressImageFile(file)))
      const files = await Promise.all(compressed.map(({ name, dataUrl }) => dataUrlToFile(dataUrl, name)))
      files.forEach((file) => payload.append('contract_images', file))
      const { data } = await axios.post('/api/auth/register', payload, {
      })
      setSuccess(data.message || 'สมัครสมาชิกสำเร็จ')
      setRegisterForm({ ...initialRegisterForm, rental_start_date: getNow() })
      setContractImages([])
      setTimeout(() => navigate(homePathForRole(sessionRole())), 1200)
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'สมัครสมาชิกไม่สำเร็จ กรุณาลองใหม่อีกครั้ง')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page register-page">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12 col-lg-10 col-xl-9">
            <div className="auth-card register-card">
              <div className="register-head">
                <div className="register-head-main">
                  <span className="register-head-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                      <circle cx="9" cy="7" r="4" />
                      <path d="M19 8v6" />
                      <path d="M22 11h-6" />
                    </svg>
                  </span>
                  <div className="register-head-text">
                    <h1>ลงทะเบียนลูกค้าใหม่</h1>
                    <p>กรอก 4 ขั้นตอน · ช่องที่มี <Required /> ต้องกรอก</p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleRegisterSubmit} noValidate className="register-form">
                <RegisterSection step={1} icon="user" title="ข้อมูลผู้เช่า" hint="ชื่อ เลขบัตรประชาชน และช่องทางติดต่อ">
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-firstname">
                      ชื่อจริง <Required />
                    </label>
                    <input
                      id="register-firstname"
                      type="text"
                      name="first_name"
                      className={fieldClass('first_name')}
                      aria-invalid={Boolean(fieldErrors.first_name)}
                      aria-describedby={fieldErrors.first_name ? 'register-first_name-error' : undefined}
                      placeholder="ชื่อจริง"
                      value={registerForm.first_name}
                      onChange={handleRegisterChange}
                      autoComplete="given-name"
                    />
                    {fieldFeedback('first_name')}
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-lastname">
                      นามสกุล <Required />
                    </label>
                    <input
                      id="register-lastname"
                      type="text"
                      name="last_name"
                      className={fieldClass('last_name')}
                      aria-invalid={Boolean(fieldErrors.last_name)}
                      aria-describedby={fieldErrors.last_name ? 'register-last_name-error' : undefined}
                      placeholder="นามสกุล"
                      value={registerForm.last_name}
                      onChange={handleRegisterChange}
                      autoComplete="family-name"
                    />
                    {fieldFeedback('last_name')}
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-idcard">
                      เลขบัตรประชาชน <Required />
                    </label>
                    <div className="register-suggest">
                      <input
                        id="register-idcard"
                        type="text"
                        inputMode="numeric"
                        maxLength={13}
                        name="idcard"
                        className={fieldClass('idcard')}
                        aria-invalid={Boolean(fieldErrors.idcard)}
                        aria-describedby={fieldErrors.idcard ? 'register-idcard-error' : undefined}
                        placeholder="เลขบัตรประชาชน 13 หลัก"
                        value={registerForm.idcard}
                        onChange={handleIdcardChange}
                        onFocus={() => setIdcardSuggestOpen(true)}
                        onBlur={() => setIdcardSuggestOpen(false)}
                        onKeyDown={(event) => {
                          if (event.key === 'Escape') setIdcardSuggestOpen(false)
                        }}
                        autoComplete="off"
                        role="combobox"
                        aria-expanded={showIdcardSuggestions}
                        aria-controls="register-idcard-suggest"
                      />
                      {showIdcardSuggestions && (
                        <ul id="register-idcard-suggest" className="register-suggest-list" role="listbox">
                          {idcardSuggestions.map((customer) => (
                            <li key={customer.idcard} role="option" aria-selected="false">
                              <button
                                type="button"
                                onMouseDown={(event) => event.preventDefault()}
                                onClick={() => pickIdcardSuggestion(customer)}
                              >
                                <strong>
                                  <mark>{customer.idcard.slice(0, registerForm.idcard.length)}</mark>
                                  {customer.idcard.slice(registerForm.idcard.length)}
                                </strong>
                                <small>
                                  {[customer.first_name, customer.last_name].filter(Boolean).join(' ') || '-'}
                                  {customer.phone ? ` · ${customer.phone}` : ''}
                                </small>
                              </button>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                    {fieldFeedback('idcard')}
                    {idcardLookup?.depositMessage ? (
                      <p className="register-field-hint is-danger" role="alert">
                        <RegisterIcon type="alert" size={14} />
                        <span><b>ผู้เช่าเดิม</b> · ต้องจัดการเงินมัดจำของสัญญาเก่าก่อนลงทะเบียน</span>
                      </p>
                    ) : idcardLookup?.found ? (
                      <p className={`register-field-hint ${idcardLookup.room_number != null ? 'is-danger' : 'is-success'}`}>
                        <RegisterIcon type={idcardLookup.room_number != null ? 'alert' : 'check'} size={14} />
                        <span>
                          <b>ผู้เช่าเดิม</b> ·{' '}
                          {idcardLookup.room_number != null
                            ? `มีสัญญาเช่าห้อง ${idcardLookup.room_number} อยู่แล้ว`
                            : 'ดึงชื่อ นามสกุล เบอร์โทร และวันเกิดให้แล้ว'}
                        </span>
                      </p>
                    ) : (
                      <div className="form-text">ใช้เป็นชื่อผู้ใช้สำหรับเข้าสู่ระบบ</div>
                    )}
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-phone">
                      เบอร์โทรศัพท์ <Required />
                    </label>
                    <input
                      id="register-phone"
                      type="tel"
                      inputMode="numeric"
                      maxLength={10}
                      name="phone"
                      className={fieldClass('phone')}
                      aria-invalid={Boolean(fieldErrors.phone)}
                      aria-describedby={fieldErrors.phone ? 'register-phone-error' : undefined}
                      placeholder="0812345678"
                      value={registerForm.phone}
                      onChange={handlePhoneChange}
                      autoComplete="tel"
                    />
                    {fieldFeedback('phone')}
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-birth_date">
                      วันเดือนปีเกิด <Required />
                    </label>
                    <BirthDateInput
                      id="register-birth_date"
                      value={registerForm.birth_date}
                      invalid={Boolean(fieldErrors.birth_date)}
                      onChange={handleBirthDateChange}
                    />
                    {fieldFeedback('birth_date')}
                  </div>
                  {idcardLookup?.depositContract && (
                    <div className="col-12 register-deposit-settle">
                      <DepositSettlementForm
                        contract={idcardLookup.depositContract}
                        onSaved={() => {
                          setIdcardLookup((prev) => ({ ...prev, depositMessage: null, depositContract: null, depositSettled: true }))
                          setError('')
                        }}
                      />
                    </div>
                  )}
                  {idcardLookup?.depositSettled && (
                    <div className="col-12">
                      <p className="register-field-hint is-success">
                        <RegisterIcon type="check" size={14} />
                        <span>บันทึกการจัดการเงินมัดจำของสัญญาเก่าแล้ว ลงทะเบียนสัญญาใหม่ต่อได้เลย</span>
                      </p>
                    </div>
                  )}
                </RegisterSection>

                <RegisterSection step={2} icon="home" title="ห้องพักและสัญญาเช่า" hint="ราคาห้องดึงจากข้อมูลห้องจริง วันสิ้นสุดคำนวณให้อัตโนมัติ">
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-room-number">
                      ห้องพัก <Required />
                    </label>
                    <select
                      id="register-room-number"
                      name="room_number"
                      className="form-select"
                      value={registerForm.room_number}
                      onChange={handleRoomChange}
                      disabled={roomsLoading}
                    >
                      <option value="">
                        {roomsLoading ? 'กำลังโหลดห้องว่าง...' : 'เลือกห้องว่าง'}
                      </option>
                      {availableRooms.map((room) => (
                        <option key={room.id} value={room.room_number}>
                          ห้อง {room.room_number} ({roomFloorLabel(room.room_number)}) · {formatContractMoney(room.price)}/เดือน
                          {room.room_size != null ? ` · ${Number(room.room_size).toLocaleString('th-TH', { maximumFractionDigits: 2 })} ตร.ม.` : ''}
                        </option>
                      ))}
                    </select>
                    {!roomsLoading && availableRooms.length === 0 && (
                      <div className="form-text text-danger">ขณะนี้ไม่มีห้องว่าง</div>
                    )}
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-deposit">
                      เงินมัดจำ <Required />
                    </label>
                    <input
                      id="register-deposit"
                      type="text"
                      name="deposit_months"
                      className="form-control"
                      value={`${DEPOSIT_MONTHS} เดือน${selectedRoomPrice !== null ? ` · ${formatContractMoney(selectedRoomPrice * DEPOSIT_MONTHS)}` : ''}`}
                      disabled
                    />
                    <div className="form-text">
                      {selectedRoom
                        ? `มัดจำ ${DEPOSIT_MONTHS} เดือนทุกสัญญา · ชำระพร้อมค่าห้องเดือนแรก`
                        : `มัดจำ ${DEPOSIT_MONTHS} เดือนของราคาห้อง · เลือกห้องเพื่อดูยอด`}
                    </div>
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-contract-duration">
                      ระยะเวลาสัญญาเช่า <Required />
                    </label>
                    <select
                      id="register-contract-duration"
                      name="contract_duration_months"
                      className="form-select"
                      value={registerForm.contract_duration_months}
                      onChange={handleRegisterChange}
                    >
                      <option value="">เลือกระยะเวลาสัญญา</option>
                      {CONTRACT_DURATION_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-rental-start">
                      วันเวลาที่เริ่มเช่า <Required />
                    </label>
                    <ThaiDatePicker
                      id="register-rental-start"
                      name="rental_start_date"
                      valueType="date"
                      placeholder="เลือกวันเวลา"
                      value={registerForm.rental_start_date}
                      onChange={handleRentalStartChange}
                      showTimeSelect
                      timeIntervals={15}
                      withPortal={isMobile}
                      portalId="rental-date-portal"
                    />
                  </div>

                  <div className="col-12">
                    <div className="register-contract-summary">
                      <div className="rcs-date">
                        <span className="rcs-date-icon" aria-hidden="true">
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="3" y="5" width="18" height="16" rx="3" />
                            <path d="M16 3v4M8 3v4M3 11h18" />
                          </svg>
                        </span>
                        <div>
                          <span>สิ้นสุดสัญญา</span>
                          <strong className={contractEndDate ? '' : 'is-empty'}>
                            {contractEndDate ? formatContractDate(contractEndDate, true) : 'เลือกระยะสัญญา'}
                          </strong>
                        </div>
                      </div>
                      <div className="rcs-calc">
                        <div className="rcs-item">
                          <span>ค่าห้อง</span>
                          <strong>{firstMonth ? formatContractMoney(firstMonth.price) : '-'}</strong>
                        </div>
                        <span className="rcs-op" aria-hidden="true">+</span>
                        <div className="rcs-item">
                          <span>มัดจำ{firstMonth?.depositMonths ? ` ${firstMonth.depositMonths} เดือน` : ''}</span>
                          <strong>{firstMonth ? formatContractMoney(firstMonth.deposit) : '-'}</strong>
                        </div>
                        <span className="rcs-op" aria-hidden="true">=</span>
                        <div className="rcs-item is-total">
                          <span>เดือนแรก</span>
                          <strong>{firstMonth ? formatContractMoney(firstMonth.total) : '-'}</strong>
                        </div>
                      </div>
                    </div>
                  </div>

                </RegisterSection>

                <RegisterSection
                  step={3}
                  icon="image"
                  title={<>รูปสัญญาเช่า <Required /></>}
                  hint="ถ่ายสัญญาทุกหน้าให้อ่านออกชัดเจน"
                >
                  <div className="col-12">
                    <ContractImagePicker files={contractImages} onChange={handleContractImagesChange} error={contractImageError} />
                  </div>
                </RegisterSection>

                <RegisterSection step={4} icon="lock" title="บัญชีเข้าใช้งาน" hint="ผู้เช่าใช้เลขบัตรประชาชนหรือเลขห้องคู่กับรหัสผ่านนี้เข้าสู่ระบบ">
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-password">
                      รหัสผ่าน <Required />
                    </label>
                    <input
                      id="register-password"
                      type="password"
                      name="password"
                      className={fieldClass('password')}
                      aria-invalid={Boolean(fieldErrors.password)}
                      aria-describedby={fieldErrors.password ? 'register-password-error' : undefined}
                      placeholder="อย่างน้อย 6 ตัวอักษร"
                      value={registerForm.password}
                      onChange={handleRegisterChange}
                      autoComplete="new-password"
                    />
                    {fieldFeedback('password')}
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label" htmlFor="register-confirm-password">
                      ยืนยันรหัสผ่าน <Required />
                    </label>
                    <input
                      id="register-confirm-password"
                      type="password"
                      name="confirmPassword"
                      className={fieldClass('confirmPassword')}
                      aria-invalid={Boolean(fieldErrors.confirmPassword)}
                      aria-describedby={fieldErrors.confirmPassword ? 'register-confirmPassword-error' : undefined}
                      placeholder="ยืนยันรหัสผ่าน"
                      value={registerForm.confirmPassword}
                      onChange={handleRegisterChange}
                      autoComplete="new-password"
                    />
                    {fieldFeedback('confirmPassword')}
                    {!fieldErrors.confirmPassword && registerForm.confirmPassword && registerForm.password !== registerForm.confirmPassword && (
                      <div className="form-text text-danger">รหัสผ่านไม่ตรงกัน</div>
                    )}
                  </div>
                </RegisterSection>

                <div className="register-actions">
                  {(error || success) && (
                    <div className={`auth-alert ${success ? 'is-success' : ''}`} role={error ? 'alert' : 'status'}>
                      <span className="auth-alert-icon"><RegisterIcon type={success ? 'check' : 'alert'} size={18} /></span>
                      <span>{success || error}</span>
                    </div>
                  )}
                  <div className="register-actions-row">
                    <div className="register-actions-meta">
                      {selectedRoom ? (
                        <>
                          <span>ห้อง {selectedRoom.room_number} · {roomFloorLabel(selectedRoom.room_number)}{registerForm.contract_duration_months ? ` · ${registerForm.contract_duration_months} เดือน` : ''}</span>
                          <strong>เดือนแรก {firstMonth ? formatContractMoney(firstMonth.total) : '-'} · ถัดไป {firstMonth ? formatContractMoney(firstMonth.price) : '-'}/เดือน</strong>
                        </>
                      ) : (
                        <span>ยังไม่ได้เลือกห้อง</span>
                      )}
                    </div>
                    <button type="button" className="auth-secondary-btn register-cancel" disabled={loading} onClick={() => navigate(-1)}>
                      ยกเลิก
                    </button>
                    <button type="submit" className="auth-submit-btn register-submit" disabled={loading || Boolean(idcardLookup?.depositMessage)}>
                      {loading ? 'กำลังลงทะเบียน...' : 'ลงทะเบียนลูกค้า'}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default RegisterMain
