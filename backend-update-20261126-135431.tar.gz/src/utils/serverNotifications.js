import { useCallback, useEffect, useRef, useState } from 'react'
import axios from 'axios'

const POLL_MS = 60000

const KIND_BY_TYPE_PREFIX = [
  ['tenant_request', 'tenant'],
  ['renew', 'tenant'],
  ['maintenance', 'maintenance'],
  ['slip', 'slip'],
  ['payment', 'slip'],
  ['fine', 'visit'],
  ['visit', 'visit'],
  ['safety', 'safety'],
  ['staff', 'staff'],
  ['tenant_registered', 'staff'],
  ['waiting', 'staff'],
]

function kindOf(type = '') {
  return KIND_BY_TYPE_PREFIX.find(([prefix]) => type.startsWith(prefix))?.[1] || 'document'
}

export function toBellItem(row, pending = false) {
  return {
    key: pending ? `pending-${row.key}` : `server-${row.id}`,
    serverId: pending ? null : row.id,
    type: row.type || null,
    actorName: row.actor_name || null,
    isRead: pending ? null : Boolean(row.is_read),
    title: row.title,
    label: row.message,
    tone: row.tone || 'info',
    date: row.created_at,
    preview: row.detail || null,
    previewLabel: 'รายละเอียด',
    detail: row.detail || null,
    details: [
      { label: 'สถานะ', value: row.message },
      row.detail && { label: 'รายละเอียด', value: row.detail },
      row.actor_name && { label: 'ดำเนินการโดย', value: row.actor_name },
    ].filter(Boolean),
    kind: row.kind || kindOf(row.type),
    target: row.target || null,
    refId: row.ref_id ?? null,
    refTable: row.ref_table || null,
    server: true,
  }
}

function timeOf(item) {
  const value = typeof item.date === 'string' ? item.date.replace(/^(\d{4}-\d{2}-\d{2}) (?=\d)/, '$1T') : item.date
  const time = value ? new Date(value).getTime() : Number.NaN
  return Number.isFinite(time) ? time : Number.NEGATIVE_INFINITY
}

export function sortNewestFirst(items, now = Date.now()) {
  return items
    .map((item) => ({ item, time: Math.min(timeOf(item), now) }))
    .sort((a, b) => (b.time > a.time) - (b.time < a.time))
    .map(({ item }) => item)
}

export function isUnread(item, seenKeys) {
  if (item.serverId) return !item.isRead
  return seenKeys.has ? !seenKeys.has(item.key) : !seenKeys.includes(item.key)
}

export function topicOf(item) {
  return item.target ? item.target.split(':')[0] : item.kind || ''
}

const sameSubject = (a, b) => a.key === b.key || (a.title === b.title && topicOf(a) === topicOf(b))

const MAX_SEEN_KEYS = 1000
const RETRY_MS = 5000
const DISMISS_CHUNK = 200

function readSeenKeys(storageKey) {
  if (!storageKey) return new Set()
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey) || '[]')
    return new Set(Array.isArray(stored) ? stored : [])
  } catch {
    return new Set()
  }
}

export function useNotificationReads(storageKey, serverFeed) {
  const [seen, setSeen] = useState(() => ({ storageKey, keys: readSeenKeys(storageKey) }))
  let seenKeys = seen.keys
  if (seen.storageKey !== storageKey) {
    seenKeys = readSeenKeys(storageKey)
    setSeen({ storageKey, keys: seenKeys })
  }
  const { markRead: markServerRead, markAllRead: markAllServerRead } = serverFeed

  const rememberSeen = useCallback((keys) => {
    if (keys.length === 0) return
    const next = new Set([...keys, ...seenKeys].slice(0, MAX_SEEN_KEYS))
    setSeen({ storageKey, keys: next })
    try {
      if (storageKey) localStorage.setItem(storageKey, JSON.stringify([...next]))
    } catch (error) {
      console.warn('Could not save seen notifications', error)
    }
  }, [seenKeys, storageKey])

  const markRead = useCallback((item, notifications) => {
    const items = notifications.filter((other) => sameSubject(other, item) && isUnread(other, seenKeys))
    if (!items.some((other) => other.key === item.key) && isUnread(item, seenKeys)) items.push(item)
    markServerRead(items.filter((other) => other.serverId).map((other) => other.serverId))
    rememberSeen(items.filter((other) => !other.serverId).map((other) => other.key))
  }, [markServerRead, rememberSeen, seenKeys])

  const markAllRead = useCallback((notifications) => {
    const unread = notifications.filter((item) => isUnread(item, seenKeys))
    if (unread.some((item) => item.serverId)) markAllServerRead?.()
    rememberSeen(unread.filter((item) => !item.serverId).map((item) => item.key))
  }, [markAllServerRead, rememberSeen, seenKeys])

  return { seenKeys, markRead, markAllRead }
}

export function useServerNotifications(apiBase, { pendingKinds = [], enabled = true, onNewEvents } = {}) {
  const [events, setEvents] = useState([])
  const [pending, setPending] = useState([])
  const [dismissed, setDismissed] = useState(() => new Set())
  const newestId = useRef(0)
  const readIds = useRef(new Set())
  const dismissedKeys = useRef(new Set())
  const onNewEventsRef = useRef(onNewEvents)
  const kinds = pendingKinds.join(',')

  useEffect(() => {
    onNewEventsRef.current = onNewEvents
  }, [onNewEvents])

  const refresh = useCallback(() => axios
    .get(`${apiBase}/notifications`, {
      params: kinds ? { pending: kinds } : undefined,
    })
    .then(({ data }) => {
      const rows = data.notifications || []
      const newest = rows.reduce((max, row) => Math.max(max, Number(row.id) || 0), 0)
      const fresh = Boolean(newestId.current && newest > newestId.current)
      if (fresh) onNewEventsRef.current?.()
      newestId.current = Math.max(newestId.current, newest)
      setEvents(rows.map((row) => toBellItem(readIds.current.has(row.id) ? { ...row, is_read: true } : row)))
      setPending((data.pending || []).map((row) => toBellItem(row, true)))
      if (Array.isArray(data.dismissed)) {
        const next = new Set([...data.dismissed, ...dismissedKeys.current])
        setDismissed((current) => (current.size === next.size && [...next].every((key) => current.has(key)) ? current : next))
      }
      return fresh
    })
    .catch(() => false), [apiBase, kinds])

  useEffect(() => {
    if (!enabled) return undefined
    const first = setTimeout(refresh, 0)
    const timer = setInterval(refresh, POLL_MS)
    window.addEventListener('focus', refresh)
    return () => {
      clearTimeout(first)
      clearInterval(timer)
      window.removeEventListener('focus', refresh)
    }
  }, [enabled, refresh])

  useEffect(() => {
    if (!enabled) return undefined
    const controller = new AbortController()
    let cursor = null
    const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
    ;(async () => {
      while (!controller.signal.aborted) {
        try {
          const { data } = await axios.get(`${apiBase}/notifications/wait`, {
            params: cursor ? { cursor } : undefined,
            signal: controller.signal,
            timeout: 40000,
          })
          cursor = data.cursor
          if (data.changed && !(await refresh())) onNewEventsRef.current?.()
        } catch {
          if (controller.signal.aborted) return
          await pause(RETRY_MS)
        }
      }
    })()
    return () => controller.abort()
  }, [apiBase, enabled, refresh])

  const markRead = useCallback((ids) => {
    const unread = ids.filter((id) => !readIds.current.has(id))
    if (unread.length === 0) return
    unread.forEach((id) => readIds.current.add(id))
    setEvents((current) => current.map((item) => (unread.includes(item.serverId) ? { ...item, isRead: true } : item)))
    axios.post(`${apiBase}/notifications/read`, { ids: unread }).catch(() => {
      unread.forEach((id) => readIds.current.delete(id))
    })
  }, [apiBase])

  const markAllRead = useCallback(() => {
    if (!events.some((item) => !item.isRead)) return
    events.forEach((item) => readIds.current.add(item.serverId))
    setEvents((current) => current.map((item) => ({ ...item, isRead: true })))
    axios.post(`${apiBase}/notifications/read`, { all: true }).catch(() => {})
  }, [apiBase, events])

  const dismiss = useCallback((keys) => {
    const fresh = keys.filter((key) => key && !dismissedKeys.current.has(key))
    if (fresh.length === 0) return Promise.resolve()
    fresh.forEach((key) => dismissedKeys.current.add(key))
    setDismissed((current) => new Set([...current, ...fresh]))
    const chunks = []
    for (let index = 0; index < fresh.length; index += DISMISS_CHUNK) chunks.push(fresh.slice(index, index + DISMISS_CHUNK))
    return Promise.all(chunks.map((keys) => axios.post(`${apiBase}/notifications/dismiss`, { keys }))).catch((error) => {
      fresh.forEach((key) => dismissedKeys.current.delete(key))
      setDismissed((current) => new Set([...current].filter((key) => !fresh.includes(key))))
      throw error
    })
  }, [apiBase])

  return { events, pending, dismissed, markRead, markAllRead, dismiss, refresh }
}

export function withoutDismissed(items, dismissed) {
  return dismissed?.size ? items.filter((item) => !dismissed.has(item.key)) : items
}

export function takeNotificationDeepLink() {
  try {
    const params = new URLSearchParams(window.location.search)
    const tab = params.get('tab')
    if (!tab) return null
    const link = { tab, section: params.get('section'), focus: params.get('focus') }
    window.history.replaceState(null, '', window.location.pathname)
    return link
  } catch {
    return null
  }
}
