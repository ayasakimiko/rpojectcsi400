import mysql from "mysql2/promise";
import "dotenv/config";

export const SCHEMA_SERVICES = ["room", "auth", "customer", "maintenance", "payment", "staff", "admin", "owner", "parcel", "market"];

export const ISOLATED_SERVICES = new Set(["market"]);

export const TABLES_BY_SERVICE = {
  room: ["Room", "RoomType", "RoomFloor", "RoomWifi", "RoomWifiDevice"],
  auth: ["Customer", "Staff", "Admin", "Owner", "Booking", "ContractImage", "RoomTransfer", "ContractAmendment"],
  customer: ["TenantRequest", "ParkingSpace", "ResidentVisitRequest", "SafetyIncident"],
  maintenance: ["MaintenanceRequest", "MaintenancePhoto", "RepairVendor", "RepairVendorApiKey", "RepairJob", "RepairVendorImage", "RepairVendorIntegration", "RepairWebhookEvent", "RepairContract", "RepairContractItem", "RepairContractInstallment", "RepairContractFile"],
  payment: ["Payment", "PaymentSlip", "PaymentSlipRejection"],
  staff: ["MoveOutInspection", "DepositSettlementLog", "MoveInInspection"],
  admin: ["Announcement", "AnnouncementAcknowledgement", "WaitingList"],
  owner: ["Expense", "RoomOccupancySnapshot", "AuditLog", "DormConfig", "Notification", "NotificationRead", "NotificationDismiss"],
  parcel: ["Parcel", "ParcelPhoto"],
  market: ["Shop", "ShopLease", "ShopProduct", "ShopApiKey", "ShopLeaseImage", "ShopLeasePayment", "ShopSeed"],
};

export const TABLE_OWNER = Object.fromEntries(
  Object.entries(TABLES_BY_SERVICE).flatMap(([service, tables]) => tables.map((table) => [table, service])),
);

export function serviceDatabaseName(baseName, service) {
  if (!SCHEMA_SERVICES.includes(service)) throw new Error(`Unknown database service: ${service}`);
  const name = `${baseName}_${service}`;
  if (!/^[a-zA-Z0-9_]+$/.test(name) || name.length > 64) {
    throw new Error(`Invalid MySQL database name: ${name}`);
  }
  return name;
}

const {
  DB_HOST = "localhost",
  DB_PORT = "3308",
  DB_USER = "root",
  DB_PASSWORD = "",
  DB_NAME = "projectcsi400",
  DB_POOL_SIZE,
  MARKET_DB_USER,
  MARKET_DB_PASSWORD,
} = process.env;

export const DB_CONFIG = {
  host: DB_HOST,
  port: Number(DB_PORT),
  user: DB_USER,
  password: DB_PASSWORD,
  database: DB_NAME,
};

const SERVICE_DB_CREDENTIALS = {
  market: { user: MARKET_DB_USER, password: MARKET_DB_PASSWORD },
};

export function serviceCredentials(service) {
  const credentials = SERVICE_DB_CREDENTIALS[service];
  return credentials?.user && credentials?.password ? credentials : null;
}

const poolSize = Number(DB_POOL_SIZE) || 4;

let pool;
let databaseService;

export function configureDatabaseService(service) {
  serviceDatabaseName(DB_CONFIG.database, service);
  if (pool || (databaseService && databaseService !== service)) {
    throw new Error("Database service must be configured once before opening a connection");
  }
  databaseService = service;
}

export function getPool() {
  if (!databaseService) throw new Error("Database service has not been configured");
  if (!pool) {
    pool = mysql.createPool({
      ...DB_CONFIG,
      ...serviceCredentials(databaseService),
      database: serviceDatabaseName(DB_CONFIG.database, databaseService),
      waitForConnections: true,
      connectionLimit: poolSize,
      maxIdle: 1,
      idleTimeout: 10000,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 10000,
    });
  }
  return pool;
}
