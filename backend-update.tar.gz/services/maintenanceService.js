import express from "express";
import "dotenv/config";
import { configureDatabaseService } from "../Database/connection.js";
import { createCorsMiddleware } from "../middleware/cors.js";
import { auditDetailsMiddleware } from "../middleware/auditDetails.js";
import { authenticate, requireStaffRole } from "../middleware/authMiddleware.js";
import { requireActiveStaff } from "../middleware/accounts.js";
import { sendApiError } from "../middleware/marketApiKey.js";
import { authenticateRepairApiKey, repairApiCors } from "../middleware/repairApiKey.js";
import customerRouter from "../router/CustomerDashboardRouter.js";
import staffRouter from "../router/StaffRouter.js";
import adminRouter from "../router/AdminRouter.js";
import repairVendorRouter from "../router/RepairVendorRouter.js";
import repairVendorApiRouter from "../router/RepairVendorApiRouter.js";
import { RepairError } from "../router/repairVendorShared.js";
import { repairPartnerWebhook } from "../router/RepairPartnerWebhook.js";
import { CONTRACT_JSON_LIMIT } from "../router/repairContracts.js";
import { domainRouter } from "./domainRoutes.js";

configureDatabaseService("maintenance");

const app = express();
const PORT = process.env.MAINTENANCE_PORT || 4008;
const REPAIR_API_PREFIX = "/api/repair/v1";
const REPAIR_STAFF_PREFIX = "/api/staff/repair-vendors";
const REPAIR_WEBHOOK_PREFIX = "/api/repair/webhooks";
const isPartnerApi = (url) => url.startsWith(REPAIR_API_PREFIX) || url.startsWith(REPAIR_WEBHOOK_PREFIX);

app.set("trust proxy", "loopback, uniquelocal");
// raw body: X-Signature is an HMAC of the exact bytes the partner sent
app.post(`${REPAIR_WEBHOOK_PREFIX}/renocare/:ref`, express.raw({ type: () => true, limit: "64kb" }), repairPartnerWebhook);
// key check runs before the body is read, so only authenticated vendors can send large contract bodies
const vendorJson = express.json({ limit: "64kb" });
const contractJson = express.json({ limit: CONTRACT_JSON_LIMIT });
const CONTRACT_PUT = /^\/jobs\/[^/]+\/contracts\/[^/]+\/?$/;
const vendorBody = (req, res, next) => (req.method === "PUT" && CONTRACT_PUT.test(req.path) ? contractJson : vendorJson)(req, res, next);
app.use(REPAIR_API_PREFIX, repairApiCors, authenticateRepairApiKey, vendorBody, repairVendorApiRouter);

app.use(createCorsMiddleware());
app.use(express.json({ limit: "12mb" }));
app.use(auditDetailsMiddleware);

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "maintenance" }));
app.use(REPAIR_STAFF_PREFIX, authenticate, requireStaffRole, requireActiveStaff, repairVendorRouter);
app.use("/api/customer", domainRouter(customerRouter, "customer", "maintenance"));
app.use("/api/staff", domainRouter(staffRouter, "staff", "maintenance"));
app.use("/api/admin", domainRouter(adminRouter, "admin", "maintenance"));

app.use((req, res) => {
  if (isPartnerApi(req.originalUrl)) return sendApiError(res, 404, "NOT_FOUND", "ไม่พบ endpoint นี้");
  return res.status(404).json({ message: "ไม่พบเส้นทาง API นี้" });
});

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  const vendorApi = isPartnerApi(req.originalUrl);
  if (error instanceof RepairError) {
    return vendorApi ? sendApiError(res, error.status, error.code, error.message) : res.status(error.status).json({ message: error.message, code: error.code });
  }
  if (vendorApi && error.type === "entity.too.large") {
    return sendApiError(res, 413, "PAYLOAD_TOO_LARGE", `ข้อมูลใหญ่เกินไป (PUT สัญญารับได้ไม่เกิน ${CONTRACT_JSON_LIMIT} ไฟล์ใหญ่ให้ส่งแยกผ่าน POST .../files)`);
  }
  if (error.type === "entity.parse.failed" || error.type === "entity.too.large") {
    return vendorApi
      ? sendApiError(res, 400, "VALIDATION_ERROR", "รูปแบบ JSON ไม่ถูกต้องหรือใหญ่เกินไป")
      : res.status(400).json({ message: "รูปแบบข้อมูลไม่ถูกต้อง" });
  }
  if (error.message === "Not allowed by CORS") return res.status(403).json({ message: "ไม่อนุญาตให้เข้าถึงจาก origin นี้" });
  console.error("Maintenance service error:", error);
  return vendorApi
    ? sendApiError(res, 500, "SERVER_ERROR", "ระบบขัดข้อง กรุณาลองใหม่ภายหลัง")
    : res.status(500).json({ message: "เกิดข้อผิดพลาดของระบบ กรุณาลองใหม่อีกครั้ง" });
});

const server = app.listen(PORT, () => console.log(`Maintenance service is running on http://localhost:${PORT}`));
server.keepAliveTimeout = 65000;
server.headersTimeout = 66000;
